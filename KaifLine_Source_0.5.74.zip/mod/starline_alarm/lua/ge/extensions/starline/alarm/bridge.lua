--[[
  starline_alarm_bridge.lua — Game Engine (GE) Lua bridge

  ROLE: single source of truth for WHICH vehicle the keyfob talks to.

  Root cause this file fixes ("keyfob stops working after exiting the car"):
    getPlayerVehicle(0) returns nil as soon as the player leaves the vehicle,
    so every command after exiting was dropped. The bridge now remembers the
    vehicle id and addresses the vehicle through
      getObjectByID(id):queueLuaCommand(...)
    which works for ANY spawned vehicle, not only the one the player sits in
    (verified: vehicleBridge.lua, sounds.lua, checkpoints.lua use exactly this
    for non-player vehicles).

  Verified APIs (BeamNG 0.40.4):
    getObjectByID(id)                    lua/ge/ge_utils.lua:450
    <obj>:queueLuaCommand(str)           lua/ge/extensions/core/vehicleBridge.lua
    extensions.hook('onVehicleDestroyed', vid)   lua/ge/main.lua:1196
]]

local M = {}

-- Must stay in sync with starlineAlarm.WHITELIST and keyfob.js WHITELIST.
local WHITELIST = {
  arm = true, disarm = true, lock = true, unlock = true,
  trunk = true, find = true, remoteStart = true, stopEngine = true,
  alarmOff = true, status = true, authorize = true, setSensitivity = true,
  silentArm = true, silentDisarm = true, silentAlarmArm = true,
  shockSensitivityMode = true, tiltSensitivityMode = true, serviceMode = true,
  panic = true, panicOff = true,
  shockLevel = true, tiltLevel = true,
  requestState = true,
}

local TAG = "starline_alarm.bridge"

local boundVehicleId = nil   -- 0/nil = no vehicle bound
local linkLost = false
local lastState = nil
local lastStateAt = 0
local alarmVehicles = {}
local vehicleStates = {}
local vehicleStateTimes = {}
local manualSelection = false
local lastPlayerVehicleId = nil
local pagerSound = "/art/sound/starline_alarm/pager_alarm.wav"
local pagerSourceId
local pagerDelay = 0
local pagerFailed = false
local pagerSettingsPath = "/settings/starlinePager.json"
local pagerGains = {[0] = 0, [1] = 0.32, [2] = 1}
local pagerVolume = 2

local function logI(msg) log("I", TAG, tostring(msg)) end
local function logW(msg) log("W", TAG, tostring(msg)) end

local function stopPager()
  if pagerSourceId then
    local source = scenetree.findObjectById(pagerSourceId)
    if source then source:stop(0) end
  end
  pagerSourceId = nil
  pagerDelay = 0
  pagerFailed = false
end

function M.setPagerVolume(level)
  if type(level) ~= "number" or pagerGains[level] == nil then return pagerVolume end
  if level ~= pagerVolume then
    pagerVolume = level
    stopPager()
    local ok, saved = pcall(jsonWriteFile, pagerSettingsPath, {volume = level}, true)
    if not ok or saved == false then logW("pager volume settings could not be saved") end
  end
  return pagerVolume
end

-- Only [A-Za-z] command names reach Lua: a UI string can never smuggle code.
local function isSafeName(name)
  return type(name) == "string" and name:match("^[A-Za-z]+$") ~= nil
end

local function resolveVehicle()
  if not boundVehicleId then return nil end
  local obj = getObjectByID and getObjectByID(boundVehicleId) or nil
  if not obj then
    if not linkLost then
      linkLost = true
      logW("vehicle " .. tostring(boundVehicleId) .. " is gone; link lost")
    end
    return nil
  end
  linkLost = false
  return obj
end

local function sendLua(code)
  local veh = resolveVehicle()
  if not veh then return false, "no_vehicle" end
  local ok, err = pcall(function() veh:queueLuaCommand(code) end)
  if not ok then
    logW("queueLuaCommand failed: " .. tostring(err))
    return false, "queue_failed"
  end
  return true
end

-- ------------------------------------------------------------- binding

function M.bindVehicle(id)
  id = tonumber(id)
  if not id then return false end
  alarmVehicles[id] = true
  if boundVehicleId ~= id then
    stopPager()
    boundVehicleId = id
    linkLost = false
    lastState = vehicleStates[id]
    lastStateAt = vehicleStateTimes[id] or 0
    logI("bound to vehicle " .. tostring(id))
  end
  return true
end

-- Called from the vehicle adapter on init/reset.
function M.registerAlarmVehicle(id)
  id = tonumber(id)
  if not id then return false end
  alarmVehicles[id] = true
  local player = getPlayerVehicle and getPlayerVehicle(0)
  if not manualSelection and player and player:getId() == id then return M.bindVehicle(id) end
  if not boundVehicleId then return M.bindVehicle(id) end
  return true
end

local function selectPlayerVehicle()
  local player = getPlayerVehicle and getPlayerVehicle(0)
  local id = player and player:getId() or nil
  if id ~= lastPlayerVehicleId then
    lastPlayerVehicleId = id
    manualSelection = false
  end
  if not manualSelection and id and alarmVehicles[id] and id ~= boundVehicleId then
    M.bindVehicle(id)
  end
end

function M.onVehicleSwitched(oldId, newId, player)
  if player ~= nil and player ~= 0 then return end
  -- Query the actual player object; some hooks run before their newId is current.
  local before = boundVehicleId
  selectPlayerVehicle()
  if boundVehicleId ~= before then M.requestState() end
end

function M.getBoundVehicleId() selectPlayerVehicle() return boundVehicleId end
function M.hasLink()
  selectPlayerVehicle()
  return boundVehicleId ~= nil and resolveVehicle() ~= nil
    and lastState ~= nil and os.clock() - lastStateAt < 4
end

-- HUD-only preferences: writing the game's layout file can remount all apps.
local hudPositions
local hudPositionPath = "/settings/kaiflineHudPosition.json"
local function hudPositionKey(filename, index)
  local layouts = extensions and extensions.ui_appLayouts
  if not layouts or not layouts.getCurrentLayout or type(filename) ~= "string"
    or type(index) ~= "number" or index % 1 ~= 0 or index < 0 then return nil end
  local layout = layouts.getCurrentLayout()
  if not layout or layout.filename ~= filename or type(layout.apps) ~= "table" then return nil end
  local function isKeyfob(entry)
    local name = entry and tostring(entry.appName):lower():gsub("[^a-z]", "")
    return name == "starlinekeyfob" or name == "kaiflinekeyfob"
  end
  if not isKeyfob(layout.apps[index + 1]) then return nil end
  local ordinal = 0
  for i = 1, index + 1 do if isKeyfob(layout.apps[i]) then ordinal = ordinal + 1 end end
  return filename .. "#" .. ordinal
end
local function getHudDragPositions()
  if not hudPositions then
    local ok, data = pcall(jsonReadFile, hudPositionPath)
    hudPositions = ok and type(data) == "table" and data or {}
  end
  return hudPositions
end
function M.getHudDragPosition(filename, index)
  local key = hudPositionKey(filename, index)
  return key and getHudDragPositions()[key] or nil
end
function M.saveHudDragPosition(filename, index, left, top)
  local key = hudPositionKey(filename, index)
  if not key or type(left) ~= "number" or left ~= left or left < 0 or left > 100
    or type(top) ~= "number" or top ~= top or top < 0 or top > 100 then return false end
  local positions = getHudDragPositions()
  positions[key] = {left=left, top=top}
  local ok, result = pcall(jsonWriteFile, hudPositionPath, positions, true)
  return ok and result ~= false
end
function M.clearHudDragPosition(filename, index)
  local key = hudPositionKey(filename, index)
  if not key then return false end
  local positions = getHudDragPositions()
  positions[key] = nil
  local ok, result = pcall(jsonWriteFile, hudPositionPath, positions, true)
  return ok and result ~= false
end

-- Cosmetic HUD preferences live separately from the game's app layout.
local hudPreferences
local hudPreferencesPath = "/settings/kaiflineHudPreferences.json"
function M.getHudPreferences()
  if not hudPreferences then
    local ok, data = pcall(jsonReadFile, hudPreferencesPath)
    data = ok and type(data) == "table" and data or {}
    hudPreferences = {skin="horizon",
      language=data.language == "en" and "en" or "ru"}
  end
  return {skin=hudPreferences.skin, language=hudPreferences.language}
end
function M.setHudPreferences(skin, language)
  if (skin ~= "horizon") or (language ~= "ru" and language ~= "en") then return false end
  local prefs = {skin=skin, language=language}
  local ok, result = pcall(jsonWriteFile, hudPreferencesPath, prefs, true)
  if not ok or result == false then return false end
  hudPreferences = prefs
  return true
end

-- ------------------------------------------------------------- commands

function M.command(name, arg, expectedVehicleId)
  selectPlayerVehicle()
  if not isSafeName(name) or not WHITELIST[name] then
    logW("rejected command: " .. tostring(name))
    return false, "rejected"
  end

  if not M.hasLink() then return false, "no_link" end
  if expectedVehicleId ~= nil and expectedVehicleId ~= boundVehicleId then return false, "vehicle_changed" end
  local argLiteral = "nil"
  if type(arg) == "number" then argLiteral = string.format("%f", arg) end

  local code = string.format(
    "if starline_alarm_handleCommand then starline_alarm_handleCommand('%s', %s) end",
    name, argLiteral)

  local ok, why = sendLua(code)
  if not ok then
    logW("command '" .. name .. "' not delivered: " .. tostring(why))
    return false, why
  end
  return true
end

-- ------------------------------------------------------------- state

-- Vehicle Lua pushes state here on every change and on a timer, so the HUD
-- can still render a sane keyfob when the vehicle Lua is not answering.
function M.onVehicleState(stateTable)
  if type(stateTable) ~= "table" then return end
  local id = tonumber(stateTable.vehicleId)
  if not id then return end
  alarmVehicles[id] = true
  vehicleStates[id] = stateTable
  vehicleStateTimes[id] = os.clock()
  selectPlayerVehicle()
  if not boundVehicleId then M.bindVehicle(id) end
  if id ~= boundVehicleId then return end
  if stateTable.alarmState ~= "ALARM" and lastState and lastState.alarmState == "ALARM" then
    stopPager()
  end
  lastState = stateTable
  lastStateAt = os.clock()
  if guihooks and guihooks.trigger then
    stateTable.link = M.hasLink()
    pcall(guihooks.trigger, "starlineAlarmState", M.getState())
  end
end

local function getVehicleDisplayName(vehicle)
  if not core_vehicles then return nil end
  local ok, data = pcall(core_vehicles.getModel, vehicle.JBeam or vehicle:getJBeamFilename())
  local model = ok and data and data.model
  local name = model and model.Name
  if type(name) ~= "string" or not name:find("%S") then return nil end

  local brand = model.Brand
  if type(brand) == "string" and brand:find("%S")
    and name:lower() ~= brand:lower() and name:lower():sub(1, #brand + 1) ~= brand:lower() .. " " then
    return brand .. " " .. name
  end
  return name
end

function M.getAlarmVehicles()
  local list = {}
  for id in pairs(alarmVehicles) do
    local obj = getObjectByID and getObjectByID(id)
    if obj then
      local state = vehicleStates[id]
      list[#list + 1] = {vehicleId=id, vehicleName=getVehicleDisplayName(obj),
        link=state ~= nil and os.clock() - (vehicleStateTimes[id] or 0) < 4,
        armed=state and state.armed == true or false}
    end
  end
  table.sort(list, function(a, b) return a.vehicleId < b.vehicleId end)
  return list
end

function M.selectVehicle(id)
  if type(id) ~= "number" or id % 1 ~= 0 or id < 1 or not alarmVehicles[id]
    or not (getObjectByID and getObjectByID(id)) then
    return false, "vehicle_unavailable"
  end
  selectPlayerVehicle()
  manualSelection = true
  M.bindVehicle(id)
  M.requestState()
  if guihooks and guihooks.trigger then
    pcall(guihooks.trigger, "starlineAlarmState", M.getState())
  end
  return true
end

function M.onUpdate(dtReal)
  if pagerVolume == 0 then return end
  if not lastState or lastState.alarmState ~= "ALARM" then return end
  if not M.hasLink() then
    stopPager()
    return
  end
  if pagerFailed then return end
  pagerDelay = pagerDelay - dtReal
  if pagerDelay > 0 then return end
  pagerDelay = 0.95
  local ok, result = pcall(function()
    return Engine.Audio.playOnce("AudioGui", pagerSound, {volume = pagerGains[pagerVolume]})
  end)
  if ok and result and result.sourceId then
    pagerSourceId = result.sourceId
  else
    pagerFailed = true
    logW("pager alarm could not play: " .. tostring(result))
  end
end

-- JSON entry point for Vehicle Lua: VLua must NOT index
-- extensions.starline_alarm_bridge directly (vehicle-side loader only
-- resolves lua/vehicle/extensions/ and logs 'extension unavailable' on
-- every access). VLua serializes with jsonEncode and hands the string
-- over via obj:queueGameEngineLua.
function M.onVehicleStateJson(jsonStr)
  if type(jsonStr) ~= "string" or jsonStr == "" then return end
  if type(jsonDecode) ~= "function" then return end
  local ok, st = pcall(jsonDecode, jsonStr)
  if ok and type(st) == "table" then M.onVehicleState(st) end
end

local function getGameClock()
  local value
  if core_environment and type(core_environment.getTimeOfDay) == "function" then
    local ok, tod = pcall(core_environment.getTimeOfDay)
    if ok and type(tod) == "table" then value = tonumber(tod.time) end
  end
  if not value and scenetree and scenetree.findClassObjects and scenetree.findObject then
    local ok, names = pcall(scenetree.findClassObjects, "TimeOfDay")
    if ok and type(names) == "table" and names[1] then
      local found, obj = pcall(scenetree.findObject, names[1])
      if found and obj then value = tonumber(obj.time) end
    end
  end
  if not value or value ~= value or value < 0 or value > 1 then return "--:--" end
  -- BeamNG's 0.0 is noon, 0.5 is midnight.
  local minutes = math.floor((((value + 0.5) % 1) * 1440) + 0.0001)
  return string.format("%02d:%02d", math.floor(minutes / 60), minutes % 60)
end

function M.getState()
  selectPlayerVehicle()
  local st = {}
  if type(lastState) == "table" then
    for k, v in pairs(lastState) do st[k] = v end
  end
  st.clock = getGameClock()
  st.link = M.hasLink()
  st.vehicleId = boundVehicleId
  st.pagerVolume = pagerVolume
  st.vehicles = M.getAlarmVehicles()
  local selected = resolveVehicle()
  if selected then st.vehicleName = getVehicleDisplayName(selected) end
  return st
end

function M.requestState()
  sendLua("if starline_alarm_pushNow then starline_alarm_pushNow() end")
  return M.getState()
end

-- ------------------------------------------------------------- lifecycle

function M.onVehicleDestroyed(vid)
  alarmVehicles[tonumber(vid)] = nil
  vehicleStates[tonumber(vid)] = nil
  vehicleStateTimes[tonumber(vid)] = nil
  if boundVehicleId and tonumber(vid) == boundVehicleId then
    stopPager()
    logI("bound vehicle destroyed: " .. tostring(vid))
    linkLost = true
    boundVehicleId = nil
    manualSelection = false
    lastState = nil
    lastStateAt = 0
    if guihooks and guihooks.trigger then
      pcall(guihooks.trigger, "starlineAlarmState",
        { link = false, vehicleId = nil, alarmState = "DISARMED" })
    end
  end
end

function M.onExtensionUnloaded()
  stopPager()
  alarmVehicles = {}
  vehicleStates = {}
  vehicleStateTimes = {}
  manualSelection = false
end

--[[
  Регистрация режима выгрузки — ИЗНУТРИ расширения.

  Почему не из modScript (проверено по lua/ge/main.lua):
    manualUnloadExtensions формируется из startupExtensions на старте игры
    (main.lua:382), ДО выполнения modScript. Вызов setExtensionUnloadMode
    из modScript добавляет имя в список слишком поздно: при смене игрового
    режима loadGameModeModules (main.lua:1626) вызывает
    unloadAutoExtensions() -> unloadExcept(manualUnloadExtensions), и моста
    в списке ещё нет -> он выгружается -> каждое обращение даёт
    "extension unavailable" и брелок перестаёт управлять машиной.

  Правильный способ прямо указан в main.lua:356:
    "To keep an extension loaded across levels:
       M.onInit = function() setExtensionUnloadMode(M, "manual") end"
  onInit вызывается после загрузки расширения (processLoadedFreshList),
  до смены игрового режима, поэтому имя успевает попасть в список.

  Передаём M (таблицу), а не строку: setExtensionUnloadMode берёт
  extension.__extensionName__ (main.lua:425-430), а это ровно
  "starline_alarm_bridge" — то же имя, под которым модуль загружен.
]]
function M.onInit()
  local ok, saved = pcall(jsonReadFile, pagerSettingsPath)
  if ok and type(saved) == "table" and type(saved.volume) == "number"
    and pagerGains[saved.volume] ~= nil then
    pagerVolume = saved.volume
  end
  if setExtensionUnloadMode then
    pcall(setExtensionUnloadMode, M, "manual")
    logI("unload mode registered: manual")
  end
end

function M.onExtensionLoaded()
  logI("loaded")
  return true
end

function M.arm() return M.command("arm") end
function M.disarm() return M.command("disarm") end
function M.status() return M.command("status") end

-- A response is queued to the requesting vehicle, not the HUD selection.
function M.requestWelcomeLight(vehicleId)
  local id = tonumber(vehicleId)
  local vehicle = id and getObjectByID and getObjectByID(id)
  if not vehicle then return false end
  local darkness = require('ge/extensions/starline/alarm/darkness')
  local dark = darkness.isDark(vehicle)
  vehicle:queueLuaCommand('_G.starline_alarm_welcomeLight(' .. tostring(dark == true) .. ')')
  return true
end

return M
