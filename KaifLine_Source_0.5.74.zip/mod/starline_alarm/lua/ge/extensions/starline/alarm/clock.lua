-- Runs in GE Lua: the level clock is shared by all alarm vehicles.
local M = {}
local elapsed = 0
local lastClock

function M.getClock()
  local env = core_environment or (extensions and extensions.core_environment)
  local ok, tod = false, nil
  if env and env.getTimeOfDay then ok, tod = pcall(env.getTimeOfDay) end
  local value = ok and type(tod) == 'table' and tonumber(tod.time) or nil
  if not value and scenetree and scenetree.findClassObjects then
    local found, names = pcall(scenetree.findClassObjects, 'TimeOfDay')
    if found and type(names) == 'table' then
      for _, name in ipairs(names) do
        local foundObject, obj = pcall(scenetree.findObject, name)
        if foundObject and obj then value = tonumber(obj.time) end
        if value then break end
      end
    end
  end
  if not value or value ~= value or math.abs(value) == math.huge then return '--:--' end
  local minutes = math.floor(((value + .5) % 1) * 1440 + .0001) % 1440
  return string.format('%02d:%02d', math.floor(minutes / 60), minutes % 60)
end

local function publish()
  local clock = M.getClock()
  if clock ~= lastClock then
    log('I', 'kaifline.clock', 'level clock: ' .. clock)
    lastClock = clock
  end
  -- Decorate even an older bridge that survived a live mod upgrade.
  local bridge = extensions and extensions.starline_alarm_bridge
  if bridge and bridge.getState and not bridge.kaiflineClockVersion then
    local original = bridge.getState
    bridge.getState = function(...)
      local state = original(...)
      state.clock = M.getClock()
      return state
    end
    bridge.kaiflineClockVersion = 1
  end
  if guihooks and guihooks.trigger then
    guihooks.trigger('kaiflineGameClock', clock)
    if bridge and bridge.getState then guihooks.trigger('starlineAlarmState', bridge.getState()) end
  end
end

function M.onUpdate(dtReal)
  elapsed = elapsed + (dtReal or 0)
  if elapsed < .5 then return end
  elapsed = 0
  publish()
end
function M.onExtensionLoaded() publish() end
return M
