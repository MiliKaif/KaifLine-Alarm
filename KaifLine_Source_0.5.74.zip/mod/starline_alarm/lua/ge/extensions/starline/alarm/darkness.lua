-- GE scene queries: night lighting state or broad overhead cover.
local M = {}
function M.isDark(vehicle)
  local env = core_environment or (extensions and extensions.core_environment)
  if env and env.getLightState then
    local ok, light = pcall(env.getLightState)
    if ok and light and light.isNight then return true end
  end
  if env and env.getTimeOfDay then
    local ok, tod = pcall(env.getTimeOfDay)
    if ok and tod and tonumber(tod.time) then
      local hour = ((tod.time + 0.5) % 1) * 24
      if hour <= 6 or hour >= 18 then return true end
    end
  end
  if not vehicle or not castRayStatic or not vec3 then return false end
  local ok, covered = pcall(function()
    local pos = vehicle:getPosition()
    local hits = 0
    for _, offset in ipairs({{0,0},{2,0},{-2,0},{0,2},{0,-2}}) do
      local start = vec3(pos.x + offset[1], pos.y + offset[2], pos.z + 1.6)
      if castRayStatic(start, vec3(0,0,1), 20) < 20 then hits = hits + 1 end
    end
    return hits >= 4
  end)
  return ok and covered == true
end
return M
