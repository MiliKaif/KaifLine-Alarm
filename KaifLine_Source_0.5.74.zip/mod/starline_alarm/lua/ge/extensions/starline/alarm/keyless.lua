-- Handle-trigger adapter for the optional KaifLine Keyless JBeam part.
-- BeamNG calls this hook immediately before dispatching the trigger action.
local M = {}
local MAX_DISTANCE_SQUARED = 4.0 * 4.0
local registered = {}
local scanTimer = 0
local LOCK_ACTION = 'kaifline_keyless_lock'

local function triggerName(link, vehicleId)
  local id = link and link.triggerId
  if type(id) == 'string' and id:lower():find('door', 1, true) then return id end
  if not (extensions and extensions.core_vehicle_manager) then return nil end
  local ok, data = pcall(extensions.core_vehicle_manager.getVehicleData, vehicleId)
  if not ok then return nil end
  local triggers = data and data.vdata and data.vdata.triggers
  local row = triggers and (triggers[id] or triggers[tonumber(id)])
  return row and (row.name or row.id) or nil
end

local function exteriorDoor(name)
  if type(name) ~= 'string' then return nil end
  local lower = name:lower()
  if lower:find('_int', 1, true) or lower:find('interior', 1, true)
    or lower:find('inside', 1, true) then return nil end
  local zone = lower:match('door[_%-]?([fr][lr])')
  if zone then return zone:upper() end
  local side = lower:match('door[_%-]([lr])$')
  if side then return side == 'l' and 'FL' or 'FR' end
  return nil
end

function M.registerVehicle(id)
  id = tonumber(id)
  if id and id > 0 then registered[id] = registered[id] or {} end
end

local function installMiddleClick(id, record)
  local manager = extensions and extensions.core_vehicle_manager
  if not (manager and manager.getVehicleData) then return end
  local ok, data = pcall(manager.getVehicleData, id)
  local vdata = ok and data and data.vdata
  if not (vdata and vdata.triggers and vdata.triggerEventLinksDict and vdata.inputActions) then return end
  if record.vdata == vdata then return end
  vdata.inputActions[LOCK_ACTION] = {
    ctx = 'vlua', onDown = 'do end', order = 50.8,
    title = 'KaifLine · Закрыть', desc = 'Поставить машину на охрану через Keyless'
  }
  local handles, added = 0, 0
  for triggerId, links in pairs(vdata.triggerEventLinksDict) do
    if type(links) == 'table' and type(links.action0) == 'table'
      and exteriorDoor(triggerName({triggerId=triggerId}, id)) then
      handles = handles + 1
      if not links.action2 then
        links.action2 = {{
          version=2, namespace='vehicle', triggerId=triggerId,
          triggerInput='action2', inputAction=LOCK_ACTION
        }}
        added = added + 1
      end
    end
  end
  if handles > 0 then
    record.vdata = vdata
    log('I', 'starline_alarm.keyless',
      string.format('vehicle %d: %d exterior handles, %d middle-click links', id, handles, added))
  end
end

function M.onUpdate(dt)
  scanTimer = scanTimer + (tonumber(dt) or 0)
  if scanTimer < 0.4 then return end
  scanTimer = 0
  for id, record in pairs(registered) do
    if not (getObjectByID and getObjectByID(id)) then
      registered[id] = nil
    else
      installMiddleClick(id, record)
    end
  end
end

function M.onVehicleDestroyed(id)
  id = tonumber(id)
  if id then registered[id] = nil end
end

function M.onVehicleTriggersExecuteLink(link, value, vehicleId, player)
  if (tonumber(value) or 0) < 0.9 then return end
  if link and link.triggerInput == 'action2' and link.inputAction ~= LOCK_ACTION then return end
  local zone = exteriorDoor(triggerName(link, vehicleId))
  if not zone then return end
  local car = getObjectByID and getObjectByID(vehicleId)
  if not car then return end
  local playerCar = getPlayerVehicle and getPlayerVehicle(player or 0)
  local walk = gameplay_walk
  if walk and walk.isWalking and walk.isWalking(player) then
    if not playerCar or playerCar == car then return end
    local ok, near = pcall(function()
      local a, b = playerCar:getPosition(), car:getPosition()
      local dx, dy, dz = a.x-b.x, a.y-b.y, a.z-b.z
      return dx*dx + dy*dy + dz*dz <= MAX_DISTANCE_SQUARED
    end)
    if not ok or not near then return end
  elseif playerCar ~= car then
    -- Orbit camera: the selected car itself is the player's vehicle.
    return
  end
  -- The optional controller is absent when the Keyless subslot is empty.
  -- Send before the original handle action; the vehicle queue preserves order.
  local action = link.inputAction == LOCK_ACTION and 'handleLock' or 'handlePress'
  car:queueLuaCommand(string.format(
    'local k=controller.getControllerSafe("starlineKeyless"); if k and k.%s then k.%s(%q) end',
    action, action, zone))
end

return M
