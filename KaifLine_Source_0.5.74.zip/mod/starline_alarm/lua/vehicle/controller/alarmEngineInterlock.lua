-- Alarm-owned engine start interlock. A pre-existing engine failure is never repaired.
local M = {}
local powertrain = require('powertrain')
local ownedDevice = nil

local function mainEngine()
  local ok, device = pcall(powertrain.getDevice, 'mainEngine')
  if ok and type(device) == 'table' then return device end
  return nil
end

function M.block()
  local device = mainEngine()
  if not device then return false, 'unsupported' end
  if ownedDevice and ownedDevice ~= device then M.unblock() end
  if not ownedDevice then
    if device.isDisabled then return false, 'already_disabled' end
    ownedDevice = device
  end
  device.isDisabled = true
  _G.starline_alarm_check_engine = 1
  return true
end

function M.unblock()
  local device = ownedDevice
  ownedDevice = nil
  _G.starline_alarm_check_engine = 0
  if not device then return false end
  -- Engine damage also sets starterDisabled/outputTorqueState/isBroken.
  -- Clearing isDisabled in that case would silently repair the car.
  if device.isBroken or device.starterDisabled or device.outputTorqueState == 0 then
    return false
  end
  device.isDisabled = false
  return true
end

function M.isActive()
  return ownedDevice ~= nil and ownedDevice.isDisabled == true
end

function M.isSupported()
  return mainEngine() ~= nil
end

return M
