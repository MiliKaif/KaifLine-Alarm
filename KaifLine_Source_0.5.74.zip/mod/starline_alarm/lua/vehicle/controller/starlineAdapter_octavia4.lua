-- Use the Octavia IV's own locks and latch telemetry. Its exterior handles,
-- mirror folding, welcome lights and lock sounds all depend on these keys.
local M = {}
local base = require('controller/vehicleAdapterUniversal')
local electrics = require('electrics')
local relockPending = 0
local nativeUnlockPending = false
local skipNextUnlock = false
local suppressNativeUnlock = false
local interiorUnlockGuard = 0
local lastNativeLocked = nil
local lastIgnition = nil
local wrappedSystem = nil
local originalMethods = nil
local wrappedMethods = nil
local remoteAccess = false
local keyPoint = nil
local keyAge = math.huge
local ignitionOffGuard = 0
local alarmGuarded = false

local lockKeys = {
  'octavia4DoorLockedFL', 'octavia4DoorLockedFR',
  'octavia4DoorLockedRL', 'octavia4DoorLockedRR',
  'octavia4DoorLockedTrunk',
}
local doorKeys = {
  FL = 'octavia4DoorLockedFL', FR = 'octavia4DoorLockedFR',
  RL = 'octavia4DoorLockedRL', RR = 'octavia4DoorLockedRR',
  trunk = 'octavia4DoorLockedTrunk',
}
local includeFlags = {
  octavia4DoorLockedFR = 'lockInclude_FR',
  octavia4DoorLockedRL = 'lockInclude_RL',
  octavia4DoorLockedRR = 'lockInclude_RR',
  octavia4DoorLockedTrunk = 'lockInclude_trunk',
}

local function nativeLocked()
  local e = electrics.values
  for _, key in ipairs(lockKeys) do
    local flag = includeFlags[key]
    if (not flag or (tonumber(e[flag]) or 1) >= 0.5)
      and (tonumber(e[key]) or 0) < 0.5 then return false end
  end
  return true
end

local function keylessActive()
  local e = electrics.values
  return (tonumber(e.octavia4KeylessEntry) or 0) >= 0.5
    and (tonumber(e.octavia4Kessy) or 1) >= 0.5
end

local function anyDoorOpen()
  local e = electrics.values
  for _, key in ipairs({'door_FL_coupler_notAttached', 'door_FR_coupler_notAttached',
                        'door_RL_coupler_notAttached', 'door_RR_coupler_notAttached',
                        'trunkCoupler_notAttached'}) do
    if (tonumber(e[key]) or 0) >= 0.5 then return true end
  end
  return false
end

local function keyNearCar()
  if not keyPoint or keyAge > 1 or not obj or not v or not v.data then return false end
  local ok, base = pcall(obj.getPosition, obj)
  if not ok or not base then return false end
  local dx, dy = keyPoint.x - base.x, keyPoint.y - base.y
  if dx * dx + dy * dy > 100 then return false end
  -- Match Octavia's own KeyLess distance test: sample body nodes in local
  -- coordinates, then require the on-foot key to be within 1.5 metres.
  local best, index = math.huge, 0
  for _, node in pairs(v.data.nodes or {}) do
    index = index + 1
    if index % 5 == 0 and node.cid then
      local valid, p = pcall(obj.getNodePosition, obj, node.cid)
      if valid and p then
        local ex, ey = dx - p.x, dy - p.y
        best = math.min(best, ex * ex + ey * ey)
      end
    end
  end
  return best < 1.5 * 1.5
end

local function native()
  return rawget(_G, 'octavia4AutoLocking')
end

local function call(name)
  local system = native()
  if not system or type(system[name]) ~= 'function' then return false end
  local ok = pcall(system[name])
  return ok
end

local function unbindNative()
  if wrappedSystem and originalMethods then
    for name, original in pairs(originalMethods) do
      if wrappedSystem[name] == wrappedMethods[name] then
        wrappedSystem[name] = original
      end
    end
  end
  wrappedSystem, originalMethods, wrappedMethods = nil, nil, nil
end

local function bindNative()
  local system = native()
  if not system or system == wrappedSystem then return end
  unbindNative()
  wrappedSystem, originalMethods, wrappedMethods = system, {}, {}

  if type(system.unlockAll) == 'function' then
    local original = system.unlockAll
    originalMethods.unlockAll = original
    wrappedMethods.unlockAll = function(...)
      local wasLocked = nativeLocked()
      local result = original(...)
      if wasLocked and not nativeLocked() and not suppressNativeUnlock then
        nativeUnlockPending = true
      end
      return result
    end
    system.unlockAll = wrappedMethods.unlockAll
  end

  if type(system.exteriorHandle) == 'function' then
    local original = system.exteriorHandle
    originalMethods.exteriorHandle = original
    wrappedMethods.exteriorHandle = function(door, ...)
      local key = doorKeys[door]
      local wasLocked = key and (tonumber(electrics.values[key]) or 0) >= 0.5
      if wasLocked and remoteAccess and keylessActive() and keyNearCar() then
        local openKey = door == 'trunk' and 'trunkCoupler_notAttached'
          or ('door_' .. tostring(door) .. '_coupler_notAttached')
        if (tonumber(electrics.values[openKey]) or 0) < 0.5
          and M.unlockDoors() and (tonumber(electrics.values[key]) or 0) < 0.5 then
          nativeUnlockPending = true
        end
      end
      local result = original(door, ...)
      -- A locked exterior handle can only release itself when Octavia has
      -- accepted a nearby KeyLess key. An unlocked handle is not proof.
      if wasLocked and keylessActive()
        and (tonumber(electrics.values[key]) or 0) < 0.5 then
        nativeUnlockPending = true
      end
      return result
    end
    system.exteriorHandle = wrappedMethods.exteriorHandle
  end

  if type(system.interiorHandle) == 'function' then
    local original = system.interiorHandle
    originalMethods.interiorHandle = original
    wrappedMethods.interiorHandle = function(...)
      if nativeLocked() then interiorUnlockGuard = 0.5 end
      return original(...)
    end
    system.interiorHandle = wrappedMethods.interiorHandle
  end

  if type(system.keyAt) == 'function' then
    local original = system.keyAt
    originalMethods.keyAt = original
    wrappedMethods.keyAt = function(x, y, z, ...)
      local result = original(x, y, z, ...)
      local px, py, pz = tonumber(x), tonumber(y), tonumber(z)
      if px and py and pz then
        keyPoint = {x = px, y = py, z = pz}
        keyAge = 0
      else
        keyPoint, keyAge = nil, math.huge
      end
      return result
    end
    system.keyAt = wrappedMethods.keyAt
  end
end

function M.init()
  base.init()
  bindNative()
  if lastNativeLocked == nil and native() then
    lastNativeLocked = nativeLocked()
    lastIgnition = tonumber(electrics.values.ignitionLevel) or 0
  end
  -- The car extension can arrive after our controller. Retrying discovery
  -- leaves all telemetry available while the vehicle finishes loading.
  return native() ~= nil
end

function M.reset()
  -- Native onReset owns the lock keys. Never run the universal latch guard.
  relockPending = 0
  nativeUnlockPending, skipNextUnlock = false, false
  suppressNativeUnlock, interiorUnlockGuard = false, 0
  lastNativeLocked, lastIgnition = nil, nil
  remoteAccess, keyPoint, keyAge = false, nil, math.huge
  ignitionOffGuard, alarmGuarded = 0, false
  unbindNative()
end

function M.isInitialized() return native() ~= nil end
function M.supportsDoors() return base.supportsDoors() end
function M.supportsTrunk() return base.supportsTrunk() end
function M.supportsHood() return base.supportsHood() end
function M.supportsCentralLock() return native() ~= nil end
function M.getDoorStates() return base.getDoorStates() end
function M.getTrunkStateTable() return base.getTrunkStateTable() end
function M.getHoodStateTable() return base.getHoodStateTable() end
function M.getTrunkState() return base.getTrunkState() end
function M.allDoorsClosed() return base.allDoorsClosed() end
function M.anyDoorOpen() return base.anyDoorOpen() end

function M.lockDoors()
  -- KaifLine owns intrusion detection and its alarm sound. Prevent Octavia's
  -- separate 30-second horn alarm from sounding over it, while retaining the
  -- native lock flash, mirror and tail-light sequence.
  local e = electrics.values
  nativeUnlockPending = false
  skipNextUnlock = false
  local monitor = e.octavia4IntMonitor
  e.octavia4IntMonitor = 0
  local ok = call('lockAll')
  e.octavia4IntMonitor = monitor
  lastNativeLocked = nativeLocked()
  return ok
end
function M.unlockDoors()
  relockPending = 0
  if skipNextUnlock then
    skipNextUnlock = false
    lastNativeLocked = nativeLocked()
    return true
  end
  local e = electrics.values
  -- The car can be configured to unlock only the driver's door. Disarming
  -- KaifLine must release every door with one native unlock animation.
  local selection = e.octavia4DoorUnlock
  e.octavia4DoorUnlock = 0
  suppressNativeUnlock = true
  local ok = call('unlockAll')
  suppressNativeUnlock = false
  e.octavia4DoorUnlock = selection
  lastNativeLocked = nativeLocked()
  return ok
end
function M.openTrunk() return call('openTrunk') end

function M.consumeAuthorizedUnlock()
  if not nativeUnlockPending then return false end
  nativeUnlockPending = false
  skipNextUnlock = true
  return true
end

function M.setRemoteAccess(active)
  remoteAccess = active == true
end

function M.setAlarmGuarded(active)
  alarmGuarded = active == true
end

function M.scheduleRelock()
  -- Octavia unlocks on the falling ignition edge in its own updateGFX,
  -- which runs after KaifLine's controller update. Restore a guarded car
  -- on the following frame, after that edge has been processed.
  relockPending = 0.15
  return true
end

function M.updateGFX(dt)
  bindNative()
  dt = dt or 0
  keyAge = keyAge + dt
  interiorUnlockGuard = math.max(0, interiorUnlockGuard - dt)
  ignitionOffGuard = math.max(0, ignitionOffGuard - dt)
  local ignition = tonumber(electrics.values.ignitionLevel) or 0
  local locked = nativeLocked()
  if (lastIgnition or 0) >= 2 and ignition < 2 then
    -- Octavia's own update runs after ours and unlocks every door on this
    -- edge. The resulting lock change is visible only on the next frame.
    ignitionOffGuard = 0.6
    if alarmGuarded then relockPending = math.max(relockPending, 0.2) end
  end
  -- The car's proximity unlock calls a local function, bypassing its public
  -- unlockAll method. Observe that lock transition while KeyLess is active.
  -- Engine shutdown and a locked interior-handle pull must not authorize.
  if lastNativeLocked and not locked and keylessActive() and keyNearCar()
    and ignition < 2 and ignitionOffGuard <= 0
    and interiorUnlockGuard <= 0 and not anyDoorOpen() then
    nativeUnlockPending = true
  end
  lastNativeLocked, lastIgnition = locked, ignition
  if relockPending <= 0 or not alarmGuarded then return end
  relockPending = relockPending - (dt or 0)
  if relockPending > 0 then return end
  relockPending = 0
  if not nativeLocked() then
    M.lockDoors()
  end
end

function M.getLockStateTable()
  if not native() then
    return {state='UNSUPPORTED', locked=false, physical='unsupported'}
  end
  local e = electrics.values
  local locked = true
  for _, key in ipairs(lockKeys) do
    if (tonumber(e[key]) or 0) < 0.5 then locked = false; break end
  end
  return {
    state = locked and 'LOCKED' or 'UNLOCKED',
    locked = locked,
    physical = locked and 'locked' or 'unlocked',
  }
end
function M.getLockState() return M.getLockStateTable().state end
function M.nativeLockFeedback() return true end

function M.getIgnitionLevel() return base.getIgnitionLevel() end
function M.isEngineRunning() return base.isEngineRunning() end
function M.getRPM() return base.getRPM() end
function M.getWheelspeed() return base.getWheelspeed() end
function M.getParkingBrake() return base.getParkingBrake() end
function M.getThrottle() return base.getThrottle() end

return M
