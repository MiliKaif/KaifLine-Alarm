--[[
  starlineAlarm.lua
  Контроллер автомобильной сигнализации KaifLine.
  Контекст: Vehicle Lua (VLua), тип auxiliary.
  Загружается через JBeam-часть starline_alarm_module (slotType: etk800_mod).

  Подтверждённые API (проверено по исходникам BeamNG.drive 0.40.x):
    electrics.values.*                  lua/vehicle/electrics.lua
    electrics.setIgnitionLevel(level)   lua/vehicle/electrics.lua:348
    electrics.set_warn_signal(value)    lua/vehicle/electrics.lua:955
    electrics.setLightsState(state)     lua/vehicle/electrics.lua (M.setLightsState)
    electrics.light_flash_highbeams(on) lua/vehicle/electrics.lua:996
    controller.getControllerSafe(name)  lua/vehicle/controller.lua:236
    onNodeCollision(p) -> controller.nodeCollision(p)  lua/vehicle/main.lua:491
    controller.updateGFX(dtSim)         lua/vehicle/controller.lua:113
    guihooks.message({txt,context},ttl,ctx)  lua/vehicle/electrics.lua:355

  Машина состояний:
    DISARMED <-> ARMED
    ARMED -> ALARM (датчик удара)
    ALARM -> DISARMED (снятие/таймаут)
    REMOTE_STARTING -> REMOTE_RUNNING (автозапуск)
    REMOTE_RUNNING -> WAIT_AUTH (ожидание авторизации водителя)
    WAIT_AUTH -> RUNNING_AUTHORIZED
    WAIT_AUTH -> ALARM (газ/движение без авторизации -> двигатель заглушён, сирена и свет)
    IMMOBILIZED -> DISARMED (только после правильной команды)

  Бренд интерфейса: KaifLine.
]]

local M = {}
M.type = "auxiliary"
M.defaultOrder = 900

local controller = require("controller")
local electrics = require("electrics")
local sounds = require("sounds")
local engineInterlock = require("controller/alarmEngineInterlock")

-- ============================================================
-- Конфигурация
-- ============================================================

local CFG = {
  -- Интервалы
  uiPushInterval        = 0.5,   -- сек, пуш состояния в CEF UI
  armDelay              = 0.6,   -- сек, задержка постановки (проверка дверей)
  disarmFlashCount      = 2,     -- число вспышек при снятии
  armFlashCount         = 1,     -- число вспышек при постановке (A93: 1 свет + 1 звук)
  armGraceTime          = 3.0,   -- сек: игнор ударов сразу после ARMED (закрытие дверей)
  alarmFlashPeriod      = 0.35,  -- сек, период мигания в тревоге
  alarmAutoStopTime     = 30.75, -- сек, один полный цикл записи сирены
  alarmMaxCycles        = 8,     -- макс. повторных циклов тревоги, затем lockout
  alarmRearmLockoutTime = 6.0,   -- сек, защита от повторного срабатывания
  remoteStartTimeout    = 6.0,   -- сек, макс. время прокрутки стартера
  remoteStartCooldown   = 4.0,   -- сек, пауза перед вторым запуском
  -- Датчик удара
  shockThresholdWeak    = 1800,  -- импульс, слабый удар
  shockThresholdStrong  = 6000,  -- импульс, сильный удар
  shockAccelWeak        = 5.0,   -- м/с², толчок кузова
  shockAccelStrong      = 8.0,   -- м/с², отчётливый удар кузова
  shockBeamEnergy       = 500,   -- Дж, разрушение силового элемента
  shockCooldown         = 0.45,  -- сек, антидребезг; три удара успевают в окно
  shockAccumWindow      = 2.5,   -- сек, окно накопления ударов
  shockAccumLimit       = 3,     -- ударов за окно -> тревога
  -- Безопасность
  maxSafeSpeedMps       = 0.6,   -- м/с, ~2 км/ч
  throttleAuthThreshold = 0.15,  -- доля нажатия газа без авторизации
  -- Car finder
  finderDuration        = 6.0,
  finderFlashPeriod     = 0.4,
}

local S = {
  DISARMED          = "DISARMED",
  ARMING            = "ARMING",
  ARMED             = "ARMED",
  ALARM             = "ALARM",
  REMOTE_STARTING   = "REMOTE_STARTING",
  REMOTE_RUNNING    = "REMOTE_RUNNING",
  WAIT_AUTH         = "WAIT_AUTH",
  RUNNING_AUTHORIZED= "RUNNING_AUTHORIZED",
  IMMOBILIZED       = "IMMOBILIZED",
  ERROR             = "ERROR",
}

local WHITELIST = {
  -- базовые
  arm = true, disarm = true, lock = true, unlock = true,
  trunk = true, find = true, remoteStart = true, stopEngine = true,
  alarmOff = true, status = true, authorize = true, setSensitivity = true,
  -- официальная схема четырёхкнопочного A93 (ТЗ §5)
  silentArm = true, silentDisarm = true, silentAlarmArm = true,
  shockSensitivityMode = true, tiltSensitivityMode = true, serviceMode = true,
  panic = true, panicOff = true,
  shockLevel = true, tiltLevel = true,
  requestState = true,
}

-- ============================================================
-- Состояние модуля
-- ============================================================

local state = S.DISARMED
local prevState = nil
local vehicleId = 0
local initDone = false
local parkStopRemaining = 0

local adapter = nil
local adapterReady = false

-- HUD state publishing and fob start confirmation are independent of the removed screen.
local uiPushTimer = 0
local fobStartExpires = 0
local START_BRAKE_CONFIRM = "remote_start_brake_confirmation"

-- Таймеры (сек, обратный отсчёт)
local timers = {
  alarmFlash = 0,
  alarmStop = 0,
  alarmLockout = 0,
  remoteStart = 0,
  remoteIgnitionDelay = 0,
  remoteCooldown = 0,
  finder = 0,
  shockCooldown = 0,
  shockAccum = 0,
  armPending = 0,
  armToArmed = 0,
  heartbeat = 0,
}

-- Индикация
local lastEngineRunning = false
local lastIgnition = 0

-- Датчик удара
local shockSensitivity = 1.0   -- 0.5 .. 2.0 (больше = чувствительнее)
local shockHits = {}
local lastShockMagnitude = 0
local shockAccelArmed = true
local shockBaselineX = nil
local shockBaselineY = nil
local shockBaselineZ = nil
-- sim-время контроллера (сек). os.clock в VLua не гарантирует монотонность
-- относительно паузы/перемотки; окно ударов ведём через dt из updateGFX.
local simTime = 0
local shockInhibitUntil = 0  -- игнор ударов до момента (grace после ARMED)

-- Авторизация
local authGranted = false
local immobilizeReason = nil

-- Датчики A93: уровни и блокировка кнопок брелка.
-- shockMode — официальный цикл 1 двойного (уровни датчика удара):
--   0 = датчик включён, 1 = предупредительный уровень выкл,
--   2 = оба уровня выкл. tiltEnabled — датчик наклона 3 двойным (off/on).
-- shockLevel/t shockSensitivity — чувствительность внутри включённого датчика.
local shockLevel = 1      -- 1 = низкий, 2 = средний, 3 = высокий
local shockMode = 0       -- 0/1/2 по официальной строке A93
local tiltEnabled = true  -- датчик наклона: 3 двойное = off/on
local tiltLevel = 1       -- legacy, оставлен для совместимости UI
local silentAlarmArmed = false  -- 1L+2S: бесшумная охрана (без сирены)
local shockAdjustMode = false   -- 3L+3S: режим регулировки чувствительности
local tiltAdjustMode = false
local serviceMode = false
local panicActive = false
local alarmCycles = 0     -- счётчик повторных циклов тревоги
local lastTrigger = nil   -- { reason, at }
local watchedZones = nil  -- последние известные состояния кузовных зон под охраной
local plateLight = require('controller/starlinePlateLight')
local welcomeLight = require('controller/starlineWelcomeLight')
local trunkLightOwned = false
local trunkLightSawOpen = false
local trunkLightDeadline = 0
local trustedTrunkOpen = false -- trunk opened by an authenticated fob command
local trustedTrunkSeenOpen = false -- wait for the latch to move before rearming
local trustedTrunkClosedSince = nil
local trustedTrunkDeadline = 0 -- abandon an accepted command if the lid never opens
local remoteStartReturnArmed = false -- restore the mode present before remote start

-- ============================================================
-- Логирование
-- ============================================================

local function logI(m) log("I", "starline_alarm", tostring(m)) end
local function logW(m) log("W", "starline_alarm", tostring(m)) end
local function logE(m) log("E", "starline_alarm", tostring(m)) end

local function msg(txt, ctx, ttl)
  if guihooks and guihooks.message then
    pcall(guihooks.message, {txt = tostring(txt), context = {}}, ttl or 3,
          ctx or "vehicle.starline_alarm")
  end
end

-- ============================================================
-- Адаптер
-- ============================================================

--[[
  Адаптер инициализируется повторно, пока состав машины не полный.

  Проверено по живому логу: первый init приходит раньше, чем появляются
  controller'ы защёлок дверей/багажника ETK 800:

      523.98  Didn't find controller 'door_FR_coupler' ...
      523.98  adapter | initialized: doors 1/4, trunk: none

  Старый код ставил adapterReady = true после единственной попытки, поэтому
  неполный набор кэшировался навсегда. Теперь adapter.init возвращает true
  только при полном наборе (4 двери + багажник); пока false — повторяем в
  updateGFX, но не чаще ADAPTER_RETRY_PERIOD.
]]
local ADAPTER_RETRY_PERIOD = 0.5
local adapterRetryTimer = 0

local function ensureAdapter(force)
  if adapterReady and not force then return adapter ~= nil end

  if not adapter then
    local model = type(vehiclePath) == "string" and vehiclePath:match("vehicles/([%w_%-]+)")
    local custom = nil
    if model then
      local customOk, candidate = pcall(require, "controller/starlineAdapter_" .. model)
      if customOk and type(candidate) == "table" and type(candidate.init) == "function" then
        custom = candidate
      end
    end
    local ok, mod = custom ~= nil, custom
    if not ok then ok, mod = pcall(require, "controller/vehicleAdapterUniversal") end
    if ok and type(mod) == "table" then
      adapter = mod
    else
      logE("adapter require failed: " .. tostring(mod))
      adapter = nil
      adapterReady = true
      return false
    end
  end

  local ok2, complete = pcall(adapter.init, nil)
  if not ok2 then
    logE("adapter.init failed: " .. tostring(complete))
    adapter = nil
    adapterReady = true
    return false
  end

  -- adapterReady = true только когда набор полный; иначе повторим позже.
  adapterReady = false -- rescan at a bounded interval; late-loaded latches are common
  return complete == true
end

--[[
  Привязка к GE-мосту выполняется ПОВТОРНО, а не один раз.

  Проверено по живому логу: M.init у машины вызывается один раз и после
  этого initDone = true. Мост же выгружается при смене игрового режима
  (unloadExcept(manualUnloadExtensions)) и при повторной активации мода,
  то есть уже ПОСЛЕ init. Прежняя привязка "один раз в init" к этому
  моменту бесполезна.

  Поэтому GE-привязка повторяется из updateGFX не чаще раза в 2 секунды.
  Сама привязка идёт через obj:queueGameEngineLua(...), потому что в
  Vehicle Lua таблица extensions — свой загрузчик VLua-модулей
  (lua/vehicle/main.lua:38), GE-расширений он не видит.
]]
local GE_BIND_PERIOD = 2.0
local geBindTimer = 0
local geBindCmd = nil

local function doGeBind(cmd)
  if not (obj and obj.queueGameEngineLua) then return false end
  local ok, err = pcall(function() obj:queueGameEngineLua(cmd) end)
  if not ok then
    logW("GE bridge bind failed: " .. tostring(err))
    return false
  end
  return true
end

-- GE-код привязки. Строится по требованию: vehicleId может стать известен
-- позже, чем произошла первая выгрузка моста, а также после reset.
local function makeGeBindCmd(id)
  return string.format([[
local __id = %d
local __b = extensions.starline_alarm_bridge
if not (__b and __b.registerAlarmVehicle) then
  pcall(extensions.load, "starline_alarm_bridge")
  __b = extensions.starline_alarm_bridge
end
if __b and __b.registerAlarmVehicle then
  pcall(__b.registerAlarmVehicle, __id)
else
  log("W", "starline_alarm", "GE bridge still unavailable for vehicleId=" .. tostring(__id))
end
]], id)
end

local function updateGeBind(dt)
  -- vehicleId выставляется в M.init; до этого привязывать нечего.
  if not geBindCmd then
    if not vehicleId or vehicleId == 0 then return end
    geBindCmd = makeGeBindCmd(vehicleId)
  end
  geBindTimer = geBindTimer + dt
  if geBindTimer < GE_BIND_PERIOD then return end
  geBindTimer = 0
  doGeBind(geBindCmd)
end

local function updateAdapterScan(dt)
  if adapterReady or not adapter then return end
  adapterRetryTimer = adapterRetryTimer + dt
  if adapterRetryTimer < ADAPTER_RETRY_PERIOD then return end
  adapterRetryTimer = 0
  ensureAdapter(true)
end

local function A(fn, default)
  if not adapter or type(adapter[fn]) ~= "function" then return default end
  local ok, v = pcall(adapter[fn])
  if not ok or v == nil then return default end
  return v
end

-- ============================================================
-- Свет / звук
-- ============================================================

--[[
  LightManager v2 — сценарный менеджер световых сигналов.

  Каждый сценарий — независимая запись:
    id        — уникальный идентификатор запуска (растёт)
    kind      — arm | disarm | trunk | find | remotestart | heartbeat | alarm
    cause     — причина запуска (для лога)
    priority  — чем больше, тем важнее
    startedAt — время запуска (секунды с запуска контроллера)
    blinks    — сколько вспышек
    on/off    — длительности фаз
    repeat    — true: сценарий повторяется, пока его не отменят

  Действует РОВНО ОДИН сценарий: тот, у которого выше priority.
  Сценарий с repeat=true не имеет предела по времени и обязан быть
  отменён тем же кодом, который его запустил (alarm -> alarmOff,
  heartbeat -> остановка дистанционного запуска). Это исключает
  бесконечное мигание: не-repeat сценарии всегда конечны.

  Почему нельзя просто электрику:
    lua/vehicle/electrics.lua:345 при ignitionLevel == 0 подключает
    european-override, который в updateGFXSecondStep (строка 486)
    каждый кадр обнуляет values.turnsignal/signal_L/signal_R/hazard,
    сбрасывает signalLeftState/signalRightState/signalWarnState
    и ставит generateBlinkPulseHandler = nop.
    Поэтому при выключенном зажигании АВАРИЙКА НЕ РАБОТАЕТ в принципе.
    Используется отдельный канал — см. lightChannel() ниже.
]]

local SCENARIO = {
  ARM        = { kind = "arm",         priority = 20 },
  DISARM     = { kind = "disarm",      priority = 20 },
  TRUNK      = { kind = "trunk",       priority = 20 },
  FIND       = { kind = "find",        priority = 30 },
  REMOTE     = { kind = "remotestart", priority = 40 },
  HEARTBEAT  = { kind = "heartbeat",   priority = 40 },
  ALARM      = { kind = "alarm",       priority = 100 },
}

-- ============================================================
-- OutputManager: единый владелец всех физических выходов.
-- Любой выход (свет/звук) меняется только отсюда.
-- startAlarmOutput / stopAlarmOutput / stopAllOutputs — единственные
-- точки включения тревожных выходов.
--
-- Forward-объявления: start/stopAlarmOutput стоят раньше определений
-- startScenario/stopScenario/cancelScenario/horn-функций. Без этого
-- ссылки внутри них резолвятся в ГЛОБАЛЬНЫЕ nil и reset() падает:
-- "attempt to call global 'stopScenario' (a nil value)".
-- ============================================================

local startScenario, stopScenario, cancelScenario
local playAlarmSound, stopAlarmSound, stopHorn, applyLight

local function startAlarmOutput(reason)
  -- Тревога: повторяющийся свет и автомобильная сирена.
  -- При бесшумной охране (silentAlarmArmed) звук подавляется,
  -- работают только световые выходы + оповещение на брелок.
  startScenario(SCENARIO.ALARM, "alarm:" .. tostring(reason),
    0, CFG.alarmFlashPeriod, CFG.alarmFlashPeriod, true)
  local unauthorized = lastTrigger and
    (lastTrigger.reason == "throttle_without_auth" or lastTrigger.reason == "movement_without_auth"
      or lastTrigger.reason == "unauthorized_start")
  if unauthorized or not silentAlarmArmed then
    playAlarmSound(not unauthorized)
  end
end

local function stopAlarmOutput(reason)
  cancelScenario("alarm", reason or "alarm_off")
  stopScenario(reason or "alarm_off")  -- снять любой остаток света
  stopHorn()
  stopAlarmSound()
  applyLight(false)
end

local function stopAllOutputs(reason)
  stopScenario(reason or "stop_all")
  stopHorn()
  stopAlarmSound()
  applyLight(false)
  -- Preserve any hazard state selected by the driver.
  timers.heartbeat = 0
  timers.finder = 0
  timers.alarmStop = 0
end

local lightMgr = {
  active   = nil,   -- текущий сценарий
  nextId   = 0,     -- счётчик идентификаторов
  timer    = 0,     -- время текущей фазы
  lit      = false, -- свет сейчас включён
  left     = 0,     -- осталось фаз у конечного сценария
  channel  = nil,   -- канал управления светом (adapter)
}

local function logLight(msg)
  logI("light: " .. tostring(msg))
end

-- Расширение передаёт этот импульс в штатный расчёт света после
-- обработки выключенного зажигания, перед сглаживанием яркости.
applyLight = function(on)
  local v = (on == true) and 1 or 0
  _G.starline_alarm_flash = v
  -- 1) mod-owned ключ: переживает ignition-off override
  local ok1 = pcall(function() electrics.values.alarm_flash = v end)
  -- The standard turn signals remain under driver control.
  -- Do not toggle the driver's hazard switch.
  if not ok1 then
    logW("alarm_flash write failed")
  end
end

local function selectLightChannel()
  -- Канал один: mod-owned ключ alarm_flash + штатная аварийка как
  -- дополнение при включённом зажигании. Отдельного lightAdapter
  -- больше нет (переменная была неинициализирована — мёртвый код).
  lightMgr.channel = "alarm_flash"
  logLight("channel = alarm_flash (ignition independent)")
end

stopScenario = function(reason)
  if lightMgr.active then
    logLight(string.format("stop id=%d kind=%s (%s)",
      lightMgr.active.id, lightMgr.active.kind, tostring(reason or "")))
  end
  applyLight(false)
  lightMgr.active = nil
  lightMgr.lit = false
  lightMgr.timer = 0
  lightMgr.left = 0
end

-- Запуск сценария. Возвращает id.
startScenario = function(spec, cause, blinks, on, off, repeatForever)
  local cur = lightMgr.active
  if cur and cur.priority > spec.priority then
    logLight(string.format("skip kind=%s: active %s has priority %d",
      spec.kind, cur.kind, cur.priority))
    return false
  end
  -- Ardente uses a six-stage lightbar sequence lasting 0.5 s. A shorter
  -- pulse cuts it off before the outer segments become visible.
  if controller.getController and
      (controller.getController("sequentialSignal_L") or
       controller.getController("sequentialSignal_R")) then
    on = math.max(on or 0.22, 0.55)
    off = math.max(off or 0.24, 0.45)
  end
  stopScenario("replaced by " .. spec.kind)
  lightMgr.nextId = lightMgr.nextId + 1
  lightMgr.active = {
    id        = lightMgr.nextId,
    kind      = spec.kind,
    cause     = cause,
    priority  = spec.priority,
    blinks    = blinks or 2,
    on        = on or 0.22,
    off       = off or 0.24,
    repeatF   = repeatForever == true,
  }
  -- left считаем в фазах: каждое "включить" уменьшает на 1.
  lightMgr.left = lightMgr.active.repeatF and -1 or lightMgr.active.blinks
  lightMgr.timer = 0
  lightMgr.lit = true
  applyLight(true)
  logLight(string.format("start id=%d kind=%s cause=%s blinks=%s repeat=%s",
    lightMgr.active.id, spec.kind, tostring(cause),
    lightMgr.active.repeatF and "forever" or tostring(lightMgr.active.blinks),
    tostring(lightMgr.active.repeatF)))
  return lightMgr.active.id
end

cancelScenario = function(kind, reason)
  if lightMgr.active and lightMgr.active.kind == kind then
    stopScenario(reason or ("cancel " .. kind))
    return true
  end
  return false
end

local function isScenarioActive(kind)
  return lightMgr.active ~= nil and lightMgr.active.kind == kind
end

local function updateLightManager(dt)
  local a = lightMgr.active
  if not a then return end
  lightMgr.timer = lightMgr.timer + dt
  if lightMgr.lit then
    if lightMgr.timer >= a.on then
      lightMgr.timer = lightMgr.timer - a.on
      lightMgr.lit = false
      applyLight(false)
      if lightMgr.left > 0 then
        lightMgr.left = lightMgr.left - 1
        if lightMgr.left <= 0 and not a.repeatF then
          stopScenario("completed")
        end
      end
    end
  else
    if lightMgr.timer >= a.off then
      lightMgr.timer = lightMgr.timer - a.off
      lightMgr.lit = true
      applyLight(true)
    end
  end
end

-- Legacy-алиас: полная очистка всех выходов через OutputManager.
local function stopAllLights(reason)
  stopAllOutputs(reason or "stopAllLights")
end

-- Единый звуковой менеджер (одна реализация; дубликатов нет).
-- Подтверждено по исходникам 0.40.4:
--   electrics.horn(state) — единственный штатный lifecycle клаксона
--   (electrics.lua:1034-1052, playSFX/stopSFX). Писать напрямую в
--   electrics.values.horn бессмысленно: значение каждый кадр
--   перезаписывается из hornState (:435) и обнуляется override при
--   ignition=0 (:311). У стоковой гражданской ETK 800 soundscape
--   "horn"/"siren" в JBeam нет (siren — только полицейские), поэтому
--   честно используем horn-пульс; это НЕ полноценная сирена.
local hornTimer = 0
local hornPulsesLeft = 0
local HORN_PULSE_ON = 0.22
local HORN_PULSE_OFF = 0.18
local hornPhaseOn = false

-- Разные короткие записи постановки и снятия звучат у самой машины.
local CONFIRM_SOUNDS = {
  arm = {path = "/art/sound/starline_alarm/lock.wav", duration = 0.513},
  disarm = {path = "/art/sound/starline_alarm/unlock.wav", duration = 0.619}
}
local confirmSources = {}
local confirmActiveSource
local confirmTimeLeft = 0
local MECHANICAL_SOUNDS = {
  arm = {path = "/art/sound/starline_alarm/mechanical_lock.wav", duration = 0.45},
  disarm = {path = "/art/sound/starline_alarm/mechanical_unlock.wav", duration = 0.29}
}
local mechanicalSources = {}
local mechanicalActiveSource
local mechanicalTimeLeft = 0

local function playMechanicalLock(action)
  local sound = MECHANICAL_SOUNDS[action]
  if not sound then return end
  local ok, err = pcall(function()
    if mechanicalActiveSource then obj:cutSFX(mechanicalActiveSource) end
    if not mechanicalSources[action] then
      local node = sounds.refNode or sounds.engineNode or 0
      mechanicalSources[action] = assert(obj:createSFXSource2(
        sound.path, "AudioDefaultLoop3D", "starlineMechanical" .. action, node, 0))
    end
    local source = mechanicalSources[action]
    obj:cutSFX(source)
    obj:setVolume(source, 1)
    obj:playSFX(source)
    mechanicalActiveSource = source
    mechanicalTimeLeft = sound.duration
  end)
  if not ok then logW("mechanical lock sound failed: " .. tostring(err)) end
end

local function playConfirmation(action)
  local sound = CONFIRM_SOUNDS[action]
  if not sound then return end
  local ok, err = pcall(function()
    if confirmActiveSource then obj:cutSFX(confirmActiveSource) end
    if not confirmSources[action] then
      local node = sounds.refNode or sounds.engineNode or 0
      confirmSources[action] = assert(obj:createSFXSource2(
        sound.path, "AudioDefaultLoop3D", "starlineConfirm" .. action, node, 0))
    end
    local source = confirmSources[action]
    obj:cutSFX(source)
    obj:setVolume(source, 1)
    obj:playSFX(source)
    confirmActiveSource = source
    confirmTimeLeft = sound.duration
  end)
  if not ok then logW("confirmation sound failed: " .. tostring(err)) end
end

local function updateConfirmation(dt)
  if confirmActiveSource then
    confirmTimeLeft = confirmTimeLeft - dt
    if confirmTimeLeft <= 0 then
      pcall(function() obj:cutSFX(confirmActiveSource) end)
      confirmActiveSource = nil
      confirmTimeLeft = 0
    end
  end
  if mechanicalActiveSource then
    mechanicalTimeLeft = mechanicalTimeLeft - dt
    if mechanicalTimeLeft <= 0 then
      pcall(function() obj:cutSFX(mechanicalActiveSource) end)
      mechanicalActiveSource = nil
      mechanicalTimeLeft = 0
    end
  end
end

local function hornOff()
  pcall(electrics.horn, false)
  hornPhaseOn = false
end

local function playHorn()
  -- Клаксон остаётся только для поиска автомобиля и прочих старых действий.
  hornPulsesLeft = math.max(hornPulsesLeft, 1)
  if hornTimer <= 0 then
    hornTimer = HORN_PULSE_ON
    hornPhaseOn = true
    pcall(electrics.horn, true)
  end
end

local function playHornAlarm()
  hornPulsesLeft = -1 -- запасной сигнал при недоступности записи
  if hornTimer <= 0 then
    hornTimer = HORN_PULSE_ON
    hornPhaseOn = true
    pcall(electrics.horn, true)
  end
end

local ALARM_SOUND = "/art/sound/starline_alarm/alarm.wav"
local alarmSource

playAlarmSound = function(allowHornFallback)
  stopHorn()
  local ok, err = pcall(function()
    if not alarmSource then
      local node = sounds.refNode or sounds.engineNode or 0
      alarmSource = assert(obj:createSFXSource2(ALARM_SOUND, "AudioDefaultLoop3D", "starlineAlarmSiren", node, 0))
    end
    obj:cutSFX(alarmSource)
    obj:setVolume(alarmSource, 1)
    obj:playSFX(alarmSource)
  end)
  if not ok then
    logW("alarm siren failed: " .. tostring(err))
    if allowHornFallback ~= false then playHornAlarm() end
  end
end

stopAlarmSound = function()
  if alarmSource then pcall(function() obj:cutSFX(alarmSource) end) end
end

stopHorn = function()
  hornTimer = 0
  hornPulsesLeft = 0
  hornOff()
end

local function updateHorn(dt)
  if hornTimer > 0 then
    hornTimer = hornTimer - dt
    if hornTimer <= 0 then
      if hornPhaseOn then
        -- фаза "включено" закончилась -> пауза
        hornOff()
        if hornPulsesLeft > 0 then hornPulsesLeft = hornPulsesLeft - 1 end
        if hornPulsesLeft == 0 then
          hornTimer = 0
        elseif hornPulsesLeft > 0 or hornPulsesLeft == -1 then
          hornTimer = HORN_PULSE_OFF
        else
          hornTimer = 0
        end
      else
        -- пауза закончилась -> следующий импульс
        hornTimer = HORN_PULSE_ON
        hornPhaseOn = true
        pcall(electrics.horn, true)
      end
    end
  elseif hornPulsesLeft == -1 then
    -- тревожный режим без активного таймера (после паузы извне) — не стартуем сами
  end
end

-- ============================================================
-- Вспомогательные проверки
-- ============================================================

local function speedMps() return math.abs(A("getWheelspeed", 0)) end
local function parkedSafe() return A("getParkingBrake", 0) > 0.5 end
local function engineRunning() return A("isEngineRunning", false) == true end
local function ignitionLevel() return A("getIgnitionLevel", 0) end
local function throttle() return A("getThrottle", 0) end
local function doorsClosed() return A("allDoorsClosed", false) == true end

local function safeToStart()
  if speedMps() > CFG.maxSafeSpeedMps then return false, "car_moving" end
  if not doorsClosed() then return false, "doors_open_or_unavailable" end
  local hoodState = A("getHoodStateTable", {known = false})
  if hoodState and hoodState.open then return false, "hood_open" end
  return true
end

-- ============================================================
-- Смена состояния
-- ============================================================

local function needsAuthorizationInterlock()
  return not authGranted and
    (state == S.ARMING or state == S.ARMED or state == S.WAIT_AUTH
      or state == S.IMMOBILIZED
      or (state == S.ALARM and (not panicActive or engineInterlock.isActive())))
end

local function syncEngineInterlock()
  if needsAuthorizationInterlock() then
    engineInterlock.block()
  else
    engineInterlock.unblock()
  end
end

local function setState(newState, reason)
  if state == newState then return end
  fobStartExpires = 0
  prevState = state
  state = newState
  if newState == S.DISARMED or newState == S.RUNNING_AUTHORIZED then
    watchedZones = nil
    parkStopRemaining = 0
    A("unlockDoors", false)
  end
  logI(string.format("state %s -> %s (%s)", tostring(prevState), tostring(newState), tostring(reason or "")))
  -- немедленный пуш в UI
  uiPushTimer = CFG.uiPushInterval
end

-- ============================================================
-- Построение состояния для UI
-- ============================================================

local function doorInfo()
  local raw = A("getDoorStates", {}) or {}
  local out = {}
  for id, d in pairs(raw) do
    out[id] = {
      known  = d.known == true,
      open   = d.open == true,
      closed = d.closed == true,
      label  = d.label,
    }
  end
  return out
end

local function trunkInfo()
  local t = A("getTrunkStateTable", {known = false}) or {known = false}
  return {
    known  = t.known == true,
    open   = t.open == true,
    closed = t.closed == true,
  }
end

local function openingZones()
  local zones = doorInfo()
  zones.hood = A("getHoodStateTable", {known = false})
  zones.trunk = trunkInfo()
  return zones
end

local fuelSample

local function vehicleTelemetry()
  local meters = electrics.values.odometer
  local telemetry = {outsideC=obj:getEnvTemperature() - 273.15}
  if type(meters) == "number" then telemetry.odometerKm = meters / 1000 end

  local liters, capacity = 0, 0
  for _, storage in pairs(energyStorage.getStorages()) do
    if storage.type == "fuelTank" and storage.capacity > 0 then
      liters = liters + storage.remainingVolume
      capacity = capacity + storage.capacity
    end
  end
  if capacity <= 0 then
    fuelSample = nil
    return telemetry
  end
  telemetry.fuelLiters = liters
  telemetry.fuelPercent = math.max(0, math.min(100, 100 * liters / capacity))

  if type(meters) == "number" then
    if not fuelSample or meters < fuelSample.lastMeters or liters > fuelSample.lastLiters + 0.5
      or capacity ~= fuelSample.capacity then
      fuelSample = {lastMeters=meters, lastLiters=liters, capacity=capacity, distance=0, used=0}
    end
    local traveled = meters - fuelSample.lastMeters
    if traveled > 0 then
      fuelSample.distance = fuelSample.distance + traveled
      fuelSample.used = fuelSample.used + math.max(0, fuelSample.lastLiters - liters)
    end
    fuelSample.lastMeters = meters
    fuelSample.lastLiters = liters
  end
  local measured = fuelSample and fuelSample.distance >= 500 and fuelSample.used >= 0.025
  local consumption = measured and 100000 * fuelSample.used / fuelSample.distance or 10
  telemetry.rangeMeasured = not not measured
  telemetry.rangeKm = liters * 100 / math.max(1, consumption)
  return telemetry
end

local function buildStateTable()
  local speed = speedMps()
  local eng = engineRunning()
  local ign = ignitionLevel()
  local st = {
    ts              = os.time(),
    alarmState      = state,
    previousState   = prevState,
    armed           = (state == S.ARMED or (state == S.ALARM and not panicActive)),
    alarm           = (state == S.ALARM),
    link            = true,           -- UI встроен в авто: связь есть
    remoteStarted   = (state == S.REMOTE_RUNNING or state == S.WAIT_AUTH),
    authRequired    = (state == S.WAIT_AUTH),
    immobilized     = (state == S.IMMOBILIZED),
    immobilizeReason= immobilizeReason,
    engineRunning   = eng,
    checkEngine     = engineInterlock.isActive() or electrics.values.checkengine == true or electrics.values.checkengine == 1,
    engineInterlock = engineInterlock.isActive(),
    supportsEngineInterlock = engineInterlock.isSupported(),
    ignitionLevel   = ign,
    ignition        = (ign > 0),
    rpm             = A("getRPM", 0),
    telemetry       = vehicleTelemetry(),
    authorized      = authGranted,
    speedKmh        = speed * 3.6,
    parkingBrake    = (A("getParkingBrake", 0) > 0.5),
    remoteStartWarning = fobStartExpires > os.time() and not parkedSafe(),
    throttle        = throttle(),
    doors           = doorInfo(),
    trunk           = trunkInfo(),
    supportsDoors   = A("supportsDoors", false) == true,
    supportsTrunk   = A("supportsTrunk", false) == true,
    hood            = A("getHoodStateTable", {known = false}),
    supportsHood    = A("supportsHood", false) == true,
    supportsCentralLock = A("supportsCentralLock", false) == true,
    shockSensitivity= shockSensitivity,
    lastShock       = lastShockMagnitude,
    vehicleId       = vehicleId,
    finderActive    = timers.finder > 0,
    -- Состояние официальной схемы A93
    remoteRunLeft   = math.floor((timers.remoteRun or 0)),
    shockLevel      = shockLevel,
    tiltLevel       = tiltLevel,
    shockMode       = shockMode,
    tiltEnabled     = tiltEnabled,
    tiltAdjustMode  = tiltAdjustMode,
    serviceMode     = serviceMode,
    shockAdjustMode = shockAdjustMode,
    silentAlarmArmed= silentAlarmArmed,
    panic           = panicActive,
    lastTrigger     = lastTrigger and lastTrigger.reason or nil,
    alarmZone       = state == S.ALARM and lastTrigger and lastTrigger.zone or nil,
    -- Центральный замок отделён от физического состояния дверей
    lock            = adapter and adapter.getLockStateTable and adapter.getLockStateTable() or nil,
  }
  return st
end

local function pushStateToBridge(st)
  if not (obj and obj.queueGameEngineLua) then return end
  if type(jsonEncode) ~= "function" then return end
  local ok, js = pcall(jsonEncode, st)
  if not ok or type(js) ~= "string" or js == "" then return end
  -- JSON uses double quotes; escape single quotes for the Lua literal.
  js = js:gsub("'", "\\'")
  local code = "if extensions.starline_alarm_bridge and extensions.starline_alarm_bridge.onVehicleStateJson then pcall(extensions.starline_alarm_bridge.onVehicleStateJson, '" .. js .. "') end"
  pcall(function() obj:queueGameEngineLua(code) end)
end

local function pushUI(force)
  local st = buildStateTable()
  -- 2) GE bridge keeps the last state, so the HUD can render even while
  --    this vehicle Lua is not answering. VLua must NEVER touch
  --    extensions.starline_alarm_bridge directly: in the vehicle VM the
  --    extensions proxy only resolves lua/vehicle/extensions/, so every
  --    access logs 'extension unavailable' (lua/common/extensions.lua:517).
  --    Instead serialize with jsonEncode (common/utils.lua, preloaded in
  --    VLua) and hand the JSON to GE via queueGameEngineLua, where the
  --    bridge decodes it in onVehicleStateJson.
  pushStateToBridge(st)
end

-- Called from the HUD app on mount to obtain the current state immediately.
_G.starline_alarm_pushNow = function()
  if not initDone then return end
  pushUI(true)
end

-- ============================================================
-- Команды
-- ============================================================

-- Постановка блокирует ручки, сохраняя текущее положение дверей.
-- После подтверждения ARMING переходит в ARMED по таймеру.
local function requestWelcomeLight()
  obj:queueGameEngineLua(string.format(
    "local car = getObjectByID(%d); if car then local dark = require('ge/extensions/starline/alarm/darkness').isDark(car); log('I','kaifline.welcome','dark=' .. tostring(dark)); car:queueLuaCommand('_G.starline_alarm_welcomeLight(' .. tostring(dark == true) .. ')') end", vehicleId))
end

_G.starline_alarm_welcomeLight = function(dark)
  if state == S.DISARMED or state == S.RUNNING_AUTHORIZED then
    local started = welcomeLight.start(dark)
    logI('welcome: dark=' .. tostring(dark) .. ' started=' .. tostring(started)
      .. ' lights=' .. tostring(electrics.values.lights_state))
  end
end

local stopEngineHard

local function cmdArm(silent)
  if state == S.ARMED or state == S.ALARM or state == S.ARMING then
    return true, "already_armed"
  end
  if engineRunning() then
    if not parkedSafe() then return false, "parking_brake_required" end
    if speedMps() > CFG.maxSafeSpeedMps then return false, "vehicle_moving" end
    parkStopRemaining = 1
    stopAllOutputs("park_and_arm")
    timers.remoteStart, timers.remoteIgnitionDelay, timers.remoteRun, timers.heartbeat = 0, 0, 0, 0
    timers.remoteCooldown = CFG.remoteStartCooldown
    remoteStartReturnArmed = false
  end
  welcomeLight.stop()
  authGranted = false
  trustedTrunkOpen = false
  trustedTrunkSeenOpen = false
  trustedTrunkClosedSince = nil
  trustedTrunkDeadline = 0
  watchedZones = {}
  for id, zone in pairs(openingZones()) do
    if zone.known then watchedZones[id] = zone.closed == true end
  end
  setState(S.ARMING, "arm")
  syncEngineInterlock()
  A("lockDoors", false)
  timers.armPending = CFG.armDelay
  -- Обычная постановка снимает флаг бесшумной охраны.
  silentAlarmArmed = false
  -- A93: постановка = 1 световой + 1 звуковой сигнал.
  if not silent then
    stopHorn() -- не оставляем клаксон от предыдущей команды поиска
    if not A("nativeLockFeedback", false) then
      startScenario(SCENARIO.ARM, "arm", CFG.armFlashCount, 0.22, 0.22, false)
    end
    playConfirmation("arm")
    if not A("nativeLockFeedback", false) then playMechanicalLock("arm") end
  else
    if not A("nativeLockFeedback", false) then
      startScenario(SCENARIO.ARM, "arm_silent", 1, 0.10, 0.0, false)
    end
  end
  timers.armToArmed = CFG.armDelay
  msg(silent and "Охрана включена (бесшумно)" or "Охрана включена",
      "vehicle.starline_alarm.armed", 3)
  return true
end

-- При переходе в DISARMED восстанавливается штатное управление ручками.
local function cmdDisarm(silent, source)
  if state == S.DISARMED then
    A("unlockDoors", false)
    requestWelcomeLight()
    return true, "already_disarmed"
  end
  timers.alarmStop = 0
  timers.alarmFlash = 0
  panicActive = false          -- снятие с охраны всегда гасит панику
  silentAlarmArmed = false     -- обычное снятие снимает бесшумную охрану
  shockAdjustMode = false      -- выход из режима регулировки чувствительности
  -- Полная очистка тревожных выходов: свет + horn (иначе horn-пульс
  -- тревоги продолжался бы вечно). Heartbeat тоже снимается.
  stopAlarmOutput("disarm")
  timers.heartbeat = 0
  authGranted = false
  trustedTrunkOpen = false
  trustedTrunkSeenOpen = false
  trustedTrunkClosedSince = nil
  trustedTrunkDeadline = 0
  remoteStartReturnArmed = false
  immobilizeReason = nil
  setState(S.DISARMED, source or "disarm")
  requestWelcomeLight()
  syncEngineInterlock()
  -- A93: снятие = 2 световых + 2 звуковых сигнала.
  if not silent then
    if not A("nativeLockFeedback", false) then
      startScenario(SCENARIO.DISARM, "disarm", CFG.disarmFlashCount, 0.22, 0.22, false)
    end
    playConfirmation("disarm")
    if not A("nativeLockFeedback", false) then playMechanicalLock("disarm") end
  end
  msg((source == "native_keyless" or source == "keyless") and "Охрана выключена через Keyless"
      or (silent and "Охрана выключена (бесшумно)" or "Охрана выключена"),
      "vehicle.starline_alarm.disarmed", 3)
  return true
end

-- Явные команды блокировки ручек.
local function cmdLock()
  if A("lockDoors", false) ~= true then return false, "lock_unsupported" end
  if not A("nativeLockFeedback", false) then
    startScenario(SCENARIO.ARM, "lock", 1, 0.22, 0.22, false)
  end
  return true, "locked"
end

local function cmdUnlock()
  if state ~= S.DISARMED and state ~= S.RUNNING_AUTHORIZED then
    return false, "disarm_first"
  end
  if A("unlockDoors", false) ~= true then return false, "lock_unsupported" end
  requestWelcomeLight()
  if not A("nativeLockFeedback", false) then
    startScenario(SCENARIO.DISARM, "unlock", 1, 0.22, 0.22, false)
  end
  return true, "unlocked"
end

local function stopTrunkLight()
  trunkLightOwned, trunkLightSawOpen = false, false
  plateLight.update(false)
end

local function updateTrunkLight()
  if trunkLightOwned then
    local t = trunkInfo()
    if t.open then trunkLightSawOpen = true end
    if (trunkLightSawOpen and t.closed) or (not trunkLightSawOpen and simTime >= trunkLightDeadline) then
      trunkLightOwned, trunkLightSawOpen = false, false
    end
  end
  plateLight.update(trunkLightOwned)
end

local function cmdTrunk()
  local t = trunkInfo()
  if not t.known then return false, "trunk_unsupported" end
  if t.open then return false, "trunk_already_open" end
  if A("openTrunk", false) ~= true then return false, "trunk_failed" end
  -- The latch opens after the command returns. Keep the exemption through
  -- those initial closed frames, then rearm only after an open-close cycle.
  trustedTrunkOpen = true
  trustedTrunkSeenOpen = false
  trustedTrunkClosedSince = nil
  trustedTrunkDeadline = simTime + 8
  trunkLightOwned = true
  trunkLightSawOpen = false
  trunkLightDeadline = simTime + 8
  plateLight.update(true)
  startScenario(SCENARIO.TRUNK, "trunk", 2, 0.22, 0.22, false)
  return true
end

local function cmdFind()
  timers.finder = CFG.finderDuration
  -- Поиск: ограниченное число вспышек, после завершения свет гаснет.
  startScenario(SCENARIO.FIND, "find",
    math.floor(CFG.finderDuration / CFG.finderFlashPeriod), 0.2, 0.2, false)
  msg("Поиск автомобиля", "vehicle.starline_alarm.finder", 2)
  return true
end

-- 1 длительно: если двигатель уже запущен дистанционно — ПРОДЛИТЬ работу
-- на 5 минут (как на реальном A93), иначе — запустить.
local HEARTBEAT_PERIOD = 10.0      -- две вспышки каждые 10 с при дистанционной работе без авторизации
local REMOTE_RUN_PERIOD = 300.0   -- 5 минут работы на одно продление

local function cmdRemoteStart()
  local now = os.time()
  if state == S.REMOTE_RUNNING or state == S.WAIT_AUTH then
    -- продление
    timers.remoteRun = (timers.remoteRun or 0) + REMOTE_RUN_PERIOD
    startScenario(SCENARIO.REMOTE, "remote_extend", 3, 0.18, 0.18, false)
    msg(string.format("Работа двигателя продлена на 5 мин (осталось %d мин)",
        math.floor(timers.remoteRun / 60)),
        "vehicle.starline_alarm.remote_extended", 3)
    logI(string.format("remote start extended: %.0f s left", timers.remoteRun))
    pushUI(true)
    return true, "extended"
  end
  if state == S.REMOTE_STARTING or state == S.RUNNING_AUTHORIZED then
    return false, "already_running"
  end
  if engineRunning() then return false, "engine_already_running" end
  if timers.remoteCooldown > 0 then return false, "cooldown" end
  local ok, why = safeToStart()
  if not ok then
    fobStartExpires = 0
    msg("Автозапуск невозможен: " .. tostring(why), "vehicle.starline_alarm.remote_start_failed", 4)
    return false, why
  end
  if not parkedSafe() and fobStartExpires <= now then
    fobStartExpires = now + 10
    return false, START_BRAKE_CONFIRM
  end
  authGranted = false
  remoteStartReturnArmed = (state == S.ARMED or state == S.ARMING)
  immobilizeReason = nil
  timers.remoteStart = CFG.remoteStartTimeout
  timers.remoteIgnitionDelay = 1.1
  timers.remoteRun = REMOTE_RUN_PERIOD
  setState(S.REMOTE_STARTING, "remote_start_request")
  engineInterlock.unblock() -- the starter cannot engage while isDisabled is true
  -- Три коротких мигания ДО запуска двигателя, как на реальном A93.
  startScenario(SCENARIO.REMOTE, "remote_start", 3, 0.18, 0.18, false)
  if lightMgr.active and lightMgr.active.cause == "remote_start" then
    local flashTime = lightMgr.active.blinks * lightMgr.active.on
      + (lightMgr.active.blinks - 1) * lightMgr.active.off + 0.1
    timers.remoteIgnitionDelay = math.max(timers.remoteIgnitionDelay, flashTime)
  end
  timers.heartbeat = HEARTBEAT_PERIOD
  -- Стартер включается после трёх вспышек (около 1.1 с).
  return true
end

--[[
  Остановка двигателя.

  Подтверждено по исходникам 0.40.4:
    electrics.setIgnitionLevel(0) -> controller.mainController.setEngineIgnition(false)
    + setStarter(false) (electrics.lua:348-370). Методы vehicleController —
    DOT-сигнатура setStarter(enabled)/setEngineIgnition(enabled), вызов с
    self (mc, false) ошибочно включал бы их (mc = truthy). mc.engine —
    локальна в vehicleController и не экспортируется: не использовать.
  Основной путь — electrics.setIgnitionLevel(0); страховка — dot-вызовы
  при наличии функций. Arcade-автостарт (combustionEngine:291-297) может
  повторно запросить ignition при газе — подавляется состоянием модуля.
]]
stopEngineHard = function()
  local mc = controller and controller.mainController
  if mc then
    if type(mc.setEngineIgnition) == "function" then
      pcall(mc.setEngineIgnition, false)
    end
    if type(mc.setStarter) == "function" then
      pcall(mc.setStarter, false)
    end
  end
  pcall(electrics.setIgnitionLevel, 0)
end

local function updateParkShutdown(dt)
  if parkStopRemaining <= 0 then return end
  parkStopRemaining = math.max(0, parkStopRemaining - dt)
  if parkStopRemaining == 0 then stopEngineHard() end
end

local function finishRemoteRun(reason)
  local rearm = remoteStartReturnArmed and not authGranted
  remoteStartReturnArmed = false
  setState(rearm and S.ARMED or S.DISARMED, reason)
  if rearm then
    if not A("scheduleRelock", false) then A("lockDoors", false) end
  end
  syncEngineInterlock()
  return rearm
end

local function cmdStopEngine()
  local wasRunning = engineRunning()
  if not (state == S.REMOTE_RUNNING or state == S.WAIT_AUTH
          or state == S.REMOTE_STARTING or state == S.RUNNING_AUTHORIZED
          or wasRunning) then
    return false, "not_running"
  end
  stopEngineHard()
  timers.remoteStart = 0
  timers.remoteIgnitionDelay = 0
  timers.remoteCooldown = CFG.remoteStartCooldown
  authGranted = false
  immobilizeReason = nil
  -- Остановка дистанционного запуска НЕМЕДЛЕННО прекращает
  -- периодическое мигание и любые тревожные выходы.
  stopAllOutputs("stop_engine")
  finishRemoteRun("stop_engine")
  msg("Двигатель остановлен", "vehicle.starline_alarm.engine_stopped", 3)
  pushUI(true)
  return true
end

-- Кнопка 1 во время тревоги: прервать сирену и свет, но НЕ снимать охрану.
-- Если активна «ПАНИКА», она выключается полностью и машина остаётся
-- в DISARMED: паника не является режимом охраны.
local function cmdAlarmOff()
  if state ~= S.ALARM then return false, "not_in_alarm" end
  local wasPanic = panicActive
  panicActive = false
  stopAlarmOutput("alarm_off")
  if wasPanic then
    timers.alarmLockout = CFG.alarmRearmLockoutTime
    setState(S.DISARMED, "panic_off")
    msg("ПАНИКА выключена", "vehicle.starline_alarm.panic_off", 3)
  else
    timers.alarmLockout = CFG.alarmRearmLockoutTime
    setState(S.ARMED, "alarm_acknowledged")
    msg("Сигналы тревоги прерваны", "vehicle.starline_alarm.alarm_acknowledged", 3)
  end
  logI("alarm off (wasPanic=" .. tostring(wasPanic) .. ")")
  pushUI(true)
  return true
end

local function cmdStatus()
  pushUI(true)
  return true, state
end

local function authorizationDisarmFeedback()
  timers.heartbeat = 0
  cancelScenario("heartbeat", "authorized")
  cancelScenario("remotestart", "authorized")
  if not A("nativeLockFeedback", false) then
    startScenario(SCENARIO.DISARM, "authorized_disarm", CFG.disarmFlashCount, 0.22, 0.22, false)
    playMechanicalLock("disarm")
  end
  playConfirmation("disarm")
  requestWelcomeLight()
end

local function cmdAuthorize()
  if state ~= S.WAIT_AUTH then
    authGranted = true
    if state == S.ARMING or state == S.ARMED or state == S.IMMOBILIZED then
      stopAllOutputs("authorized")
      setState(S.DISARMED, "authorized")
      authorizationDisarmFeedback()
    end
    immobilizeReason = nil
    syncEngineInterlock()
    pushUI(true)
    return true, "authorized"
  end
  authGranted = true
  remoteStartReturnArmed = false
  immobilizeReason = nil
  setState(S.RUNNING_AUTHORIZED, "authorized")
  authorizationDisarmFeedback()
  syncEngineInterlock()
  msg("Водитель авторизован", "vehicle.starline_alarm.authorized", 3)
  return true
end

-- Called only by the optional Keyless controller after GE has verified an
-- exterior handle press from a nearby player in walking mode. Unlocking here
-- precedes the game's own door-latch action in the same vehicle command queue.
function M.keylessHandlePress(zone)
  if not initDone or not ({FL=true, FR=true, RL=true, RR=true})[zone] then return false end
  -- Cars with a native Keyless/lock controller keep their own handle logic.
  if A("nativeLockFeedback", false) or not A("supportsCentralLock", false) then return false end
  if state == S.WAIT_AUTH then return cmdAuthorize() end
  if state == S.ARMING or state == S.ARMED or state == S.ALARM or state == S.IMMOBILIZED then
    return cmdDisarm(false, "keyless")
  end
  return false
end

function M.keylessHandleLock(zone)
  if not initDone or not ({FL=true, FR=true, RL=true, RR=true})[zone] then return false end
  if not A("supportsCentralLock", false) then return false end
  if state == S.DISARMED or state == S.RUNNING_AUTHORIZED or state == S.WAIT_AUTH
      or state == S.REMOTE_RUNNING then return cmdArm(false) end
  return false
end

local function cmdSetSensitivity(value)
  local v = tonumber(value)
  if not v then return false, "bad_value" end
  v = math.max(0.5, math.min(2.0, v))
  shockSensitivity = v
  return true, v
end

-- ============================================================
-- Дополнительные функции официальной схемы A93
-- ============================================================

-- 1+3 длительно: режим «ПАНИКА» — сирена и свет независимо от охраны.
local function cmdPanic()
  if panicActive then
    return false, "panic_already"
  end
  panicActive = true
  lastTrigger = { reason = "panic", at = os.time() }
  timers.alarmStop = CFG.alarmAutoStopTime
  setState(S.ALARM, "panic")
  -- Паника повторяется только пока активна: снимается в cmdAlarmOff /
  -- истечением таймера alarmStop (см. updateSafety).
  startAlarmOutput("panic")
  msg("ПАНИКА", "vehicle.starline_alarm.panic", 4)
  pushUI(true)
  return true
end

-- 1L+2S: бесшумная охрана — без тревожных звуковых сигналов,
-- оповещение только на брелок. Звук тревоги подавляется флагом,
-- световые выходы работают как обычно.
local function cmdSilentAlarmArm()
  local ok, res = cmdArm(true)
  if ok then silentAlarmArmed = true end
  msg("Бесшумная охрана включена", "vehicle.starline_alarm.silent_alarm", 3)
  logI("silent alarm arm -> " .. tostring(res))
  pushUI(true)
  return ok, res
end

-- 3L+3S: режим регулировки чувствительности датчика удара.
-- Значение меняется кнопками 2/3 брелка (команда setSensitivity),
-- здесь только вход в режим и индикация текущего значения.
local function cmdShockSensitivityMode()
  -- повторный вход выходит из режима
  if shockAdjustMode then
    shockAdjustMode = false
    msg("Режим чувствительности выключен", "vehicle.starline_alarm.shock_adjust", 3)
    logI("shock adjust mode off")
    pushUI(true)
    return true, shockSensitivity
  end
  shockAdjustMode = true
  msg("Режим чувствительности: кнопки 2/3 меняют уровень (0.5–2.0), сейчас "
      .. string.format("%.1f", shockSensitivity),
      "vehicle.starline_alarm.shock_adjust", 4)
  logI("shock adjust mode on, level=" .. tostring(shockSensitivity))
  pushUI(true)
  return true, shockSensitivity
end

local function cmdTiltSensitivityMode()
  tiltAdjustMode = not tiltAdjustMode
  shockAdjustMode = false
  msg(tiltAdjustMode and ("Наклон: уровень " .. tiltLevel .. ", кнопки 2/3")
      or "Настройка наклона закрыта", "vehicle.starline_alarm.tilt_adjust", 3)
  pushUI(true)
  return true, tiltLevel
end

local function cmdServiceMode()
  if not serviceMode and state ~= S.DISARMED then return false, "disarm_first" end
  serviceMode = not serviceMode
  shockAdjustMode = false
  tiltAdjustMode = false
  msg(serviceMode and "Сервисный режим включён" or "Сервисный режим выключен",
      "vehicle.starline_alarm.service_mode", 3)
  pushUI(true)
  return true, serviceMode
end

-- 1 двойное: официальный цикл уровней датчика удара A93:
-- «предупредительный off → оба уровня off → датчик on».
-- Это НЕ регулировка чувствительности (она — отдельный режим 3L+3S).
local function cmdShockLevel()
  shockMode = (shockMode + 1) % 3
  local names = { "датчик удара включён", "предупредительный уровень выкл", "датчик удара выкл" }
  msg(names[shockMode + 1], "vehicle.starline_alarm.shock_level", 3)
  logI("shock mode -> " .. tostring(shockMode))
  pushUI(true)
  return true, shockMode
end

-- 3 двойное: отключение/включение датчика наклона (официальная строка A93).
local function cmdTiltLevel()
  tiltEnabled = not tiltEnabled
  msg(tiltEnabled and "Датчик наклона включён" or "Датчик наклона выключен",
      "vehicle.starline_alarm.tilt_level", 3)
  logI("tilt enabled -> " .. tostring(tiltEnabled))
  pushUI(true)
  return true, tiltEnabled
end

-- Центральный диспетчер: только whitelisted строки
function M.handleCommand(cmd, arg)
  if type(cmd) ~= "string" or not WHITELIST[cmd] then
    logW("rejected command: " .. tostring(cmd))
    return false, "invalid_command"
  end

  if serviceMode and (cmd == "arm" or cmd == "silentArm" or cmd == "silentAlarmArm"
      or cmd == "remoteStart") then return false, "service_mode" end

  if cmd ~= "remoteStart" and cmd ~= "status" and cmd ~= "requestState" then
    fobStartExpires = 0
    end
  local ok, res
  -- Короткая 1 во время тревоги (жест "1S" при state=ALARM): прервать
  -- сирену и свет, охрану НЕ снимать (обрабатывается контроллером,
  -- отдельного жеста в таблице кнопок нет).
  if cmd == "arm" and state == S.ALARM then
    ok, res = cmdAlarmOff()
    pushUI(true)
    return ok, res
  end
  -- Режим регулировки чувствительности (3L+3S): кнопки 2 (2S/disarm)
  -- и 3 (3S/status) меняют уровень вместо своих обычных действий.
  -- Выход: повторный 3L+3S, постановка/снятие, alarmOff.
  if shockAdjustMode then
    if cmd == "shockSensitivityMode" then ok, res = cmdShockSensitivityMode()
    elseif cmd == "status" then
      shockSensitivity = math.min(2.0, shockSensitivity + 0.25)
      msg("Чувствительность: " .. string.format("%.2f", shockSensitivity),
          "vehicle.starline_alarm.shock_adjust", 2)
      logI("shock sensitivity up -> " .. tostring(shockSensitivity))
      pushUI(true)
      return true, shockSensitivity
    elseif cmd == "disarm" then
      shockSensitivity = math.max(0.5, shockSensitivity - 0.25)
      msg("Чувствительность: " .. string.format("%.2f", shockSensitivity),
          "vehicle.starline_alarm.shock_adjust", 2)
      logI("shock sensitivity down -> " .. tostring(shockSensitivity))
      pushUI(true)
      return true, shockSensitivity
    elseif cmd == "silentAlarmArm" then ok, res = cmdSilentAlarmArm()
    elseif cmd == "alarmOff" then shockAdjustMode = false ok, res = cmdAlarmOff()
    else
      -- любая другая команда выходит из режима и выполняется обычно
      shockAdjustMode = false
      logI("shock adjust mode off (command " .. tostring(cmd) .. ")")
    end
    if ok ~= nil then pushUI(true) return ok, res end
  end
  if tiltAdjustMode then
    if cmd == "tiltSensitivityMode" then ok, res = cmdTiltSensitivityMode()
    elseif cmd == "status" or cmd == "disarm" then
      tiltLevel = math.max(1, math.min(3, tiltLevel + (cmd == "status" and 1 or -1)))
      msg("Наклон: уровень " .. tiltLevel, "vehicle.starline_alarm.tilt_adjust", 2)
      pushUI(true)
      return true, tiltLevel
    else tiltAdjustMode = false end
    if ok ~= nil then pushUI(true) return ok, res end
  end
  if cmd == "arm" then ok, res = cmdArm(false)
  elseif cmd == "disarm" then ok, res = cmdDisarm(false)
  elseif cmd == "silentArm" then ok, res = cmdArm(true)
  elseif cmd == "silentDisarm" then ok, res = cmdDisarm(true)
  elseif cmd == "silentAlarmArm" then ok, res = cmdSilentAlarmArm()
  elseif cmd == "shockSensitivityMode" then ok, res = cmdShockSensitivityMode()
  elseif cmd == "tiltSensitivityMode" then ok, res = cmdTiltSensitivityMode()
  elseif cmd == "serviceMode" then ok, res = cmdServiceMode()
  elseif cmd == "panic" then ok, res = cmdPanic()
  elseif cmd == "panicOff" then ok, res = cmdAlarmOff()
  elseif cmd == "shockLevel" then ok, res = cmdShockLevel()
  elseif cmd == "tiltLevel" then ok, res = cmdTiltLevel()
  elseif cmd == "requestState" then ok, res = cmdStatus()
  elseif cmd == "lock" then ok, res = cmdLock()
  elseif cmd == "unlock" then ok, res = cmdUnlock()
  elseif cmd == "trunk" then ok, res = cmdTrunk()
  elseif cmd == "find" then ok, res = cmdFind()
  elseif cmd == "remoteStart" then ok, res = cmdRemoteStart()
  elseif cmd == "stopEngine" then ok, res = cmdStopEngine()
  elseif cmd == "alarmOff" then ok, res = cmdAlarmOff()
  elseif cmd == "status" then ok, res = cmdStatus()
  elseif cmd == "authorize" then ok, res = cmdAuthorize()
  elseif cmd == "setSensitivity" then ok, res = cmdSetSensitivity(arg)
  end
  pushUI(true)
  return ok, res
end

-- Глобальные обёртки для GE-моста
_G.starline_alarm_handleCommand = function(cmd, arg)
  local ok, res = M.handleCommand(cmd, arg)
  return ok and "ok" or tostring(res)
end

_G.starline_alarm_getState = function()
  return state
end

-- ============================================================
-- Датчик удара
-- ============================================================

local function registerShock(impulse, weak, strong, source)
  if state ~= S.ARMED and state ~= S.ALARM then return end
  if simTime < shockInhibitUntil then return end
  if timers.alarmLockout > 0 then return end
  if timers.shockCooldown > 0 then return end
  if shockMode == 2 then return end  -- датчик полностью выключен
  local levelFactor = 1.0 + 0.5 * (shockLevel - 1)   -- 1.0 / 1.5 / 2.0
  local sens = shockSensitivity * levelFactor
  weak = weak / sens
  strong = strong / sens
  if shockMode == 1 then weak = strong end  -- предупредительный уровень выкл
  if impulse < weak then return end

  timers.shockCooldown = CFG.shockCooldown
  lastShockMagnitude = impulse
  lastShockMagnitude = math.floor(lastShockMagnitude)

  -- накопление слабых ударов (sim-время, не os.clock)
  local hits = {}
  for _, t in ipairs(shockHits) do
    if simTime - t <= CFG.shockAccumWindow then hits[#hits + 1] = t end
  end
  hits[#hits + 1] = simTime
  shockHits = hits

  local severe = impulse >= strong
  local accumulated = #hits >= CFG.shockAccumLimit
  logI(string.format("shock source=%s magnitude=%.1f strong=%s hits=%d",
    tostring(source or "unknown"), impulse, tostring(severe), #hits))

  if state == S.ARMED and (severe or accumulated) then
    M.triggerAlarm(severe and "shock_strong" or "shock_repeated")
  end
end

function M.nodeCollision(p)
  -- Постоянный контакт шин с дорогой даёт сотни normalForce-событий
  -- без удара. Учитываем только кузовной узел с входящей скоростью.
  if not p then return end
  local node = v and v.data and v.data.nodes and v.data.nodes[p.id1]
  if node and node.wheelID then return end
  if (tonumber(p.perpendicularVel) or 0) < 1.2 then return end
  -- p — transient-таблица из main.lua; использовать только внутри callback.
  local mag = tonumber(p and p.slipForce or 0) or 0
  local nf = tonumber(p and p.normalForce or 0) or 0
  registerShock(math.max(mag, nf), CFG.shockThresholdWeak, CFG.shockThresholdStrong, "body_collision")
end

function M.beamBroken(id, energy)
  -- BeamNG передаёт энергию разрушения в Дж; этот канал ловит удар,
  -- даже когда nodeCollision не выдаёт достаточной normalForce.
  local joules = tonumber(energy) or 0
  if joules >= CFG.shockBeamEnergy then
    registerShock(joules, CFG.shockBeamEnergy * 0.5, CFG.shockBeamEnergy, "beam_damage")
  end
end

local function updateShockSensor()
  if state ~= S.ARMED or not sensors then
    shockBaselineX, shockBaselineY, shockBaselineZ = nil, nil, nil
    shockAccelArmed = true
    return
  end
  local x, y = tonumber(sensors.gx2), tonumber(sensors.gy2)
  local z = tonumber(sensors.gz2)
  if not x or not y or not z then return end
  if not shockBaselineZ then
    shockBaselineX, shockBaselineY, shockBaselineZ = x, y, z
  end
  local accel = math.max(math.abs(x - shockBaselineX), math.abs(y - shockBaselineY),
    math.abs(z - shockBaselineZ),
    math.abs((tonumber(sensors.gx) or x) - shockBaselineX),
    math.abs((tonumber(sensors.gy) or y) - shockBaselineY),
    math.abs((tonumber(sensors.gz) or z) - shockBaselineZ))
  local rearm = CFG.shockAccelWeak * 0.55
  if accel < rearm then
    shockAccelArmed = true
    shockBaselineX = shockBaselineX * 0.995 + x * 0.005
    shockBaselineY = shockBaselineY * 0.995 + y * 0.005
    shockBaselineZ = shockBaselineZ * 0.995 + z * 0.005
  end
  if not shockAccelArmed or accel < CFG.shockAccelWeak then return end
  shockAccelArmed = false
  registerShock(accel, CFG.shockAccelWeak, CFG.shockAccelStrong, "body_acceleration")
end

function M.triggerAlarm(reason, zone)
  local unauthorized = reason == "throttle_without_auth" or reason == "movement_without_auth"
    or reason == "unauthorized_start"
  local remoteGuard = watchedZones and
    (state == S.REMOTE_STARTING or state == S.REMOTE_RUNNING or state == S.WAIT_AUTH)
  if state ~= S.ARMED and state ~= S.ALARM and not (zone and remoteGuard)
      and not (unauthorized and state == S.WAIT_AUTH) then return false end
  if timers.alarmLockout > 0 and not zone and not unauthorized then return false end
  if unauthorized then
    stopEngineHard()
    timers.remoteStart, timers.remoteIgnitionDelay, timers.remoteRun, timers.heartbeat = 0, 0, 0, 0
    timers.remoteCooldown = CFG.remoteStartCooldown
    authGranted = false
    immobilizeReason = reason
  end
  if zone and remoteGuard then
    stopEngineHard()
    timers.remoteStart, timers.remoteRun, timers.heartbeat = 0, 0, 0
  end
  lastTrigger = {reason = reason, zone = zone, at = os.time()}
  alarmCycles = 0
  setState(S.ALARM, reason)
  timers.alarmStop = CFG.alarmAutoStopTime
  timers.alarmFlash = 0
  -- Тревога мигает РОВНО столько, сколько активна: отменяется в
  -- cmdDisarm / cmdAlarmOff / истечении alarmStop. Повторные циклы
  -- ограничены alarmMaxCycles (см. updateSafety).
  startAlarmOutput(reason)
  local labels = {
    door_open = "открыта дверь", hood_open = "открыт капот", trunk_open = "открыт багажник",
    throttle_without_auth = "газ без авторизации", movement_without_auth = "движение без авторизации",
    unauthorized_start = "попытка запуска под охраной", shock_strong = "сильный удар",
    shock_repeated = "повторные удары"
  }
  msg("ТРЕВОГА: " .. (labels[reason] or tostring(reason)), "vehicle.starline_alarm.alarm", 6)
  pushUI(true)
  return true
end

local function watchOpenings()
  if not watchedZones or state == S.ARMING then return end
  local opened
  for id, zone in pairs(openingZones()) do
    if zone.known then
      if id == "trunk" and trustedTrunkOpen then
        if zone.open then
          trustedTrunkSeenOpen = true
          trustedTrunkClosedSince = nil
        elseif trustedTrunkSeenOpen and zone.closed then
          trustedTrunkClosedSince = trustedTrunkClosedSince or simTime
          if simTime - trustedTrunkClosedSince >= 1 and simTime >= trustedTrunkDeadline then
            trustedTrunkOpen = false
            trustedTrunkSeenOpen = false
            trustedTrunkClosedSince = nil
          end
        elseif not trustedTrunkSeenOpen and simTime >= trustedTrunkDeadline then
          trustedTrunkOpen = false
        end
      elseif watchedZones[id] == true and zone.open == true then
        opened = opened or id
      end
      watchedZones[id] = zone.closed == true
    end
  end
  if opened and state ~= S.ALARM then
    local reason = (opened == "hood" or opened == "trunk") and opened .. "_open" or "door_open"
    M.triggerAlarm(reason, opened)
  end
end

-- ============================================================
-- Инициализация / жизненный цикл
-- ============================================================

function M.init(jbeamData)
  if initDone then return end
  vehicleId = (obj and obj.getId and obj:getId()) or 0
  logI("init build=0.5.74, vehicleId=" .. tostring(vehicleId))

  ensureAdapter()

  --[[
    Регистрируем машину в GE-мосте и, если моста нет, ЗАГРУЖАЕМ ЕГО ЗАНОВО.

    Почему одного onInit в мосте недостаточно (проверено по живому логу):
        6.90  starline_alarm.bridge | loaded
        6.90  starline_alarm.bridge | unload mode registered: manual
        7.16  - starline_alarm_bridge :            (в списке загруженных)
        7.16  MPModManager.cleanUpSessionMods | Unloading extensions...
      523.98  extension unavailable: "starline_alarm_bridge"

    BeamMP при очистке сессии выгружает расширения по своему списку и не
    считается с manualUnloadExtensions. Снаружи это не отменить, поэтому
    Vehicle Lua сам восстанавливает связь: если расширения нет в _G,
    вызываем extensions.load(<имя>) — тот же путь, которым его грузит
    modScript. После этого мост снова получает команды брелка.
  ]]
  --[[
    Привязка машины к GE-мосту — ЧЕРЕЗ queueGameEngineLua.

    Почему не extensions.starline_alarm_bridge напрямую (проверено):
      В Vehicle Lua таблица extensions — это СВОЙ загрузчик
      (lua/vehicle/main.lua:38, require("extensions")), он видит только
      lua/vehicle/extensions/. GE-расширений там нет никогда, поэтому
      extensions.starline_alarm_bridge всегда nil, а extensions.load(...)
      ищет файл не в том дереве. Именно из-за этого прежняя "перезагрузка"
      моста молча не работала.

    Штатный путь VLua -> GE — obj:queueGameEngineLua("<lua-код>"),
    который исполняется в GE-контексте (пример: lua/vehicle/mapmgr.lua:65).
    Там extensions.starline_alarm_bridge — настоящий GE-модуль.

    В GE-коде проверяем наличие моста и при отсутствии загружаем его
    extensions.load("starline_alarm_bridge") — это безопасно в любой момент
    игры и переживает выгрузку при смене режима.
  ]]
  local bindCmd = string.format([[
local __id = %d
local __b = extensions.starline_alarm_bridge
if not (__b and __b.registerAlarmVehicle) then
  pcall(extensions.load, "starline_alarm_bridge")
  __b = extensions.starline_alarm_bridge
end
if __b and __b.registerAlarmVehicle then
  pcall(__b.registerAlarmVehicle, __id)
  log("I", "starline_alarm", "GE bridge bound to vehicleId=" .. tostring(__id))
else
  log("W", "starline_alarm", "GE bridge still unavailable for vehicleId=" .. tostring(__id))
end
]], vehicleId)

  geBindCmd = makeGeBindCmd(vehicleId)
  doGeBind(geBindCmd)
  logI("GE bridge bind requested: vehicleId=" .. tostring(vehicleId))

  state = S.DISARMED
  initDone = true
  pushUI(true)
end

function M.reset(jbeamData)
  parkStopRemaining = 0
  welcomeLight.stop()
  stopTrunkLight()
  plateLight.reset()
  fobStartExpires = 0
  fuelSample = nil
  engineInterlock.unblock()
  A("unlockDoors", false)
  A("reset")
  stopAllOutputs("reset")
  if confirmActiveSource then pcall(function() obj:cutSFX(confirmActiveSource) end) end
  confirmActiveSource = nil
  confirmTimeLeft = 0
  confirmSources = {}
  if mechanicalActiveSource then pcall(function() obj:cutSFX(mechanicalActiveSource) end) end
  mechanicalActiveSource = nil
  mechanicalTimeLeft = 0
  mechanicalSources = {}
  watchedZones = nil
  trustedTrunkOpen = false
  trustedTrunkSeenOpen = false
  trustedTrunkClosedSince = nil
  trustedTrunkDeadline = 0
  remoteStartReturnArmed = false
  tiltAdjustMode = false
  serviceMode = false
  _G.starline_alarm_flash = 0  -- сбросить флаг для fixup-расширения
  _G.starline_alarm_alive = nil
  for k in pairs(timers) do timers[k] = 0 end
  shockHits = {}
  lastShockMagnitude = 0
  shockAccelArmed = true
  shockBaselineX, shockBaselineY, shockBaselineZ = nil, nil, nil
  shockInhibitUntil = 0
  lastIgnition = 0
  lastEngineRunning = false
  authGranted = false
  immobilizeReason = nil
  adapterReady = false
  adapter = nil
  initDone = false
  state = S.DISARMED
  prevState = nil
  logI("reset")
end

function M.resetLastStage()
  -- повторная инициализация после ресета авто
  if not initDone then M.init(nil) end
end

local function updateIndicators(dt)
  -- Единственный владелец светового канала: сценарный LightManager.
  updateLightManager(dt)
  updateHorn(dt)
end

local function updateRemoteStart(dt)
  if state == S.REMOTE_STARTING then
    timers.remoteStart = timers.remoteStart - dt
    if timers.remoteIgnitionDelay > 0 then
      timers.remoteIgnitionDelay = timers.remoteIgnitionDelay - dt
      if timers.remoteIgnitionDelay <= 0 then
        timers.remoteIgnitionDelay = 0
        pcall(electrics.setIgnitionLevel, 3)
      end
    end
    if engineRunning() then
      timers.remoteStart = 0
      timers.remoteIgnitionDelay = 0
      -- Preserve access granted before the remote start request.
      authGranted = not remoteStartReturnArmed
      setState(authGranted and S.RUNNING_AUTHORIZED or S.WAIT_AUTH, "engine_started")
      syncEngineInterlock()
      -- Двигатель запущен дистанционно: короткое подтверждение, затем
      -- включается режим heartbeat (две вспышки каждые 10 с).
      startScenario(SCENARIO.REMOTE, "remote_engine_started", 2, 0.20, 0.20, false)
      timers.heartbeat = authGranted and 0 or HEARTBEAT_PERIOD
      msg(authGranted and "Двигатель запущен. Водитель авторизован" or "Двигатель запущен. Требуется авторизация", "vehicle.starline_alarm.wait_auth", 4)
    elseif timers.remoteStart <= 0 then
      timers.remoteIgnitionDelay = 0
      pcall(electrics.setIgnitionLevel, 0)
      timers.remoteCooldown = CFG.remoteStartCooldown
      cancelScenario("remotestart", "start_timeout")
      cancelScenario("heartbeat", "start_timeout")
      timers.heartbeat = 0
      finishRemoteRun("remote_start_timeout")
      msg("Автозапуск не удался", "vehicle.starline_alarm.remote_start_failed", 4)
    end
    return
  end

  -- Обратный отсчёт дистанционной работы двигателя (5 мин на запуск и на
  -- каждое продление кнопкой 1). Работает и в WAIT_AUTH, и в REMOTE_RUNNING.
  if state == S.WAIT_AUTH or state == S.REMOTE_RUNNING then
    -- Heartbeat: две короткие вспышки каждые HEARTBEAT_PERIOD секунд.
    -- Это НЕ бесконечный цикл: он живёт только пока движок работает
    -- дистанционно и снимается сразу при остановке/истечении/снятии.
    timers.heartbeat = timers.heartbeat - dt
    if timers.heartbeat <= 0 then
      timers.heartbeat = HEARTBEAT_PERIOD
      if not authGranted then
        startScenario(SCENARIO.HEARTBEAT, "remote_heartbeat", 2, 0.12, 0.12, false)
      end
    end
    if timers.remoteRun and timers.remoteRun > 0 then
      timers.remoteRun = timers.remoteRun - dt
      if timers.remoteRun <= 0 then
        timers.remoteRun = 0
        stopEngineHard()
        -- Периодическое мигание прекращается СРАЗУ при истечении.
        cancelScenario("heartbeat", "run_expired")
        cancelScenario("remotestart", "run_expired")
        timers.heartbeat = 0
        timers.remoteCooldown = CFG.remoteStartCooldown
        authGranted = false
        finishRemoteRun("remote_run_expired")
        msg("Время дистанционной работы истекло", "vehicle.starline_alarm.remote_expired", 4)
        logI("remote run period expired; engine stopped")
        pushUI(true)
        return
      end
    end
  end

  if state == S.WAIT_AUTH then
    -- Газ или движение до авторизации запускают штатную тревогу с сиреной.
    if throttle() > CFG.throttleAuthThreshold then
      M.triggerAlarm("throttle_without_auth")
      return
    end
    -- Движение без авторизации обрабатывается тем же сценарием.
    if speedMps() > CFG.maxSafeSpeedMps then
      M.triggerAlarm("movement_without_auth")
      return
    end
    if not engineRunning() then
      -- двигатель заглох сам
      cancelScenario("heartbeat", "engine_stopped")
      timers.heartbeat = 0
      finishRemoteRun("engine_stopped")
    end
    return
  end

  if state == S.IMMOBILIZED then
    -- повторный запуск заблокирован, пока не disarm/authorize
    if engineRunning() then
      pcall(electrics.setIgnitionLevel, 0)
    end
    return
  end

  if state == S.RUNNING_AUTHORIZED then
    if not engineRunning() then
      authGranted = false
      setState(S.DISARMED, "trip_end")
    end
  end
end

local function updateSafety(dt)
  -- обновление кулдаунов
  if timers.alarmLockout > 0 then timers.alarmLockout = timers.alarmLockout - dt end
  if timers.remoteCooldown > 0 then timers.remoteCooldown = timers.remoteCooldown - dt end
  if timers.shockCooldown > 0 then timers.shockCooldown = timers.shockCooldown - dt end
  if timers.finder > 0 then timers.finder = timers.finder - dt end

  if state == S.ARMED and not authGranted then
    -- Старт с ключа/кнопки под охраной. Автозапуск уже перевёл машину
    -- в REMOTE_STARTING, поэтому штатная команда не попадает в эту ветку.
    local ign = ignitionLevel()
    if parkStopRemaining <= 0 and ((ign > 0 and lastIgnition == 0) or (ign >= 2 and ign > lastIgnition)
        or (engineRunning() and not lastEngineRunning)) then
      M.triggerAlarm("unauthorized_start")
      return
    elseif throttle() > CFG.throttleAuthThreshold then
      M.triggerAlarm("throttle_without_auth")
      return
    elseif speedMps() > CFG.maxSafeSpeedMps then
      M.triggerAlarm("movement_without_auth")
      return
    end
  end

  if state == S.ALARM then
    timers.alarmStop = timers.alarmStop - dt
    if timers.alarmStop <= 0 then
      -- Конец цикла тревоги: выходы гасятся полностью.
      stopAlarmOutput("alarm_timeout")
      timers.alarmStop = 0
      alarmCycles = alarmCycles + 1
      if not (lastTrigger and lastTrigger.zone) and alarmCycles < CFG.alarmMaxCycles then
        -- Повторный цикл (датчик всё ещё видит причину): перезапуск.
        timers.alarmStop = CFG.alarmAutoStopTime
        startAlarmOutput("alarm_cycle_" .. tostring(alarmCycles + 1))
        logI("alarm cycle " .. tostring(alarmCycles + 1) .. "/" .. tostring(CFG.alarmMaxCycles))
      else
        -- Лимит циклов исчерпан: блокировка повторного срабатывания.
        timers.alarmLockout = CFG.alarmRearmLockoutTime
        setState(S.ARMED, "alarm_timeout")
      end
    end
  end

  -- ручник + выключение двигателя при ARMED (завершение поездки)
  if state == S.ARMED and parkStopRemaining <= 0 and engineRunning() then
    -- если двигатель ещё работает (не был выключен при постановке) — глушим
    pcall(electrics.setIgnitionLevel, 0)
  end
end

function M.updateGFX(dt)
  if not initDone then return end
  _G.starline_alarm_alive = os.time()
  dt = dt or 0
  -- защита от экстремальных dt
  if dt > 1 then dt = 1 end
  -- sim-время контроллера: окна датчика удара ведутся через dt,
  -- а не через os.clock (пауза/перемотка не должны ломать окно).
  simTime = simTime + dt
  if parkedSafe() then fobStartExpires = 0 end
  updateConfirmation(dt)

  -- Машина могла ещё не собрать защёлки дверей/багажника на момент M.init.
  -- Пока набор неполный — повторяем сканирование (не чаще 2 раз в секунду).
  updateAdapterScan(dt)
  if adapter and type(adapter.setRemoteAccess) == "function" then
    pcall(adapter.setRemoteAccess,
      state == S.REMOTE_STARTING or state == S.REMOTE_RUNNING or state == S.WAIT_AUTH)
  end
  if adapter and type(adapter.setAlarmGuarded) == "function" then
    pcall(adapter.setAlarmGuarded,
      state == S.ARMING or state == S.ARMED or state == S.ALARM
      or state == S.REMOTE_STARTING or state == S.REMOTE_RUNNING
      or state == S.WAIT_AUTH or state == S.IMMOBILIZED)
  end
  if adapter and type(adapter.updateGFX) == "function" then
    pcall(adapter.updateGFX, dt)
  end
  if state ~= S.DISARMED and state ~= S.RUNNING_AUTHORIZED
      and A("consumeAuthorizedUnlock", false) then
    if state == S.WAIT_AUTH then
      cmdAuthorize()
    else
      cmdDisarm(false, "native_keyless")
    end
  end
  updateGeBind(dt)

  updateParkShutdown(dt)
  updateSafety(dt)
  updateShockSensor()

  -- ARMING -> ARMED: постановка завершается по таймеру, без всякой тревоги.
  -- В момент перехода взводится grace-период: удары, вызванные самим
  -- закрытием дверей/капота, не должны поднимать тревогу.
  if state == S.ARMING then
    timers.armToArmed = timers.armToArmed - dt
    if timers.armToArmed <= 0 then
      timers.armToArmed = 0
      shockInhibitUntil = simTime + CFG.armGraceTime
      setState(S.ARMED, "arming_complete")
    end
  end

  watchOpenings()
  updateTrunkLight()
  welcomeLight.update(dt, speedMps())
  updateIndicators(dt)
  updateRemoteStart(dt)
  syncEngineInterlock()

  -- отложенная постановка: проверяем, что двери реально закрыты
  if timers.armPending > 0 then
    timers.armPending = timers.armPending - dt
    if timers.armPending <= 0 then
      timers.armPending = 0
      if not doorsClosed() and A("supportsDoors", false) then
        msg("Внимание: не все двери закрыты", "vehicle.starline_alarm.doors_open", 4)
      end
      if A("getHoodStateTable", {}).open then
        msg("Внимание: капот открыт", "vehicle.starline_alarm.hood_open", 4)
      end
      if A("getTrunkStateTable", {}).open then
        msg("Внимание: багажник открыт", "vehicle.starline_alarm.trunk_open", 4)
      end
    end
  end

  -- отслеживание перехода двигателя
  local eng = engineRunning()
  if eng ~= lastEngineRunning then
    lastEngineRunning = eng
    pushUI(true)
  end
  local ign = ignitionLevel()
  if ign ~= lastIgnition then
    lastIgnition = ign
    pushUI(true)
  end

  -- пуш в UI по таймеру
  uiPushTimer = uiPushTimer + dt
  if uiPushTimer >= CFG.uiPushInterval then
    uiPushTimer = 0
    pushUI(false)
  end
end

-- ============================================================
-- Публичный API
-- ============================================================

M.getState = function() return state end
M.isArmed = function() return state == S.ARMED or state == S.ALARM end
M.handleCommand = M.handleCommand

return M
