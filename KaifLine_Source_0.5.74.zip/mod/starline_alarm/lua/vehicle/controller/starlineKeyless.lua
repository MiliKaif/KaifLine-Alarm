-- Optional Keyless part. The GE trigger hook verifies the on-foot player and
-- exterior handle before it sends a press to this vehicle.
local M = {}
M.type = 'auxiliary'
local controller = require('controller')
local zones = {FL=true, FR=true, RL=true, RR=true}
local geRegisterTimer = 0

local function registerWithGE()
  if not (obj and obj.getId and obj.queueGameEngineLua) then return end
  local id = tonumber(obj:getId())
  if not id or id < 1 then return end
  obj:queueGameEngineLua(string.format(
    'if extensions.starline_alarm_keyless then extensions.starline_alarm_keyless.registerVehicle(%d) end', id))
end

-- Every JBeam controller is initialized and reset by BeamNG's controller
-- manager, even when it only exposes an event handler.
function M.init()
  geRegisterTimer = 0
  registerWithGE()
end
function M.reset()
  geRegisterTimer = 0
  registerWithGE()
end
function M.updateGFX(dt)
  geRegisterTimer = geRegisterTimer + (tonumber(dt) or 0)
  if geRegisterTimer >= 2 then
    geRegisterTimer = 0
    registerWithGE()
  end
end

function M.handlePress(zone)
  if not zones[zone] then return false end
  local alarm = controller.getControllerSafe('starlineAlarm')
  if not alarm or type(alarm.keylessHandlePress) ~= 'function' then return false end
  return alarm.keylessHandlePress(zone)
end

function M.handleLock(zone)
  if not zones[zone] then return false end
  local alarm = controller.getControllerSafe('starlineAlarm')
  if not alarm or type(alarm.keylessHandleLock) ~= 'function' then return false end
  return alarm.keylessHandleLock(zone)
end

return M
