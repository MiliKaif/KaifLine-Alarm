-- Isolate plate illumination from the shared exterior-light channels.
local M = {}
local bindings, materialBindings = {}, {}
local seenProps, seenMaterials = {}, {}
local active = false
local requestKey = 'kaifline_plate_request'
local function isPlate(value)
  if type(value) == 'string' then
    local name = value:lower():gsub('[^%w]', '')
    return name:find('license', 1, true) or name:find('plate', 1, true)
      or name:find('numberlight', 1, true)
  end
  if type(value) == 'table' then
    for _, item in pairs(value) do if isPlate(item) then return true end end
  end
  return false
end
local function discover()
  local data = v and v.data or {}
  local materials = data._materials
  local plateSources = {}
  for _, trigger in pairs(materials and materials.triggers or {}) do
    if isPlate(trigger.orgMat) or isPlate(trigger.off) or isPlate(trigger.on) then
      if type(trigger.simpleFunction) == 'table' then
        for source in pairs(trigger.simpleFunction) do plateSources[source] = true end
      elseif type(trigger.simpleFunction) == 'string' then
        plateSources[trigger.simpleFunction] = true
      end
      if not seenMaterials[trigger] and type(trigger.evalFunction) == 'function' then
        local original = trigger.evalFunction
        local function overlay() return math.max(tonumber(original()) or 0, active and 1 or 0) end
        materialBindings[#materialBindings + 1] = {trigger=trigger, original=original, overlay=overlay}
        trigger.evalFunction = overlay
        seenMaterials[trigger] = true
      end
    end
  end
  if #materialBindings > 0 and materials and materials.triggerList then
    local found = false
    for _, key in ipairs(materials.triggerList) do if key == requestKey then found = true end end
    if not found then materials.triggerList[#materials.triggerList + 1] = requestKey end
  end
  for _, prop in pairs(data.props or {}) do
    if not seenProps[prop] then
      local light = prop.lightBrightness or prop.lightRange
        or (type(prop.mesh) == 'string' and prop.mesh:lower():find('light', 1, true))
      -- Older cars label these small white spots only by a shared tailgate
      -- channel. Require a plate material on that channel and a short range.
      local color = prop.lightColor
      local white = not color or (color and tonumber(color.r) and tonumber(color.g) and tonumber(color.b)
        and math.min(color.r, color.g, color.b) >= math.max(color.r, color.g, color.b) * 0.65)
      local position = prop.baseTranslationGlobal
      local node = data.nodes and data.nodes[prop.idRef]
      local rearCenter = position and (tonumber(position.y) or 0) > 1
        and math.abs(tonumber(position.x) or math.huge) < 0.35
      if not position and node and node.pos then
        rearCenter = (tonumber(node.pos.y) or 0) > 1
          and math.abs(tonumber(node.pos.x) or math.huge) < 0.35
      end
      local sharedLowBeam = type(prop.func) == 'string' and prop.func:find('lowhighbeam', 1, true)
      local plateSpot = (plateSources[prop.func] or (rearCenter and sharedLowBeam)) and white
        and (tonumber(prop.lightRange) or math.huge) <= 0.6
      if light and (isPlate(prop.deformGroup) or isPlate(prop.breakGroup)
          or isPlate(prop.mesh) or isPlate(prop.func) or isPlate(prop.partOrigin) or plateSpot) then
        local key = 'kaifline_plate_light_' .. tostring(#bindings + 1)
        bindings[#bindings + 1] = {prop=prop, source=prop.func, key=key}
        prop.func = key
        seenProps[prop] = true
      end
    end
  end
end
function M.update(requested)
  active = requested == true
  discover()
  electrics.values[requestKey] = active and 1 or 0
  for _, binding in ipairs(bindings) do
    local value = electrics.values[binding.source]
    if type(value) == 'boolean' then value = value and 1 or 0 end
    electrics.values[binding.key] = math.max(tonumber(value) or 0, active and 1 or 0)
  end
end
function M.reset()
  active = false
  for _, binding in ipairs(bindings) do
    if binding.prop.func == binding.key then binding.prop.func = binding.source end
    electrics.values[binding.key] = nil
  end
  for _, binding in ipairs(materialBindings) do
    if binding.trigger.evalFunction == binding.overlay then binding.trigger.evalFunction = binding.original end
  end
  bindings, materialBindings, seenProps, seenMaterials = {}, {}, {}, {}
  electrics.values[requestKey] = 0
end
return M
