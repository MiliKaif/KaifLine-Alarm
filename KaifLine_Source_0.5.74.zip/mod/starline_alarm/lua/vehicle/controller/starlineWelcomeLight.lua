-- Own only parking lights switched on by this timer; preserve driver choices.
local M = {}
local duration = 30
local remaining = 0
local owned = false
local waiting = 0
local driving = false
local secondStepOriginal, secondStepWrapper
local function installIgnitionOffLightOverlay()
  if secondStepWrapper and electrics.updateGFXSecondStep == secondStepWrapper then return end
  if type(electrics.updateGFXSecondStep) ~= 'function' then return end
  secondStepOriginal = electrics.updateGFXSecondStep
  local original = secondStepOriginal
  secondStepWrapper = function(...)
    original(...)
    -- European electrics zero these outputs after controller.updateGFX().
    -- Restore only lighting; never bypass the rest of the ignition filter.
    if owned and (tonumber(electrics.values.ignitionLevel) or 0) == 0 then
      local values = electrics.values
      values.lights, values.lights_state = 1, 1
      values.parking = 1
      values.lowhighbeam, values.lowbeam = 1, 1
      values.lowhighbeam_signal_L, values.lowhighbeam_signal_R = 1, 1
      values.lowhighbeam_filament, values.lowbeam_filament = 1, 1
    end
  end
  electrics.updateGFXSecondStep = secondStepWrapper
end
local function removeIgnitionOffLightOverlay()
  if secondStepWrapper and electrics.updateGFXSecondStep == secondStepWrapper then
    electrics.updateGFXSecondStep = secondStepOriginal
  end
  -- Any wrapper installed by another mod keeps our inactive closure safely.
  secondStepOriginal, secondStepWrapper = nil, nil
end
function M.stop()
  local current = tonumber(electrics.values.lights_state)
  if owned and (current == nil or current == 0 or current == 1) then
    -- The ignition filter can report zero while the internal light switch
    -- remains on. Always reset that switch before releasing our overlay.
    electrics.setLightsState(0)
    local values = electrics.values
    for _, key in ipairs({'lights', 'lights_state', 'parking', 'lowhighbeam', 'lowbeam',
        'lowhighbeam_signal_L', 'lowhighbeam_signal_R', 'lowhighbeam_filament', 'lowbeam_filament'}) do
      values[key] = 0
    end
  end
  owned, remaining, waiting, driving = false, 0, 0, false
  removeIgnitionOffLightOverlay()
end
function M.start(dark)
  if not dark or type(electrics.setLightsState) ~= 'function' then return false end
  local current = tonumber(electrics.values.lights_state)
  if owned and current == 1 then remaining = duration; return true end
  if current == nil then current = 0 end
  if current ~= 0 then return false end
  installIgnitionOffLightOverlay()
  electrics.setLightsState(1)
  owned, remaining, waiting, driving = true, duration, 0.5, false
  return true
end
function M.update(dt, speedMps)
  if not owned then return end
  local current = tonumber(electrics.values.lights_state)
  if waiting > 0 then
    if current == 1 then
      waiting = 0
    elseif (current == 0 or current == nil) and waiting > (dt or 0) then
      waiting = waiting - math.max(0, dt or 0)
      return
    else
      waiting = 0
    end
  end
  if current ~= 1 then
    M.stop()
    return
  end
  if math.abs(tonumber(speedMps) or 0) > 0.5 then driving = true end
  if driving then return end -- keep the light on until manual change or locking
  remaining = remaining - math.max(0, dt or 0)
  if remaining <= 0 then M.stop() end
end
return M
