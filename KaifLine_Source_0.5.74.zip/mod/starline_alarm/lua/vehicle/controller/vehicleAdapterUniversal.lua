-- VehicleAdapter: discover latches by controller names and expose measured capabilities.
-- Optional vehicle-specific adapters can implement this interface and be selected by
-- starlineAlarm without changing AlarmCore.
local M = {}
local controller = require('controller')
local electrics = require('electrics')
local doors, trunk, hood = {}, nil, nil
local hoodLatches, trunkLatches = {}, {}
local doorLatches, guardedMethods = {}, {}
local locked = false
local doorActions = {'toggleGroup', 'toggleGroupConditional', 'detachGroup'}

local function stateOf(c)
  if not c or type(c.getGroupState) ~= 'function' then return nil end
  local ok, state = pcall(c.getGroupState, c)
  return ok and state or nil
end
local function describe(c)
  local state = stateOf(c)
  -- autoCoupling means the open latch is waiting for the door to return.
  local closed = state == 'attached'
  local open = state == 'detached' or state == 'desyncedDetached' or state == 'desyncedAttached'
    or state == 'broken' or state == 'coupling' or state == 'autoCoupling'
  return {state=state, known=state ~= nil, closed=closed, open=open}
end
local function describePanel(latches, fallback)
  if #latches == 0 then return describe(fallback) end
  local result = {known = true, open = false, closed = true}
  for _, latch in ipairs(latches) do
    local state = describe(latch)
    if state.open then return state end
    result.known = result.known and state.known
    result.closed = result.closed and state.closed
  end
  if result.closed then result.state = 'attached' end
  return result
end
local function allControllers()
  local ok, value = pcall(controller.getAllControllers)
  return ok and type(value) == 'table' and value or {}
end
local function guardDoor(c, allowClose)
  if guardedMethods[c] then return end
  local methods = {}
  for _, name in ipairs(doorActions) do
    local original = c[name]
    if type(original) == 'function' then
      local function blocked(...)
        local state = stateOf(c)
        if allowClose and name ~= 'detachGroup' and
            (state == 'detached' or state == 'desyncedDetached' or state == 'coupling'
             or state == 'autoCoupling' or state == 'broken') then
          return original(...)
        end
        return false
      end
      c[name] = blocked
      methods[name] = {original = original, blocked = blocked}
    end
  end
  if next(methods) then guardedMethods[c] = methods end
end

local doorPositions = {fl = 'FL', fr = 'FR', rl = 'RL', rr = 'RR',
  lf = 'FL', rf = 'FR', lr = 'RL', l = 'FL', r = 'FR'}

function M.init()
  doors, trunk, hood = {}, nil, nil
  hoodLatches, trunkLatches = {}, {}
  doorLatches = {}
  for name, c in pairs(allControllers()) do
    if type(name) == 'string' and type(c) == 'table' and type(c.getGroupState) == 'function' then
      local lower = name:lower()
      if lower:find('coupler', 1, true) then
        if lower:find('trunk', 1, true) or lower:find('tailgate', 1, true) or lower:find('liftgate', 1, true) then
          if not trunk then trunk = c end
          if not lower:find('catch', 1, true) then
            trunkLatches[#trunkLatches + 1] = c
            if #trunkLatches == 1 or not lower:find('upper', 1, true) then trunk = c end
          end
        elseif lower:find('hood', 1, true) or lower:find('bonnet', 1, true) then
          if not hood or lower:find('latch', 1, true) then hood = c end
          if not lower:find('catch', 1, true) then hoodLatches[#hoodLatches + 1] = c end
        elseif lower:find('door', 1, true) then
          local position = lower:match('^door[_%-]?([a-z]+)[_%-]')
            or lower:match('^door[_%-]?([a-z]+)coupler$')
          doors[doorPositions[position] or name] = c
          doorLatches[c] = true
          if locked then guardDoor(c) end
        end
      end
    end
  end
  if locked then
    for _, latch in ipairs(trunkLatches) do guardDoor(latch, true) end
    if trunk then guardDoor(trunk, true) end
  end
  return true
end
function M.reset()
  M.unlockDoors()
  doors, trunk, hood, doorLatches = {}, nil, nil, {}
  hoodLatches, trunkLatches = {}, {}
end
function M.isInitialized() return true end
function M.supportsDoors() return next(doors) ~= nil end
function M.supportsTrunk() return trunk ~= nil end
function M.supportsHood() return hood ~= nil end
function M.supportsCentralLock()
  for c in pairs(doorLatches) do
    for _, name in ipairs(doorActions) do
      if type(c[name]) == 'function' then return true end
    end
  end
  return false
end
function M.getDoorStates()
  local out = {}
  for id, c in pairs(doors) do out[id] = describe(c) end
  return out
end
function M.getTrunkStateTable() return describePanel(trunkLatches, trunk) end
function M.getHoodStateTable() return describePanel(hoodLatches, hood) end
function M.getTrunkState() return stateOf(trunk) or 'unsupported' end
function M.allDoorsClosed()
  if next(doors) == nil then return false end
  for _, c in pairs(doors) do if not describe(c).closed then return false end end
  return true
end
function M.anyDoorOpen()
  for _, c in pairs(doors) do if describe(c).open then return true end end
  return false
end
function M.openTrunk()
  if not trunk or type(trunk.detachGroup) ~= 'function' then return false end
  -- The authenticated alarm command bypasses the handle guard once.
  local methods = guardedMethods[trunk]
  local detach = methods and methods.detachGroup and methods.detachGroup.original or trunk.detachGroup
  return pcall(detach, trunk)
end
-- Stock interior and exterior handles dispatch these latch methods in Vehicle Lua.
function M.lockDoors()
  locked = true
  for c in pairs(doorLatches) do guardDoor(c) end
  for _, latch in ipairs(trunkLatches) do guardDoor(latch, true) end
  if trunk then guardDoor(trunk, true) end
  return next(guardedMethods) ~= nil
end
function M.unlockDoors()
  local supported = M.supportsCentralLock()
  for c, methods in pairs(guardedMethods) do
    for name, method in pairs(methods) do
      if c[name] == method.blocked then c[name] = method.original end
    end
  end
  guardedMethods = {}
  locked = false
  return supported
end
function M.getLockState()
  if not M.supportsCentralLock() then return 'UNSUPPORTED' end
  return locked and 'LOCKED' or 'UNLOCKED'
end
function M.getLockStateTable()
  local state = M.getLockState()
  return {state=state, locked=state == 'LOCKED', physical='unsupported'}
end
local function value(name, default)
  local v = electrics.values and electrics.values[name]
  return v == nil and default or v
end
function M.getIgnitionLevel() return tonumber(value('ignitionLevel', 0)) or 0 end
function M.isEngineRunning()
  local v = value('engineRunning', 0)
  return v == 1 or v == true
end
function M.getRPM() return tonumber(value('rpm', 0)) or 0 end
function M.getWheelspeed() return tonumber(value('wheelspeed', 0)) or 0 end
function M.getParkingBrake() return tonumber(value('parkingbrake', 0)) or 0 end
function M.getThrottle() return tonumber(value('throttle', 0)) or 0 end
return M
