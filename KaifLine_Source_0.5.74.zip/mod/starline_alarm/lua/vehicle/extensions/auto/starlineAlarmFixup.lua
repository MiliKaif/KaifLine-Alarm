local M = {}

local electrics = require("electrics")
local controller = require("controller")
local customValueParser = require("electricsCustomValueParser")
local stockUpdate
local stockElectricUpdate
local stockOctaviaBlinkersUpdate
local octaviaBlinkers
local wrappedOctaviaBlinkersUpdate

local function isOctavia()
  return type(vehiclePath) == 'string' and vehiclePath:match('vehicles/octavia4[/\\]') ~= nil
end

local function alarmAlive()
  local heartbeat = _G.starline_alarm_alive
  return heartbeat and os.time() - heartbeat <= 2
end

local function pulseActive()
  local flash = _G.starline_alarm_flash
  return (flash == 1 or flash == true) and alarmAlive()
end

local function hasSequentialSignals()
  return controller.getController("sequentialSignal_L") ~= nil
    or controller.getController("sequentialSignal_R") ~= nil
end

local function updateElectricValues(dt)
  stockElectricUpdate(dt)
  if pulseActive() and not isOctavia() then
    -- Controllers (including Ardente's sequential lightbar) run between
    -- electrics.updateGFX and updateGFXSecondStep. Feed them in that gap.
    electrics.values.signal_L = 1
    electrics.values.signal_R = 1
    if hasSequentialSignals() then
      -- Ardente resets its sequence when hazard_enabled changes.
      electrics.values.hazard_enabled = 1
    end
  end
end

local function updateCustomValues(dt)
  -- The ignition override has already run. Feed the pulse into the same
  -- JBeam expressions and smoothers as the stock turn signals.
  if pulseActive() and not isOctavia() then
    electrics.values.signal_L = 1
    electrics.values.signal_R = 1
  end
  return stockUpdate(dt)
end

local function addOctaviaPulse()
  if not isOctavia() or not pulseActive() then return end
  -- The Octavia's sequential lightbars read these dedicated channels.
  -- signal_L/R and hazard_enabled would run its ordinary hazard logic.
  local e = electrics.values
  e.octavia4SignalL = math.max(tonumber(e.octavia4SignalL) or 0, 1)
  e.octavia4SignalR = math.max(tonumber(e.octavia4SignalR) or 0, 1)
end

local function bindOctaviaBlinkers()
  if not isOctavia() then return end
  local blinker = rawget(_G, 'octavia4Blinkers')
  if type(blinker) ~= 'table' then return end
  if blinker == octaviaBlinkers and blinker.updateGFX == wrappedOctaviaBlinkersUpdate then return end
  if type(blinker.updateGFX) ~= 'function' then return end
  local original = blinker.updateGFX
  stockOctaviaBlinkersUpdate = original
  octaviaBlinkers = blinker
  wrappedOctaviaBlinkersUpdate = function(dt)
    original(dt)
    addOctaviaPulse()
  end
  blinker.updateGFX = wrappedOctaviaBlinkersUpdate
end

function M.onExtensionLoaded()
  if electrics.updateGFX ~= updateElectricValues then
    stockElectricUpdate = electrics.updateGFX
    electrics.updateGFX = updateElectricValues
  end
  if customValueParser.updateGFX ~= updateCustomValues then
    stockUpdate = customValueParser.updateGFX
    customValueParser.updateGFX = updateCustomValues
  end
  bindOctaviaBlinkers()
end

function M.onExtensionUnloaded()
  if octaviaBlinkers and octaviaBlinkers.updateGFX == wrappedOctaviaBlinkersUpdate then
    octaviaBlinkers.updateGFX = stockOctaviaBlinkersUpdate
  end
  if electrics.updateGFX == updateElectricValues then
    electrics.updateGFX = stockElectricUpdate
  end
  if customValueParser.updateGFX == updateCustomValues then
    customValueParser.updateGFX = stockUpdate
  end
end

function M.updateGFX()
  bindOctaviaBlinkers()
  addOctaviaPulse()
  if _G.starline_alarm_check_engine == 1 and alarmAlive() then
    -- Dashboard materials read this after the ignition-off override.
    electrics.values.checkengine = 1
  end
end

return M
