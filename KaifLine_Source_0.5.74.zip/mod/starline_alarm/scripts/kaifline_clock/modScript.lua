-- A separate mount script also runs when upgrading an already loaded alarm.
pcall(setExtensionUnloadMode, 'starline_alarm_clock', 'manual')
extensions.load('starline_alarm_clock')
