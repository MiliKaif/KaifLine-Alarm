-- This small hook has no state; reload it when a new archive is activated
-- so a running game uses the latest trigger logic without reloading the GE bridge.
pcall(extensions.unload, 'starline_alarm_keyless')
pcall(setExtensionUnloadMode, 'starline_alarm_keyless', 'manual')
extensions.load('starline_alarm_keyless')
