--[[
  modScript.lua
  Runs once when the mod is activated (modmanager executes every
  /scripts/**/modScript.lua found in the mounted mod).

  Job: load the GE extension that the HUD app and the in-vehicle keyfob use.

  Verified loader facts (lua/ge/main.lua, lua/common/extensions.lua):
    - extensions.addModulePath("lua/ge/extensions/")  -- require root
    - extensions.load(path) -> loadExt(path):
        * if the argument contains "/", it is used as the Lua path
          and extName = luaPathToExtName(path)  ('_' -> '__', '/' -> '_')
        * loadExt RETURNS NOTHING (no return value at all)
    - setExtensionUnloadMode(ext, mode) accepts a string name or a module
      table (main.lua:425); it only errors when the name is not a string.

  So for the file  lua/ge/extensions/starline/alarm/bridge.lua
    Lua path   = "starline/alarm/bridge"
    extName    = "starline_alarm_bridge"

  We pass the SLASH PATH to load, and the DERIVED NAME to
  setExtensionUnloadMode -- the return value of load is nil and must not be
  used (that was the bug that made the old script log a false "failed: nil"
  even though the module had loaded fine).
]]

local EXT_NAME = "starline_alarm_bridge"

pcall(setExtensionUnloadMode, 'starline_alarm_clock', 'manual')
extensions.load('starline_alarm_clock')
pcall(setExtensionUnloadMode, 'starline_alarm_keyless', 'manual')
extensions.load('starline_alarm_keyless')

--[[
  ПОЧЕМУ ИМЯ, А НЕ СЛЭШ-ПУТЬ (проверено по исходникам 0.40.4)

  modmanager при исполнении modScript подменяет extensions.load
  (lua/ge/extensions/core/modmanager.lua:721-737):

      extensions.load = function(module)
        if type(module) ~= 'string'
           or not explicitManualExtensions[module] then
          log('W', 'initDB.modScript',
              'Please make sure to call setExtensionUnloadMode(' .. ..
              ', "manual") to have this extension loaded properly.')
        end
        old_loadModule(module)
        setExtensionUnloadMode(module, "manual")
      end

  Проверка идёт по ТОМУ ЖЕ аргументу, что передан в load. Если передать
  слэш-путь "starline/alarm/bridge", а в manual зарегистрировать имя
  "starline_alarm_bridge", ключи не совпадут:
    - появится предупреждение modScript;
    - в manualUnloadExtensions попадёт слэш-путь, а реальное имя модуля
      (luaPathToExtName -> "starline_alarm_bridge") в нём не окажется;
    - unloadExcept(manualUnloadExtensions) выгрузит мост при смене
      игрового режима -> каждое обращение даёт
      "extension unavailable" и брелок перестаёт управлять машиной.

  По loadInternal (lua/common/extensions.lua:554-594) аргумент БЕЗ "/"
  трактуется как имя расширения и переводится в путь через
  extNameToLuaPath, поэтому extensions.load("starline_alarm_bridge")
  загружает lua/ge/extensions/starline/alarm/bridge.lua.

  Итог: имя в setExtensionUnloadMode и имя в extensions.load обязаны
  совпадать. Путь больше не используется.
]]

pcall(setExtensionUnloadMode, EXT_NAME, "manual")

local ok, err = pcall(extensions.load, EXT_NAME)

if ok then
  log("I", "starline_alarm", "modScript: extensions.load('" .. EXT_NAME .. "') ok")
else
  log("E", "starline_alarm", "modScript: extensions.load('" .. EXT_NAME .. "') failed: " .. tostring(err))
end
