/*
  app.js — HUD application "KaifLine keyfob"

  A PHYSICAL DEVICE rendering, not a HUD panel:
    - vertical black shell with silver rim and keyring
    - monochrome LCD with segment/pixel graphics
    - four side buttons: one red (#1), three dark (#2, #3, #4)
    - buttons visibly depress, LCD updates, short confirmation beep

  Input model per the official 4-button A93 manual:
    short        < 0.9 s
    long         >= 0.9 s (sequence starts on release)
    double       two short presses within 1 s
    sequence     long press, release, then short press of second button

  A finite state machine guarantees exactly one command per gesture.

  Command path (whitelist at every hop):
    gesture -> ACTIONS -> bngApi.engineLua(
      "extensions.starline_alarm_bridge.command('<name>')")
      -> GE bridge -> getObjectByID(id):queueLuaCommand(...)
      -> vehicle starlineAlarm.handleCommand(name)

  State path:
    vehicle -> guihooks.trigger("starlineAlarmState", st)
    and a 2 s poll of the bridge state as fallback.
    The UI never invents vehicle state.
*/

(function () {
  'use strict';

  // Wait for real RPM telemetry, then a continuous 500 ms at rest.
  function createDriveFeedback(play) {
    var vehicle = null, timer = null, notified = false;
    function cancel() { if (timer !== null) clearTimeout(timer); timer = null; }
    return {
      cancel: cancel,
      update: function (st) {
        if (vehicle !== st.vehicleId) { cancel(); vehicle = st.vehicleId; notified = false; }
        var authorized = st.authorized === true || st.alarmState === 'RUNNING_AUTHORIZED';
        if (st.link === false || !authorized) { cancel(); notified = false; return; }
        if (!(Number(st.speedKmh) > 2)) { cancel(); return; }
        if (notified || timer !== null) return;
        timer = setTimeout(function () { timer = null; notified = true; play(); }, 1000);
      }
    };
  }
  // End drive feedback helper.

  function createStopFeedback(play) {
    var vehicle = null, timer = null, expires = 0;
    function cancel() {
      if (timer !== null) clearTimeout(timer);
      timer = null; vehicle = null;
    }
    return {
      arm: function (id) { cancel(); vehicle = id; expires = Date.now() + 30000; },
      pending: function () { return vehicle !== null; },
      cancel: cancel,
      update: function (st) {
        if (vehicle === null) return;
        if (st.link === false || (st.vehicleId != null && st.vehicleId !== vehicle) || Date.now() >= expires) {
          cancel(); return;
        }
        var rpm = st.rpm == null ? NaN : Number(st.rpm);
        if (!isFinite(rpm) || rpm > 1 || rpm < 0 || st.engineRunning === true) {
          if (timer !== null) clearTimeout(timer);
          timer = null; return;
        }
        if (timer === null) timer = setTimeout(function () {
          cancel(); play();
        }, 500);
      }
    };
  }
  // End stop feedback helper.

  var SHORT_MAX_MS = 500;
  var LONG_MIN_MS = 900;
  var START_SEND_MS = 1800;
  var SERVICE_HOLD_MS = 4000;
  var MENU_HOLD_MS = 3000;
  var DOUBLE_WINDOW_MS = 1000;
  var SEQUENCE_GAP_MS = 900;
  var DEBOUNCE_MS = 220;
  var SOUND_MENU_MS = 8000;
  var SOUND_LABELS = ['БЕЗ ЗВУКА', 'ТИХО', 'ГРОМКО'];
  var SOUND_GAINS = [0, 0.011, 0.035];

  var STATE_TEXT = {
    DISARMED: 'СНЯТО',
    ARMING: 'ПОСТАНОВКА',
    ARMED: 'ОХРАНА',
    ALARM: 'ТРЕВОГА',
    REMOTE_STARTING: 'ЗАПУСК',
    REMOTE_RUNNING: 'ДВИГАТЕЛЬ',
    WAIT_AUTH: 'АВТОРИЗ.',
    RUNNING_AUTHORIZED: 'ПОЕЗДКА',
    IMMOBILIZED: 'БЛОК',
    ERROR: 'ОШИБКА'
  };

  // Translate only this app. Never mutate UIAppStorage or write game layouts.
  function installHudDrag(element) {
    var root = element && element[0];
    if (!root || !root.addEventListener) return function () {};
    var disposed = false, timer = null, remove = null, attempts = 0;
    function attach() {
      if (disposed) return;
      var item = root.closest('.overlay-item');
      if (item && root.closest('[data-app-instance]') && item.closest('.overlay__frame')) {
        remove = installMountedHudDrag(element);
        if (window.console) window.console.info("[KaifLine] HUD drag attached after DOM mount");
      } else if (++attempts < 100) {
        // Angular links a detached template, then the game appends it to its slot.
        timer = setTimeout(attach, 50);
      }
    }
    attach();
    return function () {
      disposed = true;
      if (timer !== null) clearTimeout(timer);
      if (remove) remove();
    };
  }

  function installMountedHudDrag(element) {
    var root = element && element[0];
    if (!root || !root.addEventListener) return function () {};
    var item = root.closest('.overlay-item');
    var host = root.closest('[data-app-instance]');
    var frame = item && item.closest('.overlay__frame');
    if (!item || !host || !frame) return function () {};
    var drag = null, saved = null, dx = 0, dy = 0, disposed = false, positionRevision = 0;
    var originalTransform = item.style.transform || '';
    function luaString(value) {
      var equals = '';
      while (value.indexOf(']' + equals + ']') !== -1) equals += '=';
      return '[' + equals + '[' + value + ']' + equals + ']';
    }
    function context() {
      var layout = window.UIAppStorage && window.UIAppStorage.current;
      if (!layout || !layout.apps || !layout.filename) return null;
      var name = host.getAttribute('data-app-name');
      var hosts = Array.prototype.filter.call(frame.querySelectorAll('[data-app-instance]'), function (node) {
        return node.getAttribute('data-app-name') === name;
      });
      var ordinal = hosts.indexOf(host), matches = [];
      layout.apps.forEach(function (entry, index) { if (entry.appName === name) matches.push(index); });
      return matches[ordinal] === undefined ? null : {layout:layout, index:matches[ordinal]};
    }
    function api() { return window.bngApi || (typeof bngApi !== 'undefined' && bngApi); }
    function call(method, ctx, extra, callback) {
      var bridge = api();
      if (bridge && ctx) {
        var target = 'extensions.starline_alarm_bridge.' + method;
        bridge.engineLua('(function() if extensions.starline_alarm_bridge and ' + target + ' then return ' + target + '(' +
          luaString(ctx.layout.filename) + ',' + ctx.index + (extra || '') + ') end end)()', callback);
      }
    }
    function translate(x, y) {
      dx = x; dy = y;
      item.style.transform = 'translate(' + x + 'px,' + y + 'px)' + (originalTransform ? ' ' + originalTransform : '');
    }
    function restore() {
      if (disposed || drag || !saved || item.classList.contains('is-editing')) return;
      var rect = item.getBoundingClientRect(), bounds = frame.getBoundingClientRect();
      if (!bounds.width || !bounds.height || !rect.width || !rect.height) return;
      var freeX = Math.max(0, bounds.width - rect.width), freeY = Math.max(0, bounds.height - rect.height);
      var baseX = rect.left - bounds.left - dx, baseY = rect.top - bounds.top - dy;
      translate(freeX * saved.left / 100 - baseX, freeY * saved.top / 100 - baseY);
    }
    function finish(cancel) {
      if (!drag) return;
      var current = drag;
      drag = null;
      root.classList.remove('skf-dragging');
      if (root.hasPointerCapture && root.hasPointerCapture(current.pointer)) root.releasePointerCapture(current.pointer);
      if (!current.moved) return;
      var ctx = context();
      if (cancel || !ctx || ctx.layout !== current.ctx.layout) {
        translate(current.dx, current.dy);
        return;
      }
      saved = {left:current.left, top:current.top};
      call('saveHudDragPosition', ctx, ',' + saved.left + ',' + saved.top);
    }
    function down(event) {
      if (event.button !== 0 || drag || !event.target.closest ||
          event.target.closest('.skf-btn, .skf-select-arrow, .skf-toolbar, .skf-settings') || item.classList.contains('is-editing')) return;
      var ctx = context();
      if (!ctx) return;
      var rect = item.getBoundingClientRect(), bounds = frame.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return;
      positionRevision++;
      drag = {pointer:event.pointerId, x:event.clientX, y:event.clientY, dx:dx, dy:dy,
        startLeft:rect.left - bounds.left, startTop:rect.top - bounds.top,
        freeX:Math.max(0, bounds.width - rect.width), freeY:Math.max(0, bounds.height - rect.height),
        ctx:ctx, moved:false};
      root.setPointerCapture(event.pointerId);
      event.preventDefault(); event.stopPropagation();
    }
    function move(event) {
      if (!drag || event.pointerId !== drag.pointer) return;
      var x = event.clientX - drag.x, y = event.clientY - drag.y;
      if (!drag.moved && Math.abs(x) + Math.abs(y) < 4) return;
      drag.moved = true;
      root.classList.add('skf-dragging');
      var left = Math.max(0, Math.min(drag.freeX, drag.startLeft + x));
      var top = Math.max(0, Math.min(drag.freeY, drag.startTop + y));
      drag.left = drag.freeX ? +(100 * left / drag.freeX).toFixed(4) : 0;
      drag.top = drag.freeY ? +(100 * top / drag.freeY).toFixed(4) : 0;
      translate(drag.dx + left - drag.startLeft, drag.dy + top - drag.startTop);
      event.preventDefault(); event.stopPropagation();
    }
    function up(event) { if (drag && drag.pointer === event.pointerId) finish(false); }
    function cancel() { finish(true); }
    function editChanged() {
      if (item.classList.contains('is-editing')) {
        cancel();
        if (saved) call('clearHudDragPosition', context());
        saved = null; dx = 0; dy = 0;
        item.style.transform = originalTransform;
      }
    }
    var observer = typeof MutationObserver !== 'undefined' ? new MutationObserver(editChanged) : null;
    if (observer) observer.observe(item, {attributes:true, attributeFilter:['class']});
    root.addEventListener('pointerdown', down);
    root.addEventListener('pointermove', move);
    root.addEventListener('pointerup', up);
    root.addEventListener('pointercancel', cancel);
    window.addEventListener('blur', cancel);
    window.addEventListener('resize', restore);
    var initial = context();
    call('getHudDragPosition', initial, '', function (position) {
      if (disposed || drag || positionRevision !== 0 || !position || typeof position.left !== 'number' || typeof position.top !== 'number'
        || !isFinite(position.left) || !isFinite(position.top) || position.left < 0 || position.left > 100
        || position.top < 0 || position.top > 100) return;
      saved = position; restore();
    });
    return function () {
      disposed = true; cancel();
      if (observer) observer.disconnect();
      item.style.transform = originalTransform;
      root.removeEventListener('pointerdown', down);
      root.removeEventListener('pointermove', move);
      root.removeEventListener('pointerup', up);
      root.removeEventListener('pointercancel', cancel);
      window.removeEventListener('blur', cancel);
      window.removeEventListener('resize', restore);
    };
  }

  var TEMPLATE = [
    "<div class=\"skf-root\" ng-class=\"{'skin-horizon':skf.skin === 'horizon'}\"><link rel=\"stylesheet\" href=\"/ui/modules/apps/starline_keyfob/app.css\">",
    "<div class=\"skf-toolbar\" ng-if=\"skf.skin === 'horizon' &amp;&amp; skf.vehicles.length > 1\">",
    "<div class=\"skf-horizon-selector\" ng-if=\"skf.skin === 'horizon' &amp;&amp; skf.vehicles.length > 1\"><button type=\"button\" ng-click=\"skf.cycleVehicle(-1)\" aria-label=\"{{skf.tr('Предыдущая машина')}}\">‹</button><span>{{skf.tr(skf.vehicleTitle)}}</span><button type=\"button\" ng-click=\"skf.cycleVehicle(1)\" aria-label=\"{{skf.tr('Следующая машина')}}\">›</button></div>",
    "</div>",
    "<section class=\"skf-settings\" ng-if=\"skf.settingsOpen\" role=\"dialog\" aria-label=\"{{skf.tr('Настройки')}}\">",
    "<div class=\"skf-settings-heading\"><strong>{{skf.tr('Настройки')}}</strong><button type=\"button\" ng-click=\"skf.toggleSettings()\" aria-label=\"{{skf.tr('Закрыть')}}\">×</button></div>",
    "<div class=\"skf-setting-row\"><span>{{skf.tr('Язык')}}</span><div class=\"skf-options\"><button type=\"button\" ng-class=\"{chosen:skf.language === 'ru'}\" ng-attr-aria-pressed=\"{{skf.language === 'ru'}}\" ng-click=\"skf.setLanguage('ru')\">Русский</button><button type=\"button\" ng-class=\"{chosen:skf.language === 'en'}\" ng-attr-aria-pressed=\"{{skf.language === 'en'}}\" ng-click=\"skf.setLanguage('en')\">English</button></div></div>",
    "<p class=\"skf-settings-note\">{{skf.preferenceMessage ? skf.tr(skf.preferenceMessage) : skf.tr('Сохраняется автоматически')}}</p></section>",
    "<svg xmlns=\"http://www.w3.org/2000/svg\" id=\"kh-horizon-fob\" viewBox=\"0 0 840 480\" preserveAspectRatio=\"xMidYMid meet\" role=\"img\" aria-label=\"Горизонтальный брелок KaifLine Horizon\" class=\"skf-svg skf-device skf-horizon\" ng-if=\"skf.skin === 'horizon'\" ng-class=\"{lit:skf.lit, alarm:skf.alarm, 'battery-low':skf.fobBattery &lt;= 15}\">",
    "<defs>",
    " <linearGradient id=\"kh-rim\" x1=\"0\" y1=\"0\" x2=\".8\" y2=\"1\"><stop stop-color=\"#b9c0bb\" /><stop offset=\".2\" stop-color=\"#66716e\" /><stop offset=\".48\" stop-color=\"#a6aeaa\" /><stop offset=\".7\" stop-color=\"#414c4a\" /><stop offset=\"1\" stop-color=\"#7c8782\" /></linearGradient>",
    " <linearGradient id=\"kh-shell\" x1=\".35\" y1=\"0\" x2=\".6\" y2=\"1\"><stop stop-color=\"#747c77\" /><stop offset=\".35\" stop-color=\"#505856\" /><stop offset=\"1\" stop-color=\"#343d3c\" /></linearGradient>",
    " <linearGradient id=\"kh-leftFacet\" x1=\"0\" y1=\"0\" x2=\"1\" y2=\"1\"><stop stop-color=\"#535d5a\" /><stop offset=\".48\" stop-color=\"#242e2e\" /><stop offset=\"1\" stop-color=\"#111a1c\" /></linearGradient>",
    " <linearGradient id=\"kh-chin\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#414b49\" /><stop offset=\"1\" stop-color=\"#2c3634\" /></linearGradient>",
    " <linearGradient id=\"kh-bezel\" x1=\"0\" y1=\"0\" x2=\".2\" y2=\"1\"><stop stop-color=\"#151d1c\" /><stop offset=\".35\" stop-color=\"#929d94\" /><stop offset=\".46\" stop-color=\"#141e1c\" /><stop offset=\"1\" stop-color=\"#8c9891\" /></linearGradient>",
    " <linearGradient id=\"kh-glass\" x1=\"0\" y1=\"0\" x2=\".85\" y2=\"1\"><stop stop-color=\"#101718\" /><stop offset=\".55\" stop-color=\"#1e292a\" /><stop offset=\"1\" stop-color=\"#333e3c\" /></linearGradient>",
    " <linearGradient id=\"kh-glassShine\"><stop stop-color=\"#dde9de\" stop-opacity=\".13\" /><stop offset=\"1\" stop-color=\"#dde9de\" stop-opacity=\"0\" /></linearGradient>",
    " <linearGradient id=\"kh-keyCap\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#5b6660\" /><stop offset=\".3\" stop-color=\"#35413c\" /><stop offset=\"1\" stop-color=\"#192723\" /></linearGradient>",
    " <linearGradient id=\"kh-segments\" x1=\"0\" y1=\"0\" x2=\"0\" y2=\"1\"><stop stop-color=\"#ffffff\" /><stop offset=\"1\" stop-color=\"#dce5df\" /></linearGradient>",
    " <clipPath id=\"kh-lcdClip\"><path d=\"M180 151C311 111 493 96 654 104Q670 105 677 122L711 201Q722 233 706 266L686 302Q682 309 673 309H253Q244 309 236 294L178 172Q171 157 180 151Z\" /></clipPath>",
    "</defs>",
    "<path d=\"M42 149C206 84 449 40 676 48L726 54C754 88 786 143 798 198Q811 251 789 309L756 397Q751 416 728 420H184C162 420 150 410 137 398L58 319Q30 294 28 261L30 179Q29 157 42 149Z\" fill=\"url(#kh-rim)\" stroke=\"#161f1d\" stroke-width=\"2\" />",
    "<path d=\"M47 156C211 92 450 47 675 55L722 61C750 96 778 146 791 202Q802 253 782 307L749 394Q744 410 724 412H186Q165 412 143 391L66 314Q39 289 37 258L39 179Q37 164 47 156Z\" fill=\"url(#kh-shell)\" stroke=\"#87928b\" stroke-width=\".9\" />",
    "<path d=\"M43 177L191 322L148 397L65 313Q40 287 38 258Z\" fill=\"url(#kh-leftFacet)\" stroke=\"#748179\" stroke-width=\".6\" />",
    "<path d=\"M191 322H777L748 394Q743 409 724 411H186Q168 411 148 397Z\" fill=\"url(#kh-chin)\" stroke=\"#56655e\" stroke-width=\"1\" />",
    "<path d=\"M50 156C214 92 451 48 675 55L651 73C453 65 273 102 172 127L156 119\" fill=\"none\" stroke=\"#c0c8be\" stroke-opacity=\".65\" stroke-width=\"2.1\" />",
    "<path d=\"M179 144C311 104 498 87 657 97Q676 98 685 119L719 198Q732 233 714 270L693 307Q688 318 675 318H250Q237 318 229 300L170 175Q159 151 179 144Z\" fill=\"url(#kh-bezel)\" stroke=\"#1a2421\" stroke-width=\"2\" />",
    "<path d=\"M180 151C311 111 493 96 654 104Q670 105 677 122L711 201Q722 233 706 266L686 302Q682 309 673 309H253Q244 309 236 294L178 172Q171 157 180 151Z\" fill=\"url(#kh-glass)\" />",
    "<g clip-path=\"url(#kh-lcdClip)\" class=\"lcd\">",
    " <rect class=\"backlight\" x=\"175\" y=\"100\" width=\"550\" height=\"215\" fill=\"#bed7bd\" opacity=\"0\" />",
    " <path d=\"M455 103L651 104Q669 104 678 123L712 204L665 309H590Z\" fill=\"url(#kh-glassShine)\" />",
    " <g class=\"display-content\">",
    " <svg width=\"14\" height=\"17\" viewBox=\"0 0 20 24\" fill=\"none\" id=\"kh-linkDot\" ng-class=\"{'guard-active': skf.linkOk &amp;&amp; skf.armed}\" x=\"209\" y=\"157\" data-figma-node=\"4:14\">",
    "<g id=\"kh-guardIndicator-1\">",
    "<path id=\"kh-guardIndicator-2\" d=\"M5 11V7C5 1 15 1 15 7V11M3 11H17V21H3V11Z\" stroke=\"#AEE749\" stroke-width=\"2.2\" stroke-linejoin=\"round\" />",
    "<path id=\"kh-guardIndicator-3\" d=\"M9.99995 14C9.52256 14 9.06472 14.1896 8.72716 14.5272C8.38959 14.8648 8.19995 15.3226 8.19995 15.8C8.19995 16.2774 8.38959 16.7352 8.72716 17.0728C9.06472 17.4104 9.52256 17.6 9.99995 17.6V19\" stroke=\"#AEE749\" stroke-width=\"1.5\" />",
    "</g>",
    "</svg><g id=\"kh-largeLock\"><svg width=\"76\" height=\"100\" viewBox=\"0 0 76 100\" fill=\"none\" id=\"kh-lockOpen\" x=\"229\" y=\"162\" data-figma-node=\"4:4\" ng-show=\"skf.linkOk && !skf.armed\">",
    "<g id=\"kh-lockOpen-1\">",
    "<path id=\"kh-lockOpen-2\" d=\"M55 47C76 29 59 1 36 12L26 17\" stroke=\"#E9EEE8\" stroke-width=\"5.8\" stroke-linecap=\"square\" />",
    "<path id=\"kh-lockOpen-3\" d=\"M13 47H63V85C63 88.3333 61.3333 90 58 90H17C13.6667 90 12 88.3333 12 85V48C12 47.3333 12.3333 47 13 47Z\" fill=\"url(#kh-lockOpen-6)\" stroke=\"#F0F4ED\" stroke-width=\"1.4\" />",
    "<path id=\"kh-lockOpen-4\" d=\"M38 58C31 58 29 67 35 70L33.5 80C36.5 82 39.5 82 42.5 80L41 70C47 66 45 58 38 58Z\" fill=\"#17231F\" />",
    "</g>",
    "<defs>",
    "<linearGradient id=\"kh-lockOpen-6\" x1=\"38\" y1=\"47\" x2=\"38\" y2=\"90\" gradientUnits=\"userSpaceOnUse\">",
    "<stop stop-color=\"#F1F5ED\" />",
    "<stop offset=\"1\" stop-color=\"#C7D0C8\" />",
    "</linearGradient>",
    "</defs>",
    "</svg><svg width=\"76\" height=\"100\" viewBox=\"0 0 76 100\" fill=\"none\" id=\"kh-lockClosed\" x=\"229\" y=\"162\" data-figma-node=\"4:9\" ng-show=\"skf.linkOk && skf.armed\">",
    "<g id=\"kh-lockClosed-1\">",
    "<path id=\"kh-lockClosed-2\" d=\"M22 47V30C22 8 55 8 55 30V47\" stroke=\"#E9EEE8\" stroke-width=\"5.8\" />",
    "<path id=\"kh-lockClosed-3\" d=\"M13 47H63V85C63 88.3333 61.3333 90 58 90H17C13.6667 90 12 88.3333 12 85V48C12 47.3333 12.3333 47 13 47Z\" fill=\"url(#kh-lockClosed-6)\" stroke=\"#F0F4ED\" stroke-width=\"1.4\" />",
    "<path id=\"kh-lockClosed-4\" d=\"M38 58C31 58 29 67 35 70L33.5 80C36.5 82 39.5 82 42.5 80L41 70C47 66 45 58 38 58Z\" fill=\"#17231F\" />",
    "</g>",
    "<defs>",
    "<linearGradient id=\"kh-lockClosed-6\" x1=\"38\" y1=\"47\" x2=\"38\" y2=\"90\" gradientUnits=\"userSpaceOnUse\">",
    "<stop stop-color=\"#F1F5ED\" />",
    "<stop offset=\"1\" stop-color=\"#C7D0C8\" />",
    "</linearGradient>",
    "</defs>",
    "</svg></g><text id=\"kh-voltage\" x=\"311\" y=\"183\" class=\"lcd-reading\">{{skf.voltageText}}</text>",
    " <svg width=\"50\" height=\"38\" viewBox=\"0 0 50 38\" fill=\"none\" id=\"kh-carBattery\" x=\"311\" y=\"197\" data-figma-node=\"4:18\">",
    "<g id=\"kh-carBattery-1\">",
    "<path id=\"kh-carBattery-2\" d=\"M2 7H48V35H2V7Z\" stroke=\"#E9EEE8\" stroke-width=\"2.6\" />",
    "<path id=\"kh-carBattery-3\" d=\"M8 1H15V7H8V1ZM35 1H42V7H35V1Z\" fill=\"#E9EEE8\" />",
    "<path id=\"kh-carBattery-4\" d=\"M10 21H22M16 15V27M31 21H41\" stroke=\"#E9EEE8\" stroke-width=\"3\" />",
    "</g>",
    "</svg><g id=\"kh-running\" transform=\"translate(318 243)\" fill=\"none\" stroke=\"#c5eca2\" stroke-width=\"2.7\" stroke-linecap=\"round\" stroke-linejoin=\"round\" ng-show=\"skf.linkOk && skf.engineRunning\"><path class=\"kh-engine-body\" d=\"M0 10H7L11 5H27L32 10H38V25H8L5 20H0V10ZM16 1H24M20 1V5M13 13H24M14 19H21\" /><g class=\"kh-exhaust-frame kh-frame-1\"><path d=\"M0 16C-5 13-7 14-10 16\" /></g><g class=\"kh-exhaust-frame kh-frame-2\"><path d=\"M0 16C-6 12-9 15-13 13C-16 12-18 14-19 16\" /></g><g class=\"kh-exhaust-frame kh-frame-3\"><path d=\"M0 16C-7 12-10 16-14 12C-18 9-20 13-23 11C-25 10-27 11-28 13\" /></g></g>",
    " <g class=\"clock\"><g class=\"digit\" data-digit=\"0\" transform=\"translate(377 161)\"><path data-segment=\"a\" ng-class=\"{on: skf.segmentOn(0, 'a')}\" d=\"M6 0H27L31 4L27 8H6L2 4Z\" /><path data-segment=\"b\" ng-class=\"{on: skf.segmentOn(0, 'b')}\" d=\"M29 8L33 4L37 8V30L33 34L29 30Z\" /><path data-segment=\"c\" ng-class=\"{on: skf.segmentOn(0, 'c')}\" d=\"M29 39L33 35L37 39V61L33 65L29 61Z\" /><path data-segment=\"d\" ng-class=\"{on: skf.segmentOn(0, 'd')}\" d=\"M6 62H27L31 66L27 70H6L2 66Z\" /><path data-segment=\"e\" ng-class=\"{on: skf.segmentOn(0, 'e')}\" d=\"M0 39L4 35L8 39V61L4 65L0 61Z\" /><path data-segment=\"f\" ng-class=\"{on: skf.segmentOn(0, 'f')}\" d=\"M0 8L4 4L8 8V30L4 34L0 30Z\" /><path data-segment=\"g\" ng-class=\"{on: skf.segmentOn(0, 'g')}\" d=\"M6 31H27L31 35L27 39H6L2 35Z\" /></g><g class=\"digit\" data-digit=\"1\" transform=\"translate(424 161)\"><path data-segment=\"a\" ng-class=\"{on: skf.segmentOn(1, 'a')}\" d=\"M6 0H27L31 4L27 8H6L2 4Z\" /><path data-segment=\"b\" ng-class=\"{on: skf.segmentOn(1, 'b')}\" d=\"M29 8L33 4L37 8V30L33 34L29 30Z\" /><path data-segment=\"c\" ng-class=\"{on: skf.segmentOn(1, 'c')}\" d=\"M29 39L33 35L37 39V61L33 65L29 61Z\" /><path data-segment=\"d\" ng-class=\"{on: skf.segmentOn(1, 'd')}\" d=\"M6 62H27L31 66L27 70H6L2 66Z\" /><path data-segment=\"e\" ng-class=\"{on: skf.segmentOn(1, 'e')}\" d=\"M0 39L4 35L8 39V61L4 65L0 61Z\" /><path data-segment=\"f\" ng-class=\"{on: skf.segmentOn(1, 'f')}\" d=\"M0 8L4 4L8 8V30L4 34L0 30Z\" /><path data-segment=\"g\" ng-class=\"{on: skf.segmentOn(1, 'g')}\" d=\"M6 31H27L31 35L27 39H6L2 35Z\" /></g><g class=\"digit\" data-digit=\"2\" transform=\"translate(489 161)\"><path data-segment=\"a\" ng-class=\"{on: skf.segmentOn(2, 'a')}\" d=\"M6 0H27L31 4L27 8H6L2 4Z\" /><path data-segment=\"b\" ng-class=\"{on: skf.segmentOn(2, 'b')}\" d=\"M29 8L33 4L37 8V30L33 34L29 30Z\" /><path data-segment=\"c\" ng-class=\"{on: skf.segmentOn(2, 'c')}\" d=\"M29 39L33 35L37 39V61L33 65L29 61Z\" /><path data-segment=\"d\" ng-class=\"{on: skf.segmentOn(2, 'd')}\" d=\"M6 62H27L31 66L27 70H6L2 66Z\" /><path data-segment=\"e\" ng-class=\"{on: skf.segmentOn(2, 'e')}\" d=\"M0 39L4 35L8 39V61L4 65L0 61Z\" /><path data-segment=\"f\" ng-class=\"{on: skf.segmentOn(2, 'f')}\" d=\"M0 8L4 4L8 8V30L4 34L0 30Z\" /><path data-segment=\"g\" ng-class=\"{on: skf.segmentOn(2, 'g')}\" d=\"M6 31H27L31 35L27 39H6L2 35Z\" /></g><g class=\"digit\" data-digit=\"3\" transform=\"translate(536 161)\"><path data-segment=\"a\" ng-class=\"{on: skf.segmentOn(3, 'a')}\" d=\"M6 0H27L31 4L27 8H6L2 4Z\" /><path data-segment=\"b\" ng-class=\"{on: skf.segmentOn(3, 'b')}\" d=\"M29 8L33 4L37 8V30L33 34L29 30Z\" /><path data-segment=\"c\" ng-class=\"{on: skf.segmentOn(3, 'c')}\" d=\"M29 39L33 35L37 39V61L33 65L29 61Z\" /><path data-segment=\"d\" ng-class=\"{on: skf.segmentOn(3, 'd')}\" d=\"M6 62H27L31 66L27 70H6L2 66Z\" /><path data-segment=\"e\" ng-class=\"{on: skf.segmentOn(3, 'e')}\" d=\"M0 39L4 35L8 39V61L4 65L0 61Z\" /><path data-segment=\"f\" ng-class=\"{on: skf.segmentOn(3, 'f')}\" d=\"M0 8L4 4L8 8V30L4 34L0 30Z\" /><path data-segment=\"g\" ng-class=\"{on: skf.segmentOn(3, 'g')}\" d=\"M6 31H27L31 35L27 39H6L2 35Z\" /></g><g class=\"colon\" fill=\"url(#kh-segments)\"><rect x=\"470\" y=\"181\" width=\"5\" height=\"6\" rx=\"1\" /><rect x=\"470\" y=\"204\" width=\"5\" height=\"6\" rx=\"1\" /></g></g>",
    " <svg width=\"36\" height=\"15.16\" viewBox=\"0 0 38 16\" fill=\"none\" id=\"kh-fobBattery\" x=\"615\" y=\"161\" data-figma-node=\"4:23\">",
    "<g id=\"kh-fobBattery-1\">",
    "<path id=\"kh-fobBattery-2\" d=\"M1 2H34V14H1V2ZM35 5H37V11H35V5Z\" stroke=\"#E9EEE8\" stroke-width=\"1.5\" stroke-linejoin=\"round\" />",
    "<path id=\"kh-fobBattery-3-1\" d=\"M5 5H9V11H5V5Z\" fill=\"#E9EEE8\" data-charge=\"1\" ng-attr-opacity=\"{{skf.fobBattery >= 1 ? 1 : 0.15}}\" />",
    "<path id=\"kh-fobBattery-3-2\" d=\"M12 5H16V11H12V5Z\" fill=\"#E9EEE8\" data-charge=\"2\" ng-attr-opacity=\"{{skf.fobBattery >= 26 ? 1 : 0.15}}\" />",
    "<path id=\"kh-fobBattery-3-3\" d=\"M19 5H23V11H19V5Z\" fill=\"#E9EEE8\" data-charge=\"3\" ng-attr-opacity=\"{{skf.fobBattery >= 51 ? 1 : 0.15}}\" />",
    "<path id=\"kh-fobBattery-3-4\" d=\"M26 5H30V11H26V5Z\" fill=\"#E9EEE8\" data-charge=\"4\" ng-attr-opacity=\"{{skf.fobBattery >= 76 ? 1 : 0.15}}\" />",
    "</g>",
    "</svg><svg width=\"36\" height=\"36\" viewBox=\"0 0 36 36\" fill=\"none\" id=\"kh-signal\" x=\"615\" y=\"196\" data-figma-node=\"4:27\">",
    "<g id=\"kh-radioSignal-1\">",
    "<path id=\"kh-radioSignal-2-1\" d=\"M1 26H8V35H1V26Z\" fill=\"url(#kh-radioSignal-4)\" stroke=\"#EDF3EB\" data-signal=\"1\" ng-attr-opacity=\"{{skf.linkOk ? 1 : 0.15}}\" />",
    "<path id=\"kh-radioSignal-2-2\" d=\"M13 16H20V35H13V16Z\" fill=\"url(#kh-radioSignal-4)\" stroke=\"#EDF3EB\" data-signal=\"2\" ng-attr-opacity=\"{{skf.linkOk ? 1 : 0.15}}\" />",
    "<path id=\"kh-radioSignal-2-3\" d=\"M25 1H32V35H25V1Z\" fill=\"url(#kh-radioSignal-4)\" stroke=\"#EDF3EB\" data-signal=\"3\" ng-attr-opacity=\"{{skf.linkOk ? 1 : 0.15}}\" />",
    "</g>",
    "<defs>",
    "<linearGradient id=\"kh-radioSignal-4\" x1=\"-4.84528e-07\" y1=\"-3.54998e-08\" x2=\"-4.84528e-07\" y2=\"36\" gradientUnits=\"userSpaceOnUse\">",
    "<stop stop-color=\"#F5F7F1\" />",
    "<stop offset=\"1\" stop-color=\"#C9D3CA\" />",
    "</linearGradient>",
    "</defs>",
    "</svg><g id=\"kh-miniCar\" transform=\"translate(251 265)\" stroke=\"#99aaa0\" stroke-width=\"1.7\" fill=\"none\" stroke-linejoin=\"round\"><path d=\"M9 0H22Q28 0 29 9V29Q28 38 22 38H9Q3 38 3 29V9Q3 0 9 0Z\" /><path d=\"M7 8H25M7 30H25M8 11H24V27H8Z\" />",
    " <path data-zone-icon=\"hood\" ng-class=\"{'zone-open': skf.hoodOpen}\" d=\"M8 2H23V7H8Z\" /><path data-zone-icon=\"trunk\" ng-class=\"{'zone-open': skf.trunkOpen}\" d=\"M8 31H23V36H8Z\" />",
    " <path data-zone-icon=\"FL\" ng-class=\"{'zone-open': skf.doorOpen['FL']}\" d=\"M3 10L-3 8V18L3 19Z\" /><path data-zone-icon=\"FR\" ng-class=\"{'zone-open': skf.doorOpen['FR']}\" d=\"M29 10L35 8V18L29 19Z\" /><path data-zone-icon=\"RL\" ng-class=\"{'zone-open': skf.doorOpen['RL']}\" d=\"M3 20L-3 21V31L3 29Z\" /><path data-zone-icon=\"RR\" ng-class=\"{'zone-open': skf.doorOpen['RR']}\" d=\"M29 20L35 21V31L29 29Z\" />",
    " </g>",
    " <text id=\"kh-lcdStatus\" ng-if=\"skf.startWarning\" x=\"468\" y=\"271\" class=\"lcd-status\" ng-style=\"{'font-size':skf.labelSize(skf.tr(skf.stateText),20,310)}\">{{skf.tr(skf.stateText)}}</text>",
    " <text id=\"kh-lcdDetail\" ng-if=\"skf.startWarning || skf.soundMenu\" x=\"468\" y=\"293\" class=\"lcd-detail\" ng-style=\"{'font-size':skf.labelSize(skf.detailText(),11,310)}\">{{skf.detailText()}}</text>",
    " </g></g>",
    "<path d=\"M759 248H799M756 265H795\" stroke=\"#1c2924\" stroke-width=\"12\" stroke-linecap=\"round\" />",
    "<path d=\"M760 246H798M757 263H794\" stroke=\"#68796e\" stroke-width=\"4\" stroke-linecap=\"round\" />",
    "<text x=\"452\" y=\"385\" text-anchor=\"middle\" class=\"brand brand-shadow\">KaifLine</text><text x=\"452\" y=\"383\" text-anchor=\"middle\" class=\"brand\">KaifLine</text>",
    "<g id=\"kh-findFlash\" pointer-events=\"none\" opacity=\"0\"><path d=\"M65 314L143 391M752 389L780 310\" fill=\"none\" stroke=\"#d4f3a1\" stroke-width=\"7\" stroke-linecap=\"round\" /></g>",
    "<g id=\"kh-hardware\"><g class=\"key skf-btn skf-horizon-key\" data-key=\"1\" ng-class=\"{pressed:skf.pressed[1]}\" ng-mousedown=\"skf.press(1)\" ng-mouseup=\"skf.release(1)\" ng-mouseleave=\"skf.cancel(1)\" ng-keydown=\"skf.keyDown($event,1)\" ng-keyup=\"skf.keyUp($event,1)\" ng-blur=\"skf.cancel(1)\" transform=\"translate(247 70)\" role=\"button\" tabindex=\"0\" aria-label=\"{{skf.tr('Кнопка 1')}}\"><rect class=\"key-hit\" x=\"-12\" y=\"-16\" width=\"94\" height=\"58\" rx=\"9\" /><path d=\"M2 13L8 1L60 0L68 12V26H2Z\" fill=\"#111719\" stroke=\"#77817d\" stroke-width=\"1\" /><rect class=\"key-face\" x=\"6\" y=\"8\" width=\"58\" height=\"19\" rx=\"4\" fill=\"url(#kh-keyCap)\" stroke=\"#182123\" stroke-width=\"1\" /><text x=\"35.0\" y=\"23\" text-anchor=\"middle\">1</text></g><g class=\"key skf-btn skf-horizon-key\" data-key=\"2\" ng-class=\"{pressed:skf.pressed[2]}\" ng-mousedown=\"skf.press(2)\" ng-mouseup=\"skf.release(2)\" ng-mouseleave=\"skf.cancel(2)\" ng-keydown=\"skf.keyDown($event,2)\" ng-keyup=\"skf.keyUp($event,2)\" ng-blur=\"skf.cancel(2)\" transform=\"translate(359 53)\" role=\"button\" tabindex=\"0\" aria-label=\"{{skf.tr('Кнопка 2')}}\"><rect class=\"key-hit\" x=\"-12\" y=\"-16\" width=\"90\" height=\"58\" rx=\"9\" /><path d=\"M2 13L8 1L56 0L64 12V26H2Z\" fill=\"#111719\" stroke=\"#77817d\" stroke-width=\"1\" /><rect class=\"key-face\" x=\"6\" y=\"8\" width=\"54\" height=\"19\" rx=\"4\" fill=\"url(#kh-keyCap)\" stroke=\"#182123\" stroke-width=\"1\" /><text x=\"33.0\" y=\"23\" text-anchor=\"middle\">2</text></g><g class=\"key skf-btn skf-horizon-key\" data-key=\"3\" ng-class=\"{pressed:skf.pressed[3]}\" ng-mousedown=\"skf.press(3)\" ng-mouseup=\"skf.release(3)\" ng-mouseleave=\"skf.cancel(3)\" ng-keydown=\"skf.keyDown($event,3)\" ng-keyup=\"skf.keyUp($event,3)\" ng-blur=\"skf.cancel(3)\" transform=\"translate(469 49)\" role=\"button\" tabindex=\"0\" aria-label=\"{{skf.tr('Кнопка 3')}}\"><rect class=\"key-hit\" x=\"-12\" y=\"-16\" width=\"90\" height=\"58\" rx=\"9\" /><path d=\"M2 13L8 1L56 0L64 12V26H2Z\" fill=\"#111719\" stroke=\"#77817d\" stroke-width=\"1\" /><rect class=\"key-face\" x=\"6\" y=\"8\" width=\"54\" height=\"19\" rx=\"4\" fill=\"url(#kh-keyCap)\" stroke=\"#182123\" stroke-width=\"1\" /><text x=\"33.0\" y=\"23\" text-anchor=\"middle\">3</text></g><g class=\"key skf-btn skf-horizon-key\" data-key=\"4\" ng-class=\"{pressed:skf.pressed[4]}\" ng-mousedown=\"skf.press(4)\" ng-mouseup=\"skf.release(4)\" ng-mouseleave=\"skf.cancel(4)\" ng-keydown=\"skf.keyDown($event,4)\" ng-keyup=\"skf.keyUp($event,4)\" ng-blur=\"skf.cancel(4)\" transform=\"translate(581 55)\" role=\"button\" tabindex=\"0\" aria-label=\"{{skf.tr('Кнопка 4')}}\"><rect class=\"key-hit\" x=\"-12\" y=\"-16\" width=\"90\" height=\"58\" rx=\"9\" /><path d=\"M2 13L8 1L56 0L64 12V26H2Z\" fill=\"#111719\" stroke=\"#77817d\" stroke-width=\"1\" /><rect class=\"key-face\" x=\"6\" y=\"8\" width=\"54\" height=\"19\" rx=\"4\" fill=\"url(#kh-keyCap)\" stroke=\"#182123\" stroke-width=\"1\" /><text x=\"33.0\" y=\"23\" text-anchor=\"middle\">4</text></g></g>",
    "<g class=\"skf-settings-gear skf-select-arrow\" transform=\"translate(742 168) scale(1.8)\" role=\"button\" tabindex=\"0\" aria-label=\"{{skf.tr('Настройки')}}\" ng-attr-aria-expanded=\"{{skf.settingsOpen}}\" ng-click=\"skf.toggleSettings()\" ng-keydown=\"($event.key === 'Enter' || $event.key === ' ') &amp;&amp; skf.toggleSettings()\">",
    "<rect class=\"skf-gear-hit\" x=\"-5\" y=\"-5\" width=\"34\" height=\"34\" rx=\"7\" fill=\"transparent\"/>",
    "<rect class=\"skf-gear-face\" width=\"24\" height=\"24\" rx=\"6\" fill=\"#263c33\" stroke=\"#8da399\" stroke-width=\".8\"/>",
    "<g transform=\"translate(3 3) scale(.75)\" fill=\"none\" stroke=\"#edf4ef\" stroke-width=\"1.6\"><path d=\"M9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1Z\"/><circle cx=\"12\" cy=\"12\" r=\"3.4\"/></g></g></svg>",
    "</div>"
  ].join('\n');

  angular.module('beamng.apps')
    .directive('starlineKeyfob', ['$log', function ($log) {
      return {
        template: TEMPLATE,
        replace: true,
        restrict: 'EA',
        scope: true,
        link: function (scope, element) {
          var destroyed = false;
          var remoteClockStartedAt = null;
          var remoteClockVehicleId = null;
          scope.skf = {
            skin: 'horizon', language: 'ru', settingsOpen: false,
            voltageText: '-- V',
            clock: '--:--',
            vehicles: [],
            selectedVehicleId: null,
            vehicleTitle: "",
            vehicleId: null,
            stateText: 'НЕТ СВЯЗИ',
            subText: '',
            soundMenu: false,
            soundLabel: 'ЗВУК: ' + SOUND_LABELS[2],
            armed: false,
            alarm: false,
            engineRunning: false,
            checkEngine: false,
            ignition: false,
            parkingBrake: false,
            doorOpen: { FL: false, FR: false, RL: false, RR: false },
            doorKnown: { FL: false, FR: false, RL: false, RR: false },
            anyOpening: false,
            trunkOpen: false,
            trunkKnown: false,
            hoodOpen: false,
            hoodKnown: false,
            remoteStarted: false,
            shockActive: false,
            fobBattery: 100,
            bars: ['#46525a', '#46525a', '#46525a', '#46525a'],
            ledColor: '#2b3337',
            lockState: 'UNSUPPORTED',
            panic: false,
            hint: '',
            shockLevel: 1,
            tiltLevel: 1,
            shockMode: 0,
            tiltEnabled: true,
            silentAlarmArmed: false,
            authRequired: false,
            remoteRunLeft: 0,
            lastTrigger: '',
            speedKmh: 0,
            rpm: 0,
            linkOk: false,
            lastAlarmState: '',
            pressed: { 1: false, 2: false, 3: false, 4: false },
            buttons: [
              { n: 1, label: '1', y: 128 },
              { n: 2, label: '2', y: 177 },
              { n: 3, label: '3', y: 226 },
              { n: 4, label: '4', y: 275 }
            ],
            lit: false
          };

          var skf = scope.skf;
          // Shrink only overflowing labels; never stretch letters to fill the LCD.
          var labelCanvas = document.createElement('canvas');
          var labelContext = labelCanvas.getContext('2d');
          var labelSizes = Object.create(null);
          skf.labelSize = function (value, base, width) {
            var text = String(value || '');
            var key = base + ':' + width + ':' + text;
            if (labelSizes[key]) return labelSizes[key];
            if (Object.keys(labelSizes).length > 128) labelSizes = Object.create(null);
            if (!labelContext) return base + 'px';
            labelContext.font = '700 ' + base + 'px Arial';
            var measured = labelContext.measureText(text).width;
            return (labelSizes[key] = Math.min(base, measured > 0 ? base * width / measured : base).toFixed(2) + 'px');
          };

          var session = {};            // per-button press session
          var doubleTimers = {};       // per-button double-press timers
          var lastSent = { name: null, at: 0 };
          var pendingSeq = null;       // { first: n, expires: ms }
          var hintTimer = null;
          var soundMenuTimer = null;
          var soundLevel = 2;
          var soundRevision = 0;

          var preferenceRevision = 0, preferenceTimer = null, preferenceAttempts = 0;
          var shapeTimer = null, shapeAttempts = 0;
          var shapeObserver = null, shapeResizeTimer = null;
          var translations = {
            'Настройки':'Settings', 'Настройки брелка':'Keyfob settings', 'Закрыть':'Close',
            'Скин':'Skin', 'Язык':'Language', 'Выбор сохраняется автоматически':'Your choice is saved automatically', 'Сохраняется автоматически':'Saved automatically',
            'Настройки сохранены':'Settings saved', 'Нет связи с игрой — выбор пока не сохранён':'No game connection — not saved yet',
            'Не удалось сохранить настройки':'Could not save settings',
            'Кнопка ':'Button ', 'Предыдущая машина':'Previous vehicle', 'Следующая машина':'Next vehicle',
            'СНЯТО':'DISARMED','ПОСТАНОВКА':'ARMING','ОХРАНА':'ARMED','ТРЕВОГА':'ALARM',
            'ЗАПУСК':'STARTING','ДВИГАТЕЛЬ':'RUNNING','АВТОРИЗ.':'AUTHORIZE','ПОЕЗДКА':'DRIVING','БЛОК':'BLOCKED','ОШИБКА':'ERROR',
            'НЕТ СВЯЗИ':'NO LINK','РИСК ДВИЖЕНИЯ':'MOVEMENT RISK',
            'БЕЗ РУЧНИКА · ПОВТОРИ ПУСК':'NO PARK BRAKE · REPEAT START',
            'СЕРВИСНЫЙ РЕЖИМ':'SERVICE MODE','НАКЛОН ВЫКЛ.':'TILT OFF',
            'БЕСШУМНАЯ ОХРАНА':'SILENT GUARD','УДАР: ВКЛ':'SHOCK: ON','УДАР: 1 УР.':'SHOCK: LEVEL 1','УДАР: ВЫКЛ':'SHOCK: OFF',
            'ДАТЧИК УДАРА: ':'SHOCK SENSOR: ','ЧУВСТВИТ. ':'SENSITIVITY ', 'АВТОЗАПУСК':'REMOTE START',
            'ДВЕРИ ЗАКРЫТЫ':'DOORS CLOSED','ОТКРЫТА ЗОНА':'ZONE OPEN','ОТКРЫТА ДВЕРЬ':'DOOR OPEN',
            'ОЖИДАНИЕ АВТОРИЗАЦИИ':'AWAITING AUTHORIZATION',
            'УДАР':'SHOCK','НАКЛОН':'TILT','ОТКР.':'OPEN',
            'ЗВУК: ':'SOUND: ','БЕЗ ЗВУКА':'MUTED','ТИХО':'LOW','ГРОМКО':'HIGH',
            'ПЕРЕДНЯЯ ЛЕВАЯ':'FRONT LEFT','ПЕРЕДНЯЯ ПРАВАЯ':'FRONT RIGHT','ЗАДНЯЯ ЛЕВАЯ':'REAR LEFT','ЗАДНЯЯ ПРАВАЯ':'REAR RIGHT',
            'КАПОТ':'HOOD','БАГАЖНИК':'TRUNK','ПРИЧИНА: ':'CAUSE: ','км/ч':'km/h','Автомобиль':'Vehicle','нет связи':'no link'
          };
          var translationKeys = Object.keys(translations).sort(function(a,b){return b.length-a.length;});
          skf.tr = function (value) {
            var text = String(value == null ? '' : value);
            if (skf.language !== 'en') return text;
            if (Object.prototype.hasOwnProperty.call(translations, text)) return translations[text];
            translationKeys.forEach(function(key){ text = text.split(key).join(translations[key]); });
            return text;
          };
          skf.detailText = function () {
            return skf.tr(skf.startWarning ? skf.subText : skf.soundMenu ? skf.soundLabel :
              skf.remoteRunText || skf.subText || (skf.linkOk ? skf.anyOpening ? 'ОТКРЫТА ЗОНА' : 'ДВЕРИ ЗАКРЫТЫ' : ''));
          };
          var segments = ['abcdef','bc','abged','abgcd','fgbc','afgcd','afgecd','abc','abcdefg','abfgcd'];
          skf.horizonClockText = function () {
            if (remoteClockStartedAt !== null && Math.floor((Date.now() - remoteClockStartedAt) / 3000) % 2 === 0) {
              var seconds = Math.max(0, Math.min(5999, Math.floor(skf.remoteRunLeft || 0)));
              return ('0' + Math.floor(seconds / 60)).slice(-2) + ':' + ('0' + (seconds % 60)).slice(-2);
            }
            return skf.clock;
          };
          skf.segmentOn = function (digit, segment) {
            var character = String(skf.horizonClockText()).replace(':','').charAt(digit);
            return /^[0-9]$/.test(character) && segments[Number(character)].indexOf(segment) !== -1;
          };
          skf.toggleSettings = function () {
            for (var key in session) clearSession(key);
            for (var tap in doubleTimers) {
              if (doubleTimers[tap]) clearTimeout(doubleTimers[tap].timer);
              doubleTimers[tap] = null;
            }
            skf.pressed = {1:false,2:false,3:false,4:false};
            pendingSeq = null;
            skf.settingsOpen = !skf.settingsOpen;
          };
          function scheduleSkinFit() {
            if (destroyed) return;
            if (shapeResizeTimer) clearTimeout(shapeResizeTimer);
            shapeResizeTimer = setTimeout(function () {
              shapeResizeTimer = null;
              fitSkin();
            }, 0);
          }
          // Resize this overlay only. Never save or reload the game's entire HUD layout.
          function fitSkin() {
            if (destroyed) return;
            var root = element && element[0];
            if (!root || !root.closest) return;
            var item = root.closest('.overlay-item');
            if (!item) {
              if (++shapeAttempts < 100) shapeTimer = setTimeout(fitSkin, 50);
              return;
            }
            // Vue can reapply the saved layout when the cockpit HUD changes.
            // Observe this item only, and repair its size after that DOM update.
            if (!shapeObserver && window.ResizeObserver) {
              shapeObserver = new window.ResizeObserver(scheduleSkinFit);
              shapeObserver.observe(item);
            }
            if (item.classList && item.classList.contains('is-editing')) return;
            // Horizon has explicit compact dimensions. Restoring the previous
            // overlay size must not restore oversized minimum dimensions.
            var frame = item.closest('.overlay__frame');
            var frameRect = frame && frame.getBoundingClientRect();
            var itemRect = item.getBoundingClientRect();
            var compactWidth = 300;
            var room = frameRect ? frameRect.width - Math.max(0,itemRect.left-frameRect.left) - 8 : compactWidth;
            var width = Math.max(140, Math.min(compactWidth, frameRect ? frameRect.width * .8 : compactWidth, room));
            var dimensions = {minWidth:'140px', minHeight:'80px', width:width + 'px',
              height:(width * 480/840 + 32) + 'px'};
            Object.keys(dimensions).forEach(function (key) {
              if (item.style[key] !== dimensions[key]) item.style[key] = dimensions[key];
            });
          }
          function savePreferences() {
            var revision = ++preferenceRevision;
            var api = engine();
            if (!api) { skf.preferenceMessage = 'Нет связи с игрой — выбор пока не сохранён'; return; }
            skf.preferenceMessage = '';
            api.engineLua('(function() if extensions.starline_alarm_bridge and extensions.starline_alarm_bridge.setHudPreferences then return extensions.starline_alarm_bridge.setHudPreferences("' + skf.skin + '","' + skf.language + '") end end)()', function(ok) {
              if (destroyed || revision !== preferenceRevision) return;
              skf.preferenceMessage = ok === true ? 'Настройки сохранены' : 'Не удалось сохранить настройки';
              apply();
            });
          }
          skf.setLanguage = function (language) {
            if (language !== 'ru' && language !== 'en' || skf.language === language) return;
            skf.language = language; savePreferences();
          };
          skf.keyDown = function (event, n) {
            if (event.key !== ' ' && event.key !== 'Enter' || event.repeat) return;
            event.preventDefault(); skf.press(n);
          };
          skf.keyUp = function (event, n) {
            if (event.key !== ' ' && event.key !== 'Enter') return;
            event.preventDefault(); skf.release(n);
          };
          function loadPreferences() {
            if (destroyed || preferenceRevision) return;
            var api = engine();
            if (!api) { if (++preferenceAttempts < 30) preferenceTimer = setTimeout(loadPreferences, 1000); return; }
            api.engineLua('(function() if extensions.starline_alarm_bridge and extensions.starline_alarm_bridge.getHudPreferences then return extensions.starline_alarm_bridge.getHudPreferences() end end)()', function(prefs) {
              if (destroyed || preferenceRevision) return;
              if (!prefs) { if (++preferenceAttempts < 30) preferenceTimer = setTimeout(loadPreferences, 1000); return; }
              skf.skin = 'horizon';
              if (prefs.language === 'ru' || prefs.language === 'en') skf.language = prefs.language;
              fitSkin(); apply();
            });
          }

          var ACTIONS = {
            '1S': 'arm',
            '2S': 'disarm',
            '3S': 'status',
            '1L': 'remoteStart',
            '2L': 'serviceMode',
            '1D': 'shockLevel',
            '3D': 'tiltLevel',
            '4D': 'find',
            '1_1': 'silentArm',
            '2_2': 'silentDisarm',
            '1_2': 'silentAlarmArm',
            '1_3': 'panic',
            '1_4': 'stopEngine',
            '2_1': 'trunk',
            '3_3': 'shockSensitivityMode',
            '4_4': 'tiltSensitivityMode'
          };

          function apply() { scope.$applyAsync(); }

          function hint(text) {
            skf.hint = text;
            apply();
            if (hintTimer) clearTimeout(hintTimer);
            hintTimer = setTimeout(function () { skf.hint = ''; apply(); }, 1500);
          }

          function audioContext() {
            var Ctx = window.AudioContext || window.webkitAudioContext;
            if (!Ctx) return null;
            if (!beep.ctx) beep.ctx = new Ctx();
            var ctx = beep.ctx;
            if (ctx.state === 'suspended') {
              var resume = ctx.resume();
              if (resume && resume.catch) resume.catch(function () {});
            }
            return ctx;
          }

          var recordedPaths = {
            hold: '/ui/modules/apps/starline_keyfob/sounds/uderjanie.mp3',
            send: '/ui/modules/apps/starline_keyfob/sounds/otpravka.mp3',
            startOk: '/ui/modules/apps/starline_keyfob/sounds/avtozapusk_ok.mp3',
            startTrouble: '/ui/modules/apps/starline_keyfob/sounds/avtozapusk_trouble.mp3'
          };
          var recordedBuffers = {};
          var recordedElements = {};
          var recordedActive = null;
          var recordedLoaded = false;
          function primeRecordedSounds() {
            if (recordedLoaded) return;
            recordedLoaded = true;
            var ctx = audioContext();
            Object.keys(recordedPaths).forEach(function (name) {
              var element = new Audio(recordedPaths[name]);
              element.preload = 'auto';
              recordedElements[name] = element;
              if (ctx && window.fetch) {
                fetch(recordedPaths[name]).then(function (response) {
                  if (!response.ok) throw new Error('audio not found');
                  return response.arrayBuffer();
                }).then(function (data) { return ctx.decodeAudioData(data); })
                  .then(function (buffer) { recordedBuffers[name] = buffer; })
                  .catch(function () {});
              }
            });
          }
          function recordedSound(name) {
            if (soundLevel === 0 || !recordedPaths[name]) return;
            primeRecordedSounds();
            if (recordedActive) {
              try { recordedActive.stop ? recordedActive.stop() : recordedActive.pause(); } catch (e) {}
            }
            var ctx = audioContext();
            if (ctx && recordedBuffers[name]) {
              var source = ctx.createBufferSource();
              var gain = ctx.createGain();
              gain.gain.value = soundLevel === 1 ? 0.12 : 0.32;
              source.buffer = recordedBuffers[name];
              source.connect(gain); gain.connect(ctx.destination);
              source.start();
              recordedActive = source;
            } else {
              var element = recordedElements[name];
              element.volume = soundLevel === 1 ? 0.12 : 0.32;
              element.currentTime = 0;
              var playback = element.play();
              if (playback && playback.catch) playback.catch(function () {});
              recordedActive = element;
            }
          }

          function beep(kind) {
            var peak = SOUND_GAINS[soundLevel];
            if (!peak) return;
            try {
              var ctx = audioContext();
              if (!ctx) return;
              var t0 = ctx.currentTime;
              function pip(freq, start, dur) {
                var osc = ctx.createOscillator();
                var gain = ctx.createGain();
                osc.type = 'square';
                osc.frequency.value = freq;
                gain.gain.setValueAtTime(peak, t0 + start);
                gain.gain.setValueAtTime(peak, t0 + start + dur);
                gain.gain.setValueAtTime(0.0001, t0 + start + dur + 0.005);
                osc.connect(gain);
                gain.connect(ctx.destination);
                osc.start(t0 + start);
                osc.stop(t0 + start + dur + 0.02);
              }
              if (kind === 'drive') {
                for (var i = 0; i < 4; i++) pip(2093, i * 0.1, 0.055);
              } else if (kind === 'ok') {
                pip(1568, 0, 0.08); pip(2093, 0.1, 0.12);
              } else {
                pip(2093, 0, 0.06);
              }
            } catch (e) { /* audio unavailable */ }
          }

          function engine() {
            try { if (typeof bngApi !== 'undefined' && bngApi) return bngApi; } catch (e) {}
            try { if (typeof window !== 'undefined' && window.bngApi) return window.bngApi; } catch (e) {}
            return null;
          }

          function showSoundLevel(level) {
            if (typeof level !== 'number' || SOUND_GAINS[level] === undefined) return;
            soundLevel = level;
            skf.soundLabel = 'ЗВУК: ' + SOUND_LABELS[level];
            apply();
          }

          function selectSoundLevel(level) {
            var revision = ++soundRevision;
            showSoundLevel(level);
            try {
              var api = engine();
              if (api) api.engineLua(
                'extensions.starline_alarm_bridge.setPagerVolume(' + level + ')',
                function (saved) {
                  if (!destroyed && revision === soundRevision) showSoundLevel(saved);
                });
            } catch (e) { /* bridge unavailable */ }
            if (!skf.alarm) beep('ok');
          }

          function closeSoundMenu() {
            clearTimeout(soundMenuTimer);
            soundMenuTimer = null;
            skf.soundMenu = false;
            apply();
          }

          function openSoundMenu() {
            clearTimeout(soundMenuTimer);
            skf.soundMenu = true;
            soundMenuTimer = setTimeout(closeSoundMenu, SOUND_MENU_MS);
            apply();
          }

          var lightTimer = null;
          function light(ms) {
            skf.lit = true;
            if (lightTimer) { clearTimeout(lightTimer); lightTimer = null; }
            lightTimer = setTimeout(function () {
              lightTimer = null;
              if (destroyed) return;
              skf.lit = false;
              apply();
            }, ms || 2500);
            apply();
          }

          var driveFeedback = createDriveFeedback(function () { if (!destroyed) beep('drive'); });
          var stopFeedback = createStopFeedback(function () { if (!destroyed) recordedSound('startTrouble'); });

          function send(cmd, sound) {
            var now = Date.now();
            if (lastSent.name === cmd && now - lastSent.at < DEBOUNCE_MS) return;
            lastSent.name = cmd;
            lastSent.at = now;
            if (cmd !== 'stopEngine') { if (sound) recordedSound(sound); else beep(); }
            light(1200);
            hint('→ ' + cmd);
            try {
              var api = engine();
              if (!api) { hint('НЕТ СВЯЗИ'); return; }
              if (cmd === 'stopEngine') stopFeedback.arm(skf.vehicleId);
              api.engineLua(
                'extensions.starline_alarm_bridge.command("' + cmd + '",nil,' + Number(skf.vehicleId) + ')');
            } catch (e) { hint('НЕТ СВЯЗИ'); }
          }

          function fire(key) {
            if (key === '4S') { light(3000); hint('ПОДСВЕТКА'); return; }
            var cmd = ACTIONS[key];
            if (!cmd) { hint(key); return; }
            send(cmd, key === '1_4' ? 'send' :
              (key.indexOf('_') >= 0 || key === '1L' || key === '2L') ? 'send' : null);
          }

          function held() {
            var out = [];
            for (var k in session) if (session[k] && session[k].down) out.push(+k);
            return out;
          }

          function clearSession(n) {
            var s = session[n];
            if (s && s.timer) clearTimeout(s.timer);
            session[n] = null;
          }

          skf.press = function (n) {
            if (skf.settingsOpen) return;
            try { audioContext(); } catch (e) { /* audio unavailable */ }
            primeRecordedSounds();
            n = +n;
            skf.pressed[n] = true;
            skf.fobBattery = Math.max(0, skf.fobBattery - 0.2);
            light(2500);


            if (skf.soundMenu) {
              session[n] = {menuPress: true};
              openSoundMenu();
              return;
            }

            var others = held();
            session[n] = { down: true, at: Date.now(), longFired: false, timer: null };

            if (others.length > 0) {
              pendingSeq = null;
              for (var i = 0; i < others.length; i++) {
                var other = others[i];
                clearSession(other);
                session[other] = { overlap: true };
                if (doubleTimers[other]) {
                  clearTimeout(doubleTimers[other].timer);
                  doubleTimers[other] = null;
                }
              }
              session[n] = { overlap: true };
              if (doubleTimers[n]) {
                clearTimeout(doubleTimers[n].timer);
                doubleTimers[n] = null;
              }
              hint('ПО ОДНОЙ КНОПКЕ');
              return;
            }

            session[n].timer = setTimeout(function () {
              var s = session[n];
              if (!s || !s.down) return;
              s.longFired = true;
              pendingSeq = { first: n, expires: Date.now() + SEQUENCE_GAP_MS };
              recordedSound('hold');
              var hold = n === 1 ? START_SEND_MS : n === 2 ? SERVICE_HOLD_MS : n === 4 ? MENU_HOLD_MS : 0;
              if (hold) s.timer = setTimeout(function () {
                if (!s.down) return;
                s.longActionFired = true;
                s.down = false;
                pendingSeq = null;
                if (n === 4) { openSoundMenu(); beep('ok'); }
                else fire(String(n) + 'L');
              }, hold - LONG_MIN_MS);
            }, LONG_MIN_MS);
          };

          skf.release = function (n) {
            n = +n;
            skf.pressed[n] = false;
            apply();
            var s = session[n];
            if (!s) return;
            if (s.overlap) { clearSession(n); return; }

            if (s.menuPress || skf.soundMenu) {
              clearSession(n);
              if (!s.menuPress || !skf.soundMenu) return;
              if (n === 2) selectSoundLevel(soundLevel === 2 ? 1 : 2);
              else if (n === 3) selectSoundLevel(0);
              else closeSoundMenu();
              return;
            }
            if (s.timer) { clearTimeout(s.timer); s.timer = null; }
            s.down = false;
            var heldFor = Date.now() - s.at;

            if (s.longFired) {
              if (s.timer) clearTimeout(s.timer);
              if (s.longActionFired) { clearSession(n); return; }
              if (pendingSeq && pendingSeq.first === n) {
                pendingSeq.expires = Date.now() + SEQUENCE_GAP_MS;
              }
              return;
            }
            if (heldFor >= LONG_MIN_MS) return;

            if (pendingSeq && Date.now() <= pendingSeq.expires) {
              var seqKey = pendingSeq.first + '_' + n;
              if (ACTIONS[seqKey]) {
                pendingSeq = null;
                session[n] = null;
                fire(seqKey);
                return;
              }
            }

            var t0 = doubleTimers[n];
            if (t0 && Date.now() - t0.at < DOUBLE_WINDOW_MS) {
              clearTimeout(t0.timer);
              doubleTimers[n] = null;
              session[n] = null;
              var dbl = String(n) + 'D';
              if (ACTIONS[dbl]) { fire(dbl); return; }
              if (ACTIONS[String(n) + 'S']) fire(String(n) + 'S');
              return;
            }

            var rec = { at: Date.now(), timer: null };
            rec.timer = setTimeout(function () {
              if (destroyed) return;
              if (doubleTimers[n] === rec) {
                doubleTimers[n] = null;
                session[n] = null;
                var shortKey = String(n) + 'S';
                if (ACTIONS[shortKey] || shortKey === '4S') fire(shortKey);
              }
            }, DOUBLE_WINDOW_MS);
            doubleTimers[n] = rec;
          };

          skf.cancel = function (n) {
            n = +n;
            skf.pressed[n] = false;
            apply();
            clearSession(n);
          };

          var selectionPending = false;
          skf.cycleVehicle = function (direction) {
            if (selectionPending || skf.vehicles.length < 2) return;
            var index = skf.vehicles.findIndex(function (v) { return v.vehicleId === skf.vehicleId; });
            var next = skf.vehicles[(Math.max(index, 0) + direction + skf.vehicles.length) % skf.vehicles.length];
            var id = Number(next.vehicleId);
            if (!isFinite(id) || id < 1 || Math.floor(id) !== id) return;
            for (var key in session) clearSession(key);
            var api = engine();
            if (!api) return;
            selectionPending = true;
            api.engineLua('extensions.starline_alarm_bridge.selectVehicle(' + id + ')', function () {
              selectionPending = false;
              if (!destroyed) pollState();
            });
          };

          // ---- state from the vehicle ----
          function applyState(st) {
            if (!st || typeof st !== 'object') return;
            stopFeedback.update(st);
            driveFeedback.update(st);
            if (skf.vehicleId !== st.vehicleId) {
              for (var key in session) clearSession(key);
              for (var tap in doubleTimers) {
                if (doubleTimers[tap]) clearTimeout(doubleTimers[tap].timer);
                doubleTimers[tap] = null;
              }
              skf.pressed = {1:false, 2:false, 3:false, 4:false};
              lastSent = {name:'', at:0};
              pendingSeq = null;
            }
            skf.vehicleId = st.vehicleId;
            skf.selectedVehicleId = st.vehicleId;
            var vehicleList = Array.isArray(st.vehicles) ? st.vehicles : [];
            if (!Array.isArray(st.vehicles) && st.vehicles && typeof st.vehicles === 'object') {
              vehicleList = Object.keys(st.vehicles).filter(function (key) { return /^\d+$/.test(key); })
                .sort(function (a, b) { return Number(a) - Number(b); })
                .map(function (key) { return st.vehicles[key]; });
            }
            if (!vehicleList.length && st.vehicleId != null) {
              vehicleList = [{vehicleId:st.vehicleId, vehicleName:st.vehicleName, link:st.link}];
            }
            skf.vehicles = vehicleList.map(function (v) {
              return {vehicleId:v.vehicleId, label:(v.vehicleName || 'Автомобиль') + ' · #' + v.vehicleId + (v.link ? '' : ' · нет связи')};
            });
            var title = (st.vehicleName || 'Автомобиль').replace(/\s*\[[^\]]*\]/g, '');
            if (title.length > 22) title = title.slice(0, 21) + '…';
            var selectedIndex = skf.vehicles.findIndex(function (v) { return v.vehicleId === st.vehicleId; });
            skf.vehicleTitle = title + ' · ' + (selectedIndex + 1) + '/' + skf.vehicles.length;
            var name = st.alarmState || 'DISARMED';
            var linked = st.link === true && st.vehicleId != null;
            var isAlarm = linked && name === 'ALARM';
            if (!stopFeedback.pending() && !isAlarm && linked && skf.lastAlarmState !== 'REMOTE_STARTING' &&
                     name !== skf.lastAlarmState &&
                     (name === 'ARMED' || name === 'DISARMED') &&
                     skf.lastAlarmState) { beep('ok'); }
            if (!stopFeedback.pending() && linked && skf.lastAlarmState === 'REMOTE_STARTING') {
              if (name === 'WAIT_AUTH' || name === 'REMOTE_RUNNING' || name === 'RUNNING_AUTHORIZED') recordedSound('startOk');
              else if (name === 'DISARMED' && !stopFeedback.pending()) recordedSound('startTrouble');
            }
            skf.lastAlarmState = name;
            skf.stateText = STATE_TEXT[name] || name;
            skf.armed = st.armed === true;
            skf.alarm = isAlarm;
            skf.alarmZone = isAlarm ? (st.alarmZone || st.alarmDoor) : null;
            skf.engineRunning = st.engineRunning === true;
            skf.remoteStarted = st.remoteStarted === true || name === 'REMOTE_STARTING';
            skf.checkEngine = st.checkEngine === true || st.engineInterlock === true;
            skf.ignition = st.ignition === true || (st.ignitionLevel || 0) > 0;
            skf.parkingBrake = st.parkingBrake === true;
            skf.startWarning = linked && st.remoteStartWarning === true;
            // Подпись под статусом: потеря связи важнее всего, затем
            // режим регулировки чувствительности, автозапуск с
            // остатком времени, бесшумная охрана,
            // затем уровни датчиков.
            if (st.link === false) {
              skf.subText = 'НЕТ СВЯЗИ';
            } else if (skf.startWarning) {
              skf.stateText = 'РИСК ДВИЖЕНИЯ';
              skf.subText = 'БЕЗ РУЧНИКА · ПОВТОРИ ПУСК';
            } else if (st.serviceMode === true) {
              skf.subText = 'СЕРВИСНЫЙ РЕЖИМ';
            } else if (st.tiltAdjustMode === true) {
              skf.subText = 'НАКЛОН ' + st.tiltLevel + ': 2-/3+';
            } else if (st.shockAdjustMode === true) {
              skf.subText = 'ЧУВСТВИТ. ' + st.shockSensitivity + ': 2+/3-';
            } else if (st.remoteStarted) {
              var left = Number(st.remoteRunLeft || 0);
              skf.subText = left > 0
                ? 'АВТОЗАПУСК ' + Math.floor(left / 60) + ':' +
                  ('0' + (left % 60)).slice(-2)
                : 'АВТОЗАПУСК';
            } else if (st.silentAlarmArmed === true && st.armed) {
              skf.subText = 'БЕСШУМНАЯ ОХРАНА';
            } else if (st.armed && st.shockMode !== undefined) {
              var names = ['УДАР: ВКЛ', 'УДАР: 1 УР.', 'УДАР: ВЫКЛ'];
              skf.subText = st.tiltEnabled === false ? 'НАКЛОН ВЫКЛ.' :
                (names[st.shockMode] || ('ДАТЧИК УДАРА: ' + st.shockLevel));
            } else if (st.armed && st.shockLevel) {
              skf.subText = 'ДАТЧИК УДАРА: ' + st.shockLevel;
            } else {
              skf.subText = '';
            }
            skf.lockState = st.lock && st.lock.state || 'UNSUPPORTED';
            skf.panic = st.panic === true;
            skf.shockLevel = Number(st.shockLevel) || 0;
            skf.tiltLevel = Number(st.tiltLevel) || 0;
            skf.shockMode = Number(st.shockMode) || 0;
            skf.shockActive = skf.armed && skf.shockMode !== 2;
            skf.tiltEnabled = st.tiltEnabled !== false;
            skf.silentAlarmArmed = st.silentAlarmArmed === true;
            skf.authRequired = st.authRequired === true;
            skf.lastTrigger = st.lastTrigger ? ('ПРИЧИНА: ' + st.lastTrigger) : '';
            var spd = Math.round(Number(st.speedKmh) || 0);
            var rpm = Math.round(Number(st.rpm) || 0);
            skf.speedKmh = spd;
            skf.rpm = rpm;
            skf.speedRpm = (spd > 0 || rpm > 0) ? (spd + ' км/ч ' + rpm) : '';
            if (st.clock && st.clock !== '--:--') {
              skf.clock = st.clock;
            }
            var left = Number(st.remoteRunLeft || 0);
            skf.remoteRunLeft = left;
            var remoteClockActive = linked && st.engineRunning === true && st.remoteStarted === true &&
              name !== 'RUNNING_AUTHORIZED' && left > 0;
            if (!remoteClockActive) {
              remoteClockStartedAt = null;
              remoteClockVehicleId = null;
            } else if (remoteClockStartedAt === null || remoteClockVehicleId !== st.vehicleId) {
              remoteClockStartedAt = Date.now();
              remoteClockVehicleId = st.vehicleId;
            }
            skf.remoteRunText = (st.remoteStarted && left > 0)
              ? ('АВТОЗАПУСК ' + Math.floor(left / 60) + ':' + ('0' + (left % 60)).slice(-2))
              : '';

            var d = st.doors || {};
            ['FL', 'FR', 'RL', 'RR'].forEach(function (id) {
              skf.doorKnown[id] = !!(d[id] && d[id].known === true);
              skf.doorOpen[id] = skf.doorKnown[id] && d[id].open === true;
            });
            skf.trunkKnown = !!(st.trunk && st.trunk.known === true);
            skf.trunkOpen = skf.trunkKnown && st.trunk.open === true;
            skf.hoodKnown = !!(st.hood && st.hood.known === true);
            skf.hoodOpen = skf.hoodKnown && st.hood.open === true;

            var volts = Number(st.batteryVoltage || st.voltage || (st.diagnostics && st.diagnostics.batteryVoltage));
            skf.voltageText = linked && isFinite(volts) && volts > 0 ? volts.toFixed(1) + ' V' : '-- V';
            skf.linkOk = linked;
            if (!linked) {
              skf.stateText = 'НЕТ СВЯЗИ';
              skf.startWarning = false;
              skf.lastAlarmState = '';
              skf.armed = false;
              skf.alarm = false;
              skf.engineRunning = false;
              skf.remoteStarted = false;
              skf.checkEngine = false;
              skf.ignition = false;
              skf.parkingBrake = false;
              skf.shockActive = false;
              skf.lockState = 'UNSUPPORTED';
              skf.subText = '';
              skf.trunkKnown = skf.hoodKnown = false;
              skf.trunkOpen = skf.hoodOpen = false;
              ['FL', 'FR', 'RL', 'RR'].forEach(function (id) {
                skf.doorKnown[id] = false;
                skf.doorOpen[id] = false;
              });
              skf.remoteRunText = '';
              skf.speedRpm = '';
            }
            skf.anyOpening = skf.hoodOpen || skf.trunkOpen ||
              Object.keys(skf.doorOpen).some(function (id) { return skf.doorOpen[id]; });
            var zoneLabels = {hood: 'КАПОТ', trunk: 'БАГАЖНИК', FL: 'ПЕРЕДНЯЯ ЛЕВАЯ', FR: 'ПЕРЕДНЯЯ ПРАВАЯ',
              RL: 'ЗАДНЯЯ ЛЕВАЯ', RR: 'ЗАДНЯЯ ПРАВАЯ'};
            skf.telemetryText = linked && (isAlarm && st.lastTrigger ?
              (skf.alarmZone ? zoneLabels[skf.alarmZone] || 'ОТКРЫТА ДВЕРЬ' :
                String(st.lastTrigger).slice(0, 24)) : skf.speedRpm) || '';
            skf.bars = linked
              ? ['#7fbf3f', '#7fbf3f', '#7fbf3f', '#7fbf3f']
              : ['#4a302c', '#382825', '#2c2220', '#241d1c'];
            skf.ledColor = name === 'ALARM' ? '#d8402f'
              : (name === 'ARMED' ? '#7fbf3f' : '#2b3337');
            apply();
          }

          // guihooks.trigger("starlineAlarmState", st) из VLua/GE доходит
          // в CEF через window.multihookUpdate -> $broadcast (StreamHooks.js:
          // _hookHandler делает globalAngularRootScope.$broadcast(hookName)).
          // Поэтому слушать нужно scope.$on (стоковый паттерн SimpleGears),
          // а НЕ window.addEventListener: DOM-событие никто не генерирует.
          function onStateEvent(ev, st) { applyState(st); }
          var unbindState = scope.$on('starlineAlarmState', onStateEvent);
          var unbindGameClock = scope.$on('kaiflineGameClock', function (event, clock) {
            if (typeof clock === 'string' && /^\d{2}:\d{2}$/.test(clock)) {
              skf.clock = clock;
              apply();
            }
          });

          // Потеря фокуса окном: отменяем все нажатые кнопки без команд.
          window.addEventListener('blur', function () {
            for (var k in session) {
              if (session[k] && session[k].down) { skf.cancel(k); }
            }
            document.addEventListener('mouseup', function docUp() {
              document.removeEventListener('mouseup', docUp);
              for (var k2 in session) clearSession(k2);
              for (var b in skf.pressed) skf.pressed[b] = false;
              apply();
            });
          });

          // Fallback-опрос: запрашиваем у GE-моста последнее известное
          // состояние и применяем напрямую (не через событие — $broadcast
          // на собственный poll не нужен, мост сам триггерит при пуше).
          function pollState() {
            try {
              var api = engine();
              if (!api) return;
              var revision = soundRevision;
              api.engineLua(
                'extensions.starline_alarm_bridge.getState()',
                function (s) {
                  if (!s || destroyed) return;
                  if (revision === soundRevision) showSoundLevel(s.pagerVolume);
                  applyState(s);
                });
            } catch (e) { /* bridge not loaded yet */ }
          }

          var unbindAppResize = scope.$on('app:resized', scheduleSkinFit);
          var unbindCameraResize = scope.$on('PlayerCameraModeChanged', scheduleSkinFit);
          window.addEventListener('resize', scheduleSkinFit);
          loadPreferences();
          pollState();
          var pollTimer = setInterval(pollState, 1000);

          var removeHudDrag = installHudDrag(element);
          scope.$on('$destroy', function () {
            removeHudDrag();
            destroyed = true;
            stopFeedback.cancel();
            driveFeedback.cancel();
            if (preferenceTimer) clearTimeout(preferenceTimer);
            if (shapeTimer) clearTimeout(shapeTimer);
            if (shapeResizeTimer) clearTimeout(shapeResizeTimer);
            if (shapeObserver) shapeObserver.disconnect();
            unbindAppResize();
            unbindGameClock();
            unbindCameraResize();
            window.removeEventListener('resize', scheduleSkinFit);
            clearInterval(pollTimer);
            if (hintTimer) clearTimeout(hintTimer);
            if (soundMenuTimer) clearTimeout(soundMenuTimer);
            if (unbindState) unbindState();
            for (var k in session) clearSession(k);
            for (var t in doubleTimers) {
              if (doubleTimers[t]) clearTimeout(doubleTimers[t].timer);
            }
          });

          $log.debug('[starlineKeyfob] Horizon keyfob mounted');
        }
      };
    }]);
})();
