#!/usr/bin/env python3
"""Build the standalone Horizon edition. No dependencies beyond Python 3."""
from pathlib import Path
import json
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'mod' / 'starline_alarm'
version = json.loads((SOURCE / 'info.json').read_text())['version']
output_dir = ROOT / 'release'
output_dir.mkdir(exist_ok=True)
archive_version = version.split('-github.', 1)[0]
output = output_dir / ('KaifLine_Alarm_' + archive_version + '.zip')
for file in SOURCE.rglob('*'):
    if file.is_file() and (file.suffix == '.bak' or file.name.startswith('.')):
        raise RuntimeError('Unexpected file in mod: ' + str(file))
with ZipFile(output, 'w', ZIP_DEFLATED, compresslevel=7) as archive:
    for file in sorted(SOURCE.rglob('*')):
        if file.is_file():
            archive.write(file, file.relative_to(SOURCE).as_posix())
with ZipFile(output) as archive:
    assert archive.testzip() is None
for old in output_dir.glob('KaifLine_Alarm_*.zip'):
    if old != output:
        old.unlink()
print(output)
