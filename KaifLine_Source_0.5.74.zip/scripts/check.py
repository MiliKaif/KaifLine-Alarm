#!/usr/bin/env python3
"""Check syntax, retained behavior and the boundaries of this edition."""
from pathlib import Path
import subprocess
import re

ROOT = Path(__file__).resolve().parents[1]
MOD = ROOT / 'mod' / 'starline_alarm'
def run(*args):
    subprocess.run(args, cwd=ROOT, check=True)
for file in sorted(MOD.rglob('*.lua')):
    run('luac', '-p', str(file))
js = MOD / 'ui/modules/apps/starline_keyfob/app.js'
run('node', '--check', str(js))
for file in sorted((ROOT / 'tests').glob('test_*.lua')):
    run('lua', str(file))
run('node', 'tests/test_horizon.cjs')
run('node', 'tests/test_stop_feedback.cjs')
run('node', 'tests/test_stop_sounds.cjs')
run('node', 'tests/test_drive_feedback.cjs')
source = js.read_text()
assert "skin: 'horizon'" in source
assert "skf.setSkin" not in source
for token in ['skf-a93', 'Classic', 'qrOpen', 'Pairing', 'QRCode', "seqKey === '3_4'"]:
    assert token not in source, token
bridge = (MOD / 'lua/ge/extensions/starline/alarm/bridge.lua').read_text()
for token in ['mobileSocket', 'getMobilePairing', 'onMobileCommandResult', 'socket.udp', '38741', 'getMobileMap']:
    assert token not in bridge, token
controller = (MOD / 'lua/vehicle/controller/starlineAlarm.lua').read_text()
assert 'starline_alarm_mobileCommand' not in controller
assert 'mobileRequestId' not in controller
assert 'htmlTexture' not in controller
assert not (MOD / 'ui/starline_alarm_keyfob').exists()
for file in MOD.rglob('*'):
    assert file.suffix != '.bak'
    if file.is_file() and file.suffix in {'.js', '.json', '.lua', '.jbeam'}:
        assert not re.search(r'userToken=|ghp_[A-Za-z0-9]+|/home/kaifarik/', file.read_text()), file
print('PASS: no Classic, phone server, pairing, private paths or credentials in release sources')
