// Compile exactly the callback wrapper used by ui-vue/src/bridge/libs/BeamNGAPI.js.
// The JavaScript mocks alone cannot detect a Lua statement passed as an expression.
const {spawnSync}=require('child_process');
module.exports=function assertLuaEngineCall(code,callback){
 const source=callback ? 'guihooks.trigger("onBNGAPICallback",143,'+code+')' : code;
 let equals='';while(source.includes(']'+equals+']'))equals+='=';
 const literal='['+equals+'['+source+']'+equals+']';
 const script=`local source=${literal}
local captured
local env={extensions={},guihooks={trigger=function(event,id,value) captured={event,id,value} end}}
local chunk=assert(load(source,'actual engineLua wrapper','t',env))
-- Guarded calls must also work before the extension or method has been loaded.
if source:find('(function()',1,true) then
 chunk()
 env.extensions.starline_alarm_bridge={}
 chunk()
 -- Preserve false results rather than treating a failed save as a success.
 local bridge=setmetatable({}, {__index=function() return function() return false end end})
 env.extensions.starline_alarm_bridge=bridge
 chunk()
 ${callback ? 'assert(captured[1]=="onBNGAPICallback" and captured[2]==143 and captured[3]==false)' : ''}
end`;
 const result=spawnSync('lua',['-e',script],{encoding:'utf8',timeout:2000});
 if(result.status!==0)throw new Error('Invalid engineLua call:\n'+source+'\n'+(result.stderr||result.error));
};
