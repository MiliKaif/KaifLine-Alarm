local f=assert(io.open('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua'));local src=f:read('*a');f:close()
local a=assert(src:find('local function authorizationDisarmFeedback()',1,true))
local b=assert(src:find('-- Called only by the optional Keyless',a,true))
local function run(initial, native)
 local events={}
 local function event(name)events[#events+1]=name end
 local e={state=initial,S={WAIT_AUTH='WAIT_AUTH',RUNNING_AUTHORIZED='RUNNING_AUTHORIZED',ARMED='ARMED',ARMING='ARMING',IMMOBILIZED='IMMOBILIZED',DISARMED='DISARMED'},
 timers={heartbeat=5},CFG={disarmFlashCount=2},SCENARIO={DISARM='disarm'},authGranted=false,remoteStartReturnArmed=true,
 cancelScenario=function(kind)event('cancel:'..kind)end,
 A=function(name)if name=='nativeLockFeedback' then return native end end,
 startScenario=function(spec,cause,count)assert(spec=='disarm' and count==2);event('flash')end,
 playMechanicalLock=function(action)assert(action=='disarm');event('lock')end,
 playConfirmation=function(action)assert(action=='disarm');event('sound')end,
 requestWelcomeLight=function()event('welcome')end,
 stopAllOutputs=function()end,syncEngineInterlock=function()end,pushUI=function()end,msg=function()end}
 e.setState=function(new)e.state=new end
 local authorize=assert(load(src:sub(a,b-1)..'return cmdAuthorize','authorize','t',e))()
 assert(authorize())
 assert(e.authGranted and e.timers.heartbeat==0)
 local counts={};for _,name in ipairs(events)do counts[name]=(counts[name]or 0)+1 end
 assert(counts.sound==1 and counts.welcome==1)
 if native then assert(counts.flash==nil) else assert(counts.flash==1) end
 if initial=='WAIT_AUTH' then
  assert(e.state=='RUNNING_AUTHORIZED' and not e.remoteStartReturnArmed)
  local n=#events;assert(authorize());assert(#events==n,'repeated authorization must not repeat feedback')
 end
end
run('WAIT_AUTH',false);run('WAIT_AUTH',true);run('ARMED',false)
print('PASS: remote authorization confirms disarm once; heartbeat stops; native flashes not duplicated')
