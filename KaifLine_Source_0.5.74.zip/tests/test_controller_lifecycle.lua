-- Load the entire exported controller, rather than isolated function snippets.
local published, queued = {}, {}
log=function()end
obj={getEnvTemperature=function()return 293.15 end,getId=function()return 42 end,queueGameEngineLua=function(_,code)queued[#queued+1]=code end}
v={data={props={},nodes={}}}
energyStorage={getStorages=function()return {}end}
electrics={values={ignitionLevel=0,lights_state=0},setLightsState=function(value)electrics.values.lights_state=value end}
sounds={}
guihooks={message=function()end}
powertrain={getDevice=function()return nil end}
jsonEncode=function(state)published[#published+1]=state;return '{}'end
package.loaded.controller={getControllerSafe=function()return nil end}
package.loaded.electrics=electrics
package.loaded.sounds=sounds
package.loaded['controller/alarmEngineInterlock']={isActive=function()return false end,isSupported=function()return false end,unblock=function()end,block=function()end}
package.loaded['controller/vehicleAdapterUniversal']={init=function()return true end,reset=function()end}
package.path='mod/starline_alarm/lua/vehicle/?.lua;'..package.path
local alarm=dofile('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua')
alarm.init({})
assert(#published>=1 and published[1].vehicleId==42)
assert(published[1].alarmState=='DISARMED' and published[1].remoteStartWarning==false)
local first=#published
for i=1,40 do alarm.updateGFX(0.05) end
assert(#published>first, 'HUD state must continue publishing after init')
alarm.reset({});alarm.updateGFX(0.05)
assert(#queued>0)
print('PASS: complete release controller initializes, publishes HUD state, updates and resets')
