const vm=require('vm'),fs=require('fs'),assert=require('assert');
for(const file of ['mod/starline_alarm/ui/modules/apps/starline_keyfob/app.js',...(fs.existsSync('mod/starline_alarm/ui/starline_alarm_keyfob/keyfob.js')?['mod/starline_alarm/ui/starline_alarm_keyfob/keyfob.js']:[])]){
 const s=fs.readFileSync(file,'utf8'),a=s.indexOf('  function createDriveFeedback('),b=s.indexOf('  // End drive feedback helper.',a);
 let now=0,id=0,sounds=0;const timers=new Map();
 const factory=vm.runInNewContext(s.slice(a,b)+'\ncreateDriveFeedback',{setTimeout(fn,ms){timers.set(++id,{fn,at:now+ms});return id},clearTimeout(id){timers.delete(id)}});
 const f=factory(()=>sounds++),st={vehicleId:1,link:true,alarmState:'WAIT_AUTH',speedKmh:10};
 function advance(ms){now+=ms;for(const[id,t]of timers)if(t.at<=now){timers.delete(id);t.fn()}}
 f.update(st);advance(1000);assert.equal(sounds,0);
 st.alarmState='RUNNING_AUTHORIZED';f.update(st);advance(999);assert.equal(sounds,0);advance(1);assert.equal(sounds,1);
 st.speedKmh=0;f.update(st);st.speedKmh=20;f.update(st);advance(2000);assert.equal(sounds,1);
 st.alarmState='DISARMED';f.update(st);st.authorized=true;f.update(st);advance(500);st.speedKmh=0;f.update(st);advance(500);assert.equal(sounds,1);
 st.speedKmh=20;f.update(st);advance(1000);assert.equal(sounds,2);
 st.vehicleId=2;f.update(st);f.cancel();advance(1000);assert.equal(sounds,2);
 assert(s.includes('i < 4; i++) pip(2093, i * 0.1, 0.055)'));
 console.log('PASS: '+file+' authorized movement +1s; four fast beeps, once per authorization');
}
