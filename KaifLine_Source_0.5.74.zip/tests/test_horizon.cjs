const assertLuaEngineCall=require('./assert_lua_engine_call.cjs');
const vm=require('vm'),fs=require('fs'),assert=require('assert');
let observerCallback, observerDisconnected=false;
let now=10000, timerId=0; const timers=new Map();
class Clock extends Date {static now(){return now}}
function advance(ms){const end=now+ms;while(true){const due=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!due)break;now=due[1].at;timers.delete(due[0]);due[1].fn()}now=end}
let directive, prefs={skin:'a93',language:'en'}, late, saved=[], callbacks={}, calls=[];
const state={vehicleId:1,link:true,alarmState:'DISARMED',armed:false,clock:'08:19',vehicles:[],batteryVoltage:12.4};
const scope={$on(n,fn){callbacks[n]=fn;return ()=>{}},$applyAsync(){}};
const api={engineLua(code,cb){assertLuaEngineCall(code,cb);calls.push(code);
 if(code.includes('.getHudPreferences()')){late=cb;cb(prefs)}
 else if(code.includes('.setHudPreferences(')){const p=code.match(/setHudPreferences\("(\w+)","(\w+)"\)/);prefs={skin:p[1],language:p[2]};saved.push(prefs);cb(true)}
 else if(code.includes('.getState()'))cb(state);
}};
vm.runInNewContext(fs.readFileSync('mod/starline_alarm/ui/modules/apps/starline_keyfob/app.js','utf8'),{
 angular:{module:()=>({directive(n,args){directive=args.at(-1)({debug(){},warn(){}})}})},
 window:{bngApi:api,addEventListener(){},removeEventListener(){},ResizeObserver:class {constructor(callback){observerCallback=callback} observe(){} disconnect(){observerDisconnected=true}}},document:{createElement:()=>({getContext:()=>({measureText:t=>({width:t.length*10})})})},
 setTimeout(fn,ms){timers.set(++timerId,{fn,at:now+ms});return timerId},clearTimeout(id){timers.delete(id)},setInterval(){return 1},clearInterval(){},Date:Clock,console,
 Audio:function(){return {play:()=>Promise.resolve(),pause(){}}}
});
directive.link(scope);const f=scope.skf;
assert.equal(f.skin,'horizon');assert.equal(f.language,'en');assert.equal(f.tr(f.stateText),'DISARMED');
assert.equal(f.voltageText,'12.4 V');assert(f.segmentOn(0,'a'));assert(!f.segmentOn(0,'g'));assert(f.segmentOn(1,'g'));
assert.equal(f.detailText(),'DOORS CLOSED');
f.settingsOpen=false;f.toggleSettings();assert(f.settingsOpen);
assert.equal(f.setSkin,undefined);f.setLanguage('ru');assert.equal(saved.length,1);
late({skin:'a93',language:'en'});assert.equal(f.skin,'horizon');
assert(!directive.template.includes('Classic') && !directive.template.includes('skf-a93'));
assert(!directive.template.includes('qrOpen') && !directive.template.includes('QR ДЛЯ ТЕЛЕФОНА'));
assert(directive.template.includes('kh-horizon-fob'));f.setLanguage('en');
callbacks.starlineAlarmState(null,{...state,alarmState:'ALARM',armed:true,engineRunning:true,doors:{FL:{known:true,open:true}},hood:{known:true,open:true},trunk:{known:true,open:true},remoteStarted:true,remoteRunLeft:121});
assert(f.armed&&f.alarm&&f.engineRunning&&f.doorOpen.FL&&f.hoodOpen&&f.trunkOpen);
assert.equal(f.tr(f.stateText),'ALARM');assert.equal(f.detailText(),'REMOTE START 2:01');
assert.equal(f.horizonClockText(),'02:01');
advance(3000);assert.equal(f.horizonClockText(),'08:19');
callbacks.starlineAlarmState(null,{...state,alarmState:'WAIT_AUTH',engineRunning:true,remoteStarted:true,remoteRunLeft:118});
assert.equal(f.horizonClockText(),'08:19','telemetry updates must not restart the display cycle');
advance(3000);assert.equal(f.horizonClockText(),'01:58');
callbacks.starlineAlarmState(null,{...state,alarmState:'RUNNING_AUTHORIZED',engineRunning:true,remoteStarted:false,remoteRunLeft:118});
assert.equal(f.horizonClockText(),'08:19','authorization restores game time immediately');
advance(3000);assert.equal(f.horizonClockText(),'08:19');
callbacks.starlineAlarmState(null,{...state,alarmState:'WAIT_AUTH',engineRunning:true,remoteStarted:true,remoteRunLeft:90});
assert.equal(f.horizonClockText(),'01:30');
callbacks.starlineAlarmState(null,{...state,engineRunning:false,remoteStarted:false});
assert.equal(f.horizonClockText(),'08:19','stopping remote start restores game time immediately');
callbacks.starlineAlarmState(null,{...state,link:false});assert(!f.armed&&!f.engineRunning&&!f.hoodOpen&&!f.doorOpen.FL);
assert.equal(f.tr(f.stateText),'NO LINK');assert.equal(f.voltageText,'-- V');
assert(directive.template.includes('ng-show="skf.linkOk && !skf.armed"'));
assert(directive.template.includes('ng-show="skf.linkOk && skf.armed"'));
assert(directive.template.includes('id="kh-running"'));
assert(directive.template.includes('ng-show="skf.linkOk && skf.engineRunning"'));
assert.equal((directive.template.match(/class="kh-exhaust-frame kh-frame-[123]"/g)||[]).length,3);
const hudCss=fs.readFileSync('mod/starline_alarm/ui/modules/apps/starline_keyfob/app.css','utf8');
assert(hudCss.includes('@keyframes kh-exhaustFrames'));
assert(!hudCss.includes('.smoke-1{opacity:1}'));
assert(!directive.template.includes('key-progress'));assert(!calls.some(c=>/UIAppStorage|saveLayout|reloadUI/.test(c)));
f.settingsOpen=false;callbacks.starlineAlarmState(null,state);
function lastCommand(){return calls.filter(c=>c.includes('.command(')).at(-1)||''}
f.press(1);advance(899);assert(!lastCommand().includes('remoteStart'));advance(1);assert(!lastCommand().includes('remoteStart'));advance(900);assert(lastCommand().includes('remoteStart'));f.release(1);
f.press(1);advance(900);f.release(1);f.press(4);advance(10);f.release(4);assert(lastCommand().includes('stopEngine'));
f.press(2);advance(900);f.release(2);f.press(1);advance(10);f.release(1);assert(lastCommand().includes('trunk'));
const before=calls.filter(c=>c.includes('.command(')).length;f.toggleSettings();f.press(1);advance(2000);f.release(1);assert.equal(calls.filter(c=>c.includes('.command(')).length,before,'settings must block vehicle commands');
console.log('PASS: real controller 0.9 + 0.9s start, 1→4 stop, 2→1 trunk and settings command isolation');
console.log('PASS: persisted skin/language, stale-read guard, translation, clock segments, real telemetry, doors, alarm and offline reset');
f.settingsOpen=false;f.press(3);advance(950);f.release(3);f.press(4);f.release(4);
assert(!calls.some(c=>/Mobile|Pairing/.test(c)));
assert.equal(f.skin,'horizon');callbacks.$destroy();
console.log('PASS: Horizon-only HUD, legacy preferences, indicators, timers, language and no pairing gesture');
