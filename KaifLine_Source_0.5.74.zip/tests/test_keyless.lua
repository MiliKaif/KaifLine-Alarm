local json = io.open('mod/starline_alarm/vehicles/common/licenseplates/starline/starline_alarm.jbeam'):read('*a')
assert(json:find('starline_keyless_option', 1, true))
assert(io.open('mod/starline_alarm/vehicles/common/licenseplates/starline/starline_keyless.jbeam'))

local queued = {}
local person = {getPosition = function() return {x=1.2,y=0,z=0} end}
local cars = {
  [7] = {getPosition = function() return {x=0,y=0,z=0} end,
         queueLuaCommand = function(_, code) queued[#queued+1] = {id=7,code=code} end},
  [8] = {getPosition = function() return {x=1,y=0,z=0} end,
         queueLuaCommand = function(_, code) queued[#queued+1] = {id=8,code=code} end},
}
local walking = true
log = function() end
gameplay_walk = {isWalking=function() return walking end}
getPlayerVehicle = function() return person end
getObjectByID = function(id) return cars[id] end
local vdata={
  triggers={[3]={name='door_FR'},[4]={name='door_FR_int'}},
  triggerEventLinksDict={[3]={action0={{}}},[4]={action0={{}}}},
  inputActions={}
}
extensions = {core_vehicle_manager={getVehicleData=function()
  return {vdata=vdata}
end}}
local hook = dofile('mod/starline_alarm/lua/ge/extensions/starline/alarm/keyless.lua')
hook.registerVehicle(8)
hook.onUpdate(.5)
assert(vdata.triggerEventLinksDict[3].action2 and not vdata.triggerEventLinksDict[4].action2,
  'only exterior handles gain a middle-click action')
assert(vdata.inputActions.kaifline_keyless_lock, 'middle-click action must be registered')
hook.onVehicleTriggersExecuteLink({triggerId='door_FL'},1,7,0)
assert(#queued==1 and queued[1].id==7 and queued[1].code:find('"FL"',1,true))
hook.onVehicleTriggersExecuteLink({triggerId='door_FL_int'},1,7,0)
hook.onVehicleTriggersExecuteLink({triggerId='door_FL'},0,7,0)
assert(#queued==1, 'interior and release events must be ignored')
walking=false
hook.onVehicleTriggersExecuteLink({triggerId='door_FR'},1,7,0)
assert(#queued==1, 'another car cannot unlock from orbit camera')
getPlayerVehicle=function() return cars[7] end
hook.onVehicleTriggersExecuteLink({triggerId='door_FR'},1,7,0)
assert(#queued==2 and queued[2].code:find('"FR"',1,true), 'selected car can unlock from orbit camera')
getPlayerVehicle=function() return person end
walking=true
person.getPosition=function() return {x=20,y=0,z=0} end
hook.onVehicleTriggersExecuteLink({triggerId='door_FR'},1,7,0)
assert(#queued==2, 'out of Keyless range')
person.getPosition=function() return {x=1.2,y=0,z=0} end
hook.onVehicleTriggersExecuteLink({triggerId=3},1,8,0)
assert(#queued==3 and queued[3].id==8 and queued[3].code:find('"FR"',1,true), 'trigger cid and vehicle routing')
hook.onVehicleTriggersExecuteLink(vdata.triggerEventLinksDict[3].action2[1],1,8,0)
assert(#queued==4 and queued[4].code:find('handleLock',1,true), 'middle-click locks the same vehicle')

local received
package.loaded.controller={getControllerSafe=function(name)
  if name=='starlineAlarm' then return {
    keylessHandlePress=function(zone) received=zone; return true end,
    keylessHandleLock=function(zone) received='lock:'..zone; return true end
  } end
end}
local accessory=dofile('mod/starline_alarm/lua/vehicle/controller/starlineKeyless.lua')
assert(type(accessory.init)=='function' and type(accessory.reset)=='function')
accessory.init()
assert(accessory.handlePress('RL')==true and received=='RL')
received=nil
assert(accessory.handlePress('hood')==false and received==nil)
assert(accessory.handleLock('RR')==true and received=='lock:RR')
accessory.reset()
print('PASS: optional Keyless subslot, exterior handle, walking proximity, selected vehicle and zone forwarding')
