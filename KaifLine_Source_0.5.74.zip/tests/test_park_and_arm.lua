local file=assert(io.open('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua'));local source=file:read('*a');file:close()
local a=assert(source:find('local function cmdArm(silent)',1,true));local b=assert(source:find('local function cmdDisarm(silent, source)',a,true))
local function test(brake,speed,expected)
 local events={}
 local e={pairs=pairs,S={ARMED='ARMED',ALARM='ALARM',ARMING='ARMING'},state='RUNNING_AUTHORIZED',CFG={maxSafeSpeedMps=.6,remoteStartCooldown=3,armDelay=.6,armFlashCount=1},SCENARIO={ARM={}},timers={remoteStart=8,remoteRun=100,heartbeat=10},welcomeLight={stop=function()end},
 engineRunning=function()return true end,parkedSafe=function()return brake end,speedMps=function()return speed end,
 stopEngineHard=function()events[#events+1]='stop' end,stopAllOutputs=function()end,openingZones=function()return {}end,
 syncEngineInterlock=function()end,stopHorn=function()end,startScenario=function()end,playConfirmation=function()end,playMechanicalLock=function()end,msg=function()end}
 e.A=function(name,default)if name=='lockDoors' then events[#events+1]='lock';return true end return default end
 e.setState=function(value)e.state=value end
 local arm=assert(load(source:sub(a,b-1)..'return cmdArm','arm','t',e))()
 local ok=arm(false)
 assert(ok==expected)
 if expected then assert(events[1]=='lock' and #events==1 and e.state=='ARMING');assert(e.timers.remoteRun==0 and e.timers.heartbeat==0)
  local c=assert(source:find('local function updateParkShutdown(dt)',1,true))
  local d=assert(source:find('local function finishRemoteRun(reason)',c,true))
  e.math=math
  local update=assert(load(source:sub(c,d-1)..'return updateParkShutdown','shutdown','t',e))()
  update(.5);assert(#events==1)
  update(.5);assert(events[2]=='stop' and #events==2)
  update(2);assert(#events==2)
 else assert(#events==0) end
end
test(true,0,true);test(false,0,false);test(true,5,false)
print('PASS: parked running car locks before stopping after one second; moving car and missing handbrake rejected')
