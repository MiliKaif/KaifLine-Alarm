-- Cover named lamp props, legacy glow materials, shared tailgate channels,
-- unrelated lights and the restoration of ordinary lighting.
electrics = {values={lowhighbeam=0, lowhighbeam_tailgateSafe=0, lights_state=0}}
local trigger = {orgMat='x6ken_plate', on='x6ken_plate_E',
  simpleFunction={lowhighbeam_tailgateSafe=1}, evalFunction=function() return electrics.values.lowhighbeam_tailgateSafe end}
local original = trigger.evalFunction
local named = {func='lowhighbeam', deformGroup='licenseplateLights_deform_R', lightBrightness=1}
local spot = {func='lowhighbeam_tailgateSafe',mesh='SPOTLIGHT',deformGroup='tailgateglass_break',
  lightRange=0.35, lightBrightness=0.005,lightColor={r=1,g=1,b=1}}
local tail = {func='lowhighbeam_tailgateSafe',mesh='SPOTLIGHT',lightRange=0.35,
  lightBrightness=0.005,lightColor={r=1,g=0,b=0}}
local head = {func='lowhighbeam',mesh='SPOTLIGHT',lightRange=200,lightBrightness=1}
v = {data={props={[0]=named,[1]=spot,[2]=tail,[3]=head},_materials={triggers={trigger},triggerList={'lowhighbeam_tailgateSafe'}}}}
local m=dofile('mod/starline_alarm/lua/vehicle/controller/starlinePlateLight.lua')
m.update(true)
assert(electrics.values[named.func]==1 and electrics.values[spot.func]==1)
assert(trigger.evalFunction()==1)
assert(tail.func=='lowhighbeam_tailgateSafe' and head.func=='lowhighbeam')
assert(electrics.values.lights_state==0 and electrics.values.lowhighbeam_tailgateSafe==0)
m.update(true);assert(#v.data._materials.triggerList==2, 'must not add duplicate wakeup channels')
m.update(false);assert(trigger.evalFunction()==0 and electrics.values[spot.func]==0)
electrics.values.lowhighbeam_tailgateSafe=0.49;m.update(false)
assert(trigger.evalFunction()==0.49 and electrics.values[spot.func]==0.49)
m.reset();assert(trigger.evalFunction==original and named.func=='lowhighbeam' and spot.func=='lowhighbeam_tailgateSafe')
print('PASS: named lamps, legacy plate material, isolated white spots, normal lighting restored')
-- Bastion: generic LED unit with a reverselight deformation group, no plate glow map.
-- Mach-E: old spotlight under a generic tailgate group and no explicit color.
local bastion = {func='lowhighbeam',mesh='SPOTLIGHT',deformGroup='reverselight_break',
  baseTranslationGlobal={x=0.036,y=2.566,z=0.638},lightRange=0.225,
  lightColor={r=235,g=245,b=255},lightIntensityCd=4}
local mache = {func='lowhighbeam',mesh='SPOTLIGHT',deformGroup='tailgateglass_break',
  baseTranslationGlobal={x=0.132,y=2.438,z=0.677},lightRange=0.3,lightBrightness=0.006}
local front = {func='lowhighbeam',mesh='SPOTLIGHT',baseTranslationGlobal={x=0,y=-2,z=0.6},lightRange=0.3}
local side = {func='lowhighbeam',mesh='SPOTLIGHT',baseTranslationGlobal={x=0.7,y=2.4,z=0.6},lightRange=0.3}
v={data={props={bastion,mache,front,side}}}
m.update(true)
assert(bastion.func~='lowhighbeam' and mache.func~='lowhighbeam')
assert(electrics.values[bastion.func]==1 and electrics.values[mache.func]==1)
assert(front.func=='lowhighbeam' and side.func=='lowhighbeam')
m.update(false);assert(electrics.values[bastion.func]==0)
m.reset()
assert(bastion.func=='lowhighbeam' and mache.func=='lowhighbeam')
print('PASS: Bastion and Mach-E plate spotlights; front and outer rear lights untouched')
