local f=assert(io.open('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua'));local s=f:read('*a');f:close()
local a=assert(s:find('local function updateRemoteStart(dt)',1,true));local b=assert(s:find('local function updateSafety(dt)',a,true))
local function test(armed)
 local e={state='REMOTE_STARTING',S={REMOTE_STARTING='REMOTE_STARTING',WAIT_AUTH='WAIT_AUTH',REMOTE_RUNNING='REMOTE_RUNNING',RUNNING_AUTHORIZED='RUNNING_AUTHORIZED',ARMED='ARMED',ALARM='ALARM',DISARMED='DISARMED'},
 timers={remoteStart=6,remoteIgnitionDelay=0,heartbeat=10},remoteStartReturnArmed=armed,HEARTBEAT_PERIOD=10,SCENARIO={REMOTE={}},
 engineRunning=function()return true end,syncEngineInterlock=function()end,startScenario=function()end,msg=function()end,pushUI=function()end,
 pcall=pcall,electrics={},logI=function()end}
 e.setState=function(value)e.state=value end
 local update=assert(load(s:sub(a,b-1)..'return updateRemoteStart','start','t',e))()
 update(.1)
 assert(e.authGranted==not armed)
 assert(e.state==(armed and 'WAIT_AUTH' or 'RUNNING_AUTHORIZED'))
 assert(e.timers.heartbeat==(armed and 10 or 0))
end
test(false);test(true)
print('PASS: remote start of unlocked vehicle grants access; armed start still requires authorization')
