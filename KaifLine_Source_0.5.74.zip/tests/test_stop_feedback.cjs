const fs=require('fs'),vm=require('vm'),assert=require('assert');
for(const file of ['mod/starline_alarm/ui/modules/apps/starline_keyfob/app.js', ...(fs.existsSync('mod/starline_alarm/ui/starline_alarm_keyfob/keyfob.js')?['mod/starline_alarm/ui/starline_alarm_keyfob/keyfob.js']:[])]){
 const src=fs.readFileSync(file,'utf8');const a=src.indexOf('  function createStopFeedback('),b=src.indexOf('  // End stop feedback helper.',a);
 assert(a>=0&&b>a);
 let now=0,next=0,played=0;const timers=new Map();
 const factory=vm.runInNewContext(src.slice(a,b)+'\ncreateStopFeedback',{
 Date:{now:()=>now},isFinite,setTimeout(fn,ms){timers.set(++next,{fn,at:now+ms});return next},clearTimeout(id){timers.delete(id)}});
 function advance(ms){now+=ms;for(const[id,t]of timers){if(t.at<=now){timers.delete(id);t.fn()}}}
 const f=factory(()=>played++),st={vehicleId:1,link:true,rpm:1200,engineRunning:true};
 f.arm(1);f.update(st);advance(1000);assert.equal(played,0);
 f.update({...st,rpm:120,engineRunning:false});advance(1000);assert.equal(played,0);
 f.update({...st,rpm:0,engineRunning:false});advance(499);assert.equal(played,0);
 // A rebound cancels the countdown; wait a full 500 ms after the next stop.
 f.update({...st,rpm:80,engineRunning:false});advance(1);assert.equal(played,0);
 f.update({...st,rpm:0,engineRunning:false});advance(500);assert.equal(played,1);
 f.update({...st,rpm:0,engineRunning:false});advance(1000);assert.equal(played,1);
 f.arm(1);f.update({...st,rpm:null,engineRunning:false});advance(500);assert.equal(played,1);
 f.update({...st,rpm:0,engineRunning:false});f.update({...st,vehicleId:2});advance(500);assert.equal(played,1);
 f.arm(1);f.update({...st,rpm:0,engineRunning:false});f.update({...st,link:false});advance(500);assert.equal(played,1);
 f.arm(1);f.update({...st,rpm:0,engineRunning:false});f.cancel();advance(500);assert.equal(played,1);
 assert(!src.includes("key === '1_4' ? 'startTrouble'"));assert(!src.includes("if (action === '1_4') playRecordedSound('startTrouble')"));
 console.log('PASS: '+file+' RPM rundown + 500 ms; rebound, missing RPM, switching and link loss');
}
