const assertLuaEngineCall=require('./assert_lua_engine_call.cjs');
const vm=require('vm'),fs=require('fs'),assert=require('assert');
let observerCallback, observerDisconnected=false;
let now=10000, timerId=0; const timers=new Map();
class Clock extends Date {static now(){return now}}
function advance(ms){const end=now+ms;while(true){const due=[...timers].filter(([,t])=>t.at<=end).sort((a,b)=>a[1].at-b[1].at)[0];if(!due)break;now=due[1].at;timers.delete(due[0]);due[1].fn()}now=end}
let played=[];
let directive, prefs={skin:'horizon',language:'en'}, late, saved=[], callbacks={}, calls=[];
const state={vehicleId:1,link:true,alarmState:'DISARMED',armed:false,clock:'08:19',vehicles:[],batteryVoltage:12.4};
const scope={$on(n,fn){callbacks[n]=fn;return ()=>{}},$applyAsync(){}};
const api={engineLua(code,cb){assertLuaEngineCall(code,cb);calls.push(code);
 if(code.includes('.getHudPreferences()')){late=cb;cb(prefs)}
 else if(code.includes('.setHudPreferences(')){const p=code.match(/setHudPreferences\("(\w+)","(\w+)"\)/);prefs={skin:p[1],language:p[2]};saved.push(prefs);cb(true)}
 else if(code.includes('.getState()'))cb(state);
}};
vm.runInNewContext(fs.readFileSync('mod/starline_alarm/ui/modules/apps/starline_keyfob/app.js','utf8'),{
 angular:{module:()=>({directive(n,args){directive=args.at(-1)({debug(){},warn(){}})}})},
 window:{bngApi:api,addEventListener(){},removeEventListener(){},ResizeObserver:class {constructor(callback){observerCallback=callback} observe(){} disconnect(){observerDisconnected=true}}},document:{createElement:()=>({getContext:()=>({measureText:t=>({width:t.length*10})})})},
 setTimeout(fn,ms){timers.set(++timerId,{fn,at:now+ms});return timerId},clearTimeout(id){timers.delete(id)},setInterval(){return 1},clearInterval(){},Date:Clock,console,
 Audio:function(path){return {play:()=>{played.push(path);return Promise.resolve()},pause(){}}}
});
directive.link(scope);const f=scope.skf;
const sample={...state,alarmState:'WAIT_AUTH',engineRunning:true,rpm:900,remoteStarted:true};
callbacks.starlineAlarmState(null,sample);
f.press(1);advance(900);f.release(1);
assert.equal(played.filter(p=>p.endsWith('uderjanie.mp3')).length,1);
f.press(4);advance(10);f.release(4);
assert.equal(played.filter(p=>p.endsWith('otpravka.mp3')).length,0,'stop must not play command send sound');
assert.equal(played.filter(p=>p.endsWith('avtozapusk_trouble.mp3')).length,0);
callbacks.starlineAlarmState(null,{...sample,alarmState:'DISARMED',engineRunning:false,rpm:200});advance(1000);
assert.equal(played.filter(p=>p.endsWith('avtozapusk_trouble.mp3')).length,0);
callbacks.starlineAlarmState(null,{...sample,alarmState:'DISARMED',engineRunning:false,rpm:0});advance(499);
assert.equal(played.filter(p=>p.endsWith('avtozapusk_trouble.mp3')).length,0);
advance(1);assert.equal(played.filter(p=>p.endsWith('avtozapusk_trouble.mp3')).length,1);
callbacks.$destroy();console.log('PASS: stop plays hold then one delayed confirmation, without command send sound');
