local function latch()
  local c={state='attached', opens=0, closes=0}
  c.getGroupState=function()return c.state end
  c.detachGroup=function()c.opens=c.opens+1;c.state='detached' end
  c.toggleGroup=function()
    if c.state=='attached' then c.detachGroup() else c.closes=c.closes+1;c.state='attached' end
  end
  c.toggleGroupConditional=c.toggleGroup
  return c
end
local door,trunk=latch(),latch()
package.preload.controller=function()return {getAllControllers=function()return {door_FL_coupler=door,trunkCoupler=trunk}end}end
package.preload.electrics=function()return {values={}}end
local a=dofile('mod/starline_alarm/lua/vehicle/controller/vehicleAdapterUniversal.lua')
a.init();a.lockDoors()
trunk.toggleGroup();assert(trunk.opens==0)
assert(a.openTrunk());assert(trunk.opens==1)
trunk.detachGroup();assert(trunk.opens==1, 'direct detach stays blocked')
trunk.toggleGroupConditional();assert(trunk.closes==1 and trunk.state=='attached', 'handle must close open trunk')
trunk.toggleGroup();assert(trunk.opens==1, 'closed trunk must relock immediately')
door.state='detached';door.toggleGroup();assert(door.closes==0, 'door guard must retain existing behavior')
a.unlockDoors();trunk.toggleGroup();assert(trunk.opens==2)
print('PASS: locked trunk opens from fob, closes by handle and relocks immediately')
