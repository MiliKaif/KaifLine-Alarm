-- Exercise the actual controller functions with a small simulated latch.
local file = assert(io.open('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua'))
local source = file:read('*a')
file:close()
local function section(first, last)
  local a = assert(source:find(first, 1, true))
  local b = assert(source:find(last, a + #first, true))
  return source:sub(a, b - 1)
end
local trunk = section('local function cmdTrunk()', 'local function cmdFind()')
local watcher = section('local function watchOpenings()', '-- ============================================================\n-- Инициализация')
local harness = [[
local trustedTrunkOpen = false
local trustedTrunkSeenOpen = false
local trustedTrunkClosedSince = nil
local trustedTrunkDeadline = 0
local simTime = 0
local electrics = {values={lights_state=2}}
local plateLight = {update=function()end}
local watchedZones = {trunk=true}
local state = 'ARMED'
local S = {ARMING='ARMING', ALARM='ALARM'}
local trunkState = {known=true, closed=true, open=false}
local alarms = {}
local M = {triggerAlarm=function(reason, zone) alarms[#alarms+1]={reason,zone} end}
local function trunkInfo() return trunkState end
local function openingZones() return {trunk=trunkState} end
local function A(name)
  if name=='openTrunk' then return true end -- latch moves several frames later
end
local SCENARIO = {TRUNK='trunk'}
local function startScenario() end
]] .. trunk .. watcher .. [[
return {
  command=cmdTrunk, watch=watchOpenings, alarms=alarms,
  close=function() trunkState.open=false; trunkState.closed=true end,
  forceOpen=function() trunkState.open=true; trunkState.closed=false end,
  advance=function(dt) simTime=simTime+dt end
}
]]
local test = assert(load(harness))()
assert(test.command()==true)
test.watch() -- still closed immediately after the command
test.advance(0.3)
test.watch() -- actuator has not opened the lid yet
test.forceOpen()
test.watch()
assert(#test.alarms==0, 'key command must not trigger alarm')
test.close()
test.watch()
test.advance(0.05)
test.forceOpen()
test.watch()
assert(#test.alarms==0, 'brief latch bounce must not rearm the sensor')
test.close()
test.watch()
test.advance(9)
test.watch()
test.forceOpen()
test.watch()
assert(#test.alarms==1 and test.alarms[1][1]=='trunk_open',
  'sensor must rearm after closing')
print('PASS: key-opened trunk is trusted once and rearmed on close')
