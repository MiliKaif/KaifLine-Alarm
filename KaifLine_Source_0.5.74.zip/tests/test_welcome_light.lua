local calls={}
electrics={values={lights_state=0},setLightsState=function(value)
  calls[#calls+1]=value;electrics.values.lights_state=value
end}
local m=dofile('mod/starline_alarm/lua/vehicle/controller/starlineWelcomeLight.lua')
assert(not m.start(false));assert(#calls==0)
assert(m.start(true));assert(electrics.values.lights_state==1)
m.update(29);assert(electrics.values.lights_state==1)
m.update(1);assert(electrics.values.lights_state==0)
m.start(true);electrics.values.lights_state=2;m.update(30);assert(electrics.values.lights_state==2)
electrics.values.lights_state=1;assert(not m.start(true));m.update(30);assert(electrics.values.lights_state==1)
electrics.values.lights_state=0;m.start(true);m.stop();assert(electrics.values.lights_state==0)
local darkness=dofile('mod/starline_alarm/lua/ge/extensions/starline/alarm/darkness.lua')
core_environment={getLightState=function()return {isNight=true}end}
assert(darkness.isDark(nil))
core_environment.getLightState=function()return {isNight=false}end
vec3=function(x,y,z)return {x=x,y=y,z=z}end
local vehicle={getPosition=function()return vec3(0,0,0)end}
castRayStatic=function()return 20 end;assert(not darkness.isDark(vehicle))
castRayStatic=function()return 3 end;assert(darkness.isDark(vehicle))
castRayStatic=function(pos)return pos.x==0 and pos.y==0 and 3 or 20 end
assert(not darkness.isDark(vehicle), 'one small obstruction must not count as a roof')
print('PASS: night, roof, daylight; 30-second expiry; relock cancellation; driver lights preserved')
-- BeamNG's setter updates its internal state; the published electrics values
-- change on the next electrics update, not inside setLightsState().
local pending
local delayed=dofile('mod/starline_alarm/lua/vehicle/controller/starlineWelcomeLight.lua')
electrics.values.lights_state=0
electrics.setLightsState=function(value)pending=value end
assert(delayed.start(true));assert(pending==1)
delayed.update(0.016)
assert(pending==1, 'must wait for electrics to publish parking lights')
electrics.values.lights_state=pending
delayed.update(0.016);delayed.update(29)
assert(pending==1)
delayed.update(1);assert(pending==0, 'must switch off after 30 seconds')
electrics.values.lights_state=0
assert(delayed.start(true));delayed.stop()
assert(pending==0, 'relocking before electrics updates must cancel pending lights')
print('PASS: asynchronous electrics update does not cancel welcome light')
core_environment={getLightState=function()return {isNight=false}end,
  getTimeOfDay=function()return {time=0.25}end} -- 18:00, API still calls it day
assert(darkness.isDark(nil), '18:00 must support welcome lighting')
core_environment.getTimeOfDay=function()return {time=0}end
assert(not darkness.isDark(nil), 'noon must stay off')
local f=assert(io.open('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua'));local source=f:read('*a');f:close()
local a=assert(source:find('local function cmdDisarm(silent, source)',1,true))
local b=assert(source:find('  timers.alarmStop = 0',a,true))
local early=source:sub(a,b-1)..'end\nreturn cmdDisarm'
local count=0
local env={state='DISARMED',S={DISARMED='DISARMED'},A=function()end,requestWelcomeLight=function()count=count+1 end}
local disarm=assert(load(early,'disarm early','t',env))()
assert(disarm()==true and count==1, 'unlocking an already disarmed vehicle must request welcome lights')
print('PASS: dusk at 18:00 and repeated unlock both request welcome lights')
-- Exact frame order from vehicle/main.lua: first electrics -> controllers ->
-- second electrics (European ignition-off filter) -> materials/props.
local lightSwitch=0
local filterCalls=0
local filter=function()
 filterCalls=filterCalls+1
 for _,k in ipairs({'lights_state','lights','parking','lowhighbeam','lowbeam','lowhighbeam_filament','lowbeam_filament','lowhighbeam_signal_L','lowhighbeam_signal_R','engineRunning','ignition','fuel'}) do electrics.values[k]=0 end
end
electrics={values={lights_state=0,ignitionLevel=0},setLightsState=function(value)lightSwitch=value end,updateGFXSecondStep=filter}
local off=dofile('mod/starline_alarm/lua/vehicle/controller/starlineWelcomeLight.lua')
assert(off.start(true))
for _=1,29 do
 electrics.values.lights_state=lightSwitch
 off.update(1)
 electrics.updateGFXSecondStep(1)
 assert(electrics.values.lowhighbeam==1 and electrics.values.lowhighbeam_filament==1)
 assert(electrics.values.ignitionLevel==0 and electrics.values.engineRunning==0 and electrics.values.fuel==0)
end
electrics.values.lights_state=lightSwitch;off.update(1);electrics.updateGFXSecondStep(1)
assert(lightSwitch==0 and electrics.values.lowhighbeam==0)
assert(electrics.updateGFXSecondStep==filter and filterCalls==30)
assert(off.start(true));off.stop();assert(lightSwitch==0 and electrics.updateGFXSecondStep==filter)
print('PASS: real ignition-off frame order; light survives filter for 30 seconds; ignition remains off')
-- Ignition filter may expose zero even though the internal switch is still 1.
electrics.values.lights_state=0;assert(off.start(true));assert(lightSwitch==1)
electrics.values.lights_state=0;off.update(1)
assert(lightSwitch==0, 'loss of published state must not leave the internal light switch on')
assert(electrics.updateGFXSecondStep==filter)
assert(off.start(true));electrics.values.lights_state=1
off.update(30)
assert(lightSwitch==0 and electrics.values.lowhighbeam_filament==0 and electrics.values.parking==0,
 'expiry must clear forced channels immediately')
print('PASS: zeroed published state cannot leave switch on; forced channels clear on expiry')
electrics={values={lights_state=0},setLightsState=function(n)electrics.values.lights_state=n end}
local driving=dofile('mod/starline_alarm/lua/vehicle/controller/starlineWelcomeLight.lua')
assert(driving.start(true));driving.update(20,0);driving.update(1,2)
driving.update(120,0);assert(electrics.values.lights_state==1, 'starting a journey must cancel timed light shutdown')
electrics.values.lights_state=0;driving.update(.1,2);assert(electrics.values.lights_state==0, 'manual off must still work')
assert(driving.start(true));driving.update(1,2);driving.stop();assert(electrics.values.lights_state==0, 'locking must stop welcome lighting')
print('PASS: driving keeps welcome lights on; manual off and locking still switch them off')
