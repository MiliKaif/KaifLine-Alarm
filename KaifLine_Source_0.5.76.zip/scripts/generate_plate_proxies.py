#!/usr/bin/env python3
"""Create non-recursive StarLine plate choices from installed BeamNG mods."""

import argparse
import hashlib
import json
import re
from pathlib import Path
from zipfile import BadZipFile, ZipFile


SLOT_TYPE = "starlinelicenseplate_design"
OUTPUT = Path("mod/starline_alarm/vehicles/common/licenseplates/starline/starline_mod_plates.jbeam")


def part_blocks(source):
    """Find top-level JBeam parts, including files with BeamNG's loose JSON syntax."""
    depth = 0
    part_name = None
    part_start = None
    index = 0
    decoder = json.JSONDecoder()
    while index < len(source):
        char = source[index]
        if source.startswith("//", index):
            end = source.find("\n", index)
            index = len(source) if end < 0 else end + 1
            continue
        if source.startswith("/*", index):
            end = source.find("*/", index + 2)
            index = len(source) if end < 0 else end + 2
            continue
        if char == '"':
            try:
                value, end = decoder.raw_decode(source, index)
            except ValueError:
                index += 1
                continue
            if depth == 1:
                rest = source[end:]
                if re.match(r"\s*:\s*\{", rest):
                    part_name = value
            index = end
            continue
        if char == "{":
            if depth == 1 and part_name is not None:
                part_start = index
            depth += 1
        elif char == "}":
            if depth == 2 and part_name is not None and part_start is not None:
                yield part_name, source[part_start:index + 1]
                part_name = None
                part_start = None
            depth -= 1
            if depth < 0:
                depth = 0
        index += 1


def field(body, name):
    match = re.search(r'"' + re.escape(name) + r'"\s*:\s*"((?:\\.|[^"\\])*)"', body)
    return json.loads('"' + match.group(1) + '"') if match else None


def array_field(body, name):
    """Read slot tables without requiring the surrounding JBeam to be JSON."""
    match = re.search(r'"' + re.escape(name) + r'"\s*:\s*(\[)', body)
    if not match:
        return None
    # Tokenize strings first so comment markers and brackets inside labels are
    # not interpreted as syntax. JBeam permits comments and trailing commas.
    tokens = re.findall(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*[\s\S]*?\*/|[^\s]', body[match.start(1):])
    result = []
    depth = 0
    for token in tokens:
        if token.startswith(('//', '/*')):
            continue
        if token in ('[', '{'):
            depth += 1
        elif token in (']', '}'):
            depth -= 1
            if result and result[-1] == ',':
                result.pop()
        result.append(token)
        if depth == 0:
            return json.loads(''.join(result))
    raise ValueError('Unterminated JBeam table: ' + name)


def generate_parts(archives, available_paths, existing=None):
    """Wrap plate parts; keep native style subslots owned by the source mod."""
    existing_ids = {
        (part['information'].get('authors'), part['information']['name']): name
        for name, part in (existing or {}).items()
    }
    parts = {}
    seen = set()
    for archive_path, jbeams in archives:
        with ZipFile(archive_path) as archive:
            for jbeam in jbeams:
                source = archive.read(jbeam).decode('utf-8-sig', errors='replace')
                if 'licenseplate_design_2_1' not in source:
                    continue
                for original_name, body in part_blocks(source):
                    if field(body, 'slotType') != 'licenseplate_design_2_1':
                        continue
                    label = field(body, 'name')
                    if not label:
                        continue
                    authors = field(body, 'authors') or archive_path.stem
                    proxy = {
                        'information': {'authors': authors, 'name': label, 'value': 50},
                        'slotType': SLOT_TYPE,
                    }
                    path = field(body, 'licenseplate_path')
                    if path:
                        actual_path = available_paths.get(path.lower())
                        if not actual_path:
                            print('Skipping missing plate template:', archive_path.name, path)
                            continue
                        key = actual_path.lower()
                        proxy['licenseplate_path'] = actual_path
                    else:
                        # HTNV 2026 moved licenseplate_path into selectable
                        # font/style children. A flattened stale path no longer
                        # works; preserve these subslots and their defaults.
                        slots = array_field(body, 'slots')
                        if not slots or len(slots) < 2:
                            continue
                        if any(row[0] in {'licenseplate_design_2_1', SLOT_TYPE}
                               for row in slots[1:] if isinstance(row, list) and row):
                            continue  # never reintroduce the alarm recursively
                        proxy['slots'] = slots
                        key = original_name
                    if key in seen:
                        continue
                    seen.add(key)
                    suffix = hashlib.sha1((original_name + '\0' + key).encode()).hexdigest()[:12]
                    # Old configurations store our proxy ID. Retain it when
                    # the provider moves from a flat design to nested styles.
                    name = 'starline_mod_plate_' + suffix
                    if 'slots' in proxy:
                        name = existing_ids.get((authors, label), name)
                    parts[name] = proxy
    return dict(sorted(parts.items(), key=lambda item: (item[1]['information']['name'].casefold(), item[0])))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mods_dir", type=Path, help="BeamNG user mods directory")
    parser.add_argument("--output", type=Path, default=OUTPUT)
    args = parser.parse_args()

    archives = []
    available_paths = {}
    for archive_path in sorted(args.mods_dir.glob("*.zip")):
        try:
            with ZipFile(archive_path) as archive:
                names = archive.namelist()
                archives.append((archive_path, [name for name in names if name.lower().endswith(".jbeam")]))
                for name in names:
                    available_paths.setdefault(name.lower(), name)
        except (BadZipFile, OSError):
            print("Skipping unreadable archive:", archive_path.name)

    existing = json.loads(args.output.read_text()) if args.output.exists() else {}
    parts = generate_parts(archives, available_paths, existing)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(parts, ensure_ascii=False, indent=2) + "\n")
    print("Generated", len(parts), "installed mod plate choices in", args.output)


if __name__ == "__main__":
    main()
