"""Regression coverage for flat plates and HTNV's nested style selector."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('plate_proxies', ROOT / 'scripts/generate_plate_proxies.py')
plates = importlib.util.module_from_spec(spec)
spec.loader.exec_module(plates)


class PlateProxies(unittest.TestCase):
    def generate(self, source, existing=None):
        with tempfile.TemporaryDirectory() as directory:
            archive = Path(directory) / 'plates.zip'
            with ZipFile(archive, 'w') as z:
                z.writestr('vehicles/common/plates.jbeam', source)
            return plates.generate_parts([(archive, ['vehicles/common/plates.jbeam'])],
                                         {'plate.json': 'plate.json'}, existing)

    def test_nested_style_selection_and_saved_config(self):
        source = '''{
          "htnv_regular": {
            "information": {"authors":"htnv", "name":"Russian Regular"},
            "slotType":"licenseplate_design_2_1",
            "slots":[["type","default","description"],
              ["htnv_style","htnv_default","Style",{"coreSlot":true}],],
          },
          "htnv_default": {"slotType":"htnv_style", "licenseplate_path":"plate.json"},
          "htnv_bold": {"slotType":"htnv_style", "licenseplate_path":"bold.json"},
        }'''
        old = {'saved_id': {'information': {'authors': 'htnv', 'name': 'Russian Regular'},
                            'slotType': plates.SLOT_TYPE, 'licenseplate_path': 'obsolete.json'}}
        result = self.generate(source, old)
        self.assertEqual(set(result), {'saved_id'})
        part = result['saved_id']
        self.assertEqual(part['slotType'], plates.SLOT_TYPE)
        self.assertNotIn('licenseplate_path', part)
        self.assertEqual(part['slots'][1], ['htnv_style', 'htnv_default', 'Style', {'coreSlot': True}])
        # The native style slot accepts both default and bold; changing the
        # selected child changes the merged licenseplate_path.
        native = dict(plates.part_blocks(source))
        for selected, expected in [('htnv_default', 'plate.json'), ('htnv_bold', 'bold.json')]:
            self.assertEqual(plates.field(native[selected], 'slotType'), part['slots'][1][0])
            self.assertEqual(plates.field(native[selected], 'licenseplate_path'), expected)

    def test_flat_legacy_design_keeps_path(self):
        result = self.generate('''{"flat":{"information":{"name":"Old Plate"},
          "slotType":"licenseplate_design_2_1","licenseplate_path":"plate.json"}}''')
        part = next(iter(result.values()))
        self.assertEqual(part['licenseplate_path'], 'plate.json')
        self.assertNotIn('slots', part)

    def test_missing_template_and_recursive_slots_excluded(self):
        self.assertEqual(self.generate('''{"missing":{"information":{"name":"Missing"},
          "slotType":"licenseplate_design_2_1","licenseplate_path":"missing.json"}}'''), {})
        self.assertEqual(self.generate('''{"recursive":{"information":{"name":"Recursive"},
          "slotType":"licenseplate_design_2_1", "slots":[["type","default","description"],
          ["licenseplate_design_2_1","alarm","Again"]]}}'''), {})

    def test_comments_and_brackets_inside_labels(self):
        body = '''{"slots":[["type","default","description"], // comment
          ["style","default","Style // [x],]",{"coreSlot":true,}], /* done */]}'''
        self.assertEqual(plates.array_field(body, 'slots')[1][2], 'Style // [x],]')

    def test_packaged_htnv_categories_use_native_children(self):
        data = json.loads((ROOT / 'mod/starline_alarm/vehicles/common/licenseplates/starline/starline_mod_plates.jbeam').read_text())
        parts = [p for p in data.values() if p['information']['authors'] == 'htnv']
        self.assertEqual(len(parts), 10)
        for part in parts:
            self.assertNotIn('licenseplate_path', part)
            self.assertEqual(part['slotType'], plates.SLOT_TYPE)
            self.assertEqual(len(part['slots']), 2)
            self.assertTrue(part['slots'][1][0].startswith('licenseplate_design_htnv_'))
            self.assertTrue(part['slots'][1][3]['coreSlot'])


if __name__ == '__main__':
    unittest.main()
