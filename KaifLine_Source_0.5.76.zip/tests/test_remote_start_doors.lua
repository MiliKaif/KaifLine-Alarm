-- Exercise the exported controller through command acceptance, starter and
-- successful start, including vehicles that cannot report door states.
local function test(doorMode, armed, speed, hoodOpen, brake)
  local published, running, starterCount = {}, false, 0
  local doorOpen = doorMode == 'open'
  log = function() end
  obj = {getId=function() return 42 end, getEnvTemperature=function() return 293.15 end,
    queueGameEngineLua=function() end}
  v = {data={props={}, nodes={}}}
  energyStorage = {getStorages=function() return {} end}
  electrics = {values={ignitionLevel=0, lights_state=0},
    setLightsState=function(value) electrics.values.lights_state=value end,
    setIgnitionLevel=function(value)
      electrics.values.ignitionLevel=value
      if value==3 then running=true; starterCount=starterCount+1 end
    end}
  sounds = {}
  guihooks = {message=function() end}
  powertrain = {getDevice=function() return nil end}
  jsonEncode = function(value) published[#published+1]=value; return '{}' end
  package.loaded.controller = {getControllerSafe=function() return nil end}
  package.loaded.electrics = electrics
  package.loaded.sounds = sounds
  package.loaded['controller/alarmEngineInterlock'] = {
    isActive=function() return false end, isSupported=function() return false end,
    block=function() end, unblock=function() end}
  local adapter = {
    init=function() return true end,
    isEngineRunning=function() return running end,
    getIgnitionLevel=function() return electrics.values.ignitionLevel end,
    getWheelspeed=function() return speed or 0 end,
    getParkingBrake=function() return brake==false and 0 or 1 end,
    getThrottle=function() return 0 end,
    getHoodStateTable=function() return {known=true, open=hoodOpen==true, closed=not hoodOpen} end,
    getTrunkStateTable=function() return {known=false} end,
    getDoorStates=function()
      if doorMode=='closed' or doorMode=='open' then
        return {FL={known=true, open=doorOpen, closed=not doorOpen}}
      end
      return {FL={known=false}}
    end,
    lockDoors=function() return true end,
    unlockDoors=function() return true end,
  }
  if doorMode~='missing' then
    adapter.allDoorsClosed=function()
      if doorMode=='error' then error('door controller unavailable') end
      if doorMode=='unknown_nil' then return nil end
      return doorMode=='closed' and not doorOpen
    end
  end
  package.loaded['controller/vehicleAdapterUniversal']=adapter
  -- Avoid retaining light bindings to a previous fixture's electrics table.
  package.loaded['controller/starlineWelcomeLight']=nil
  package.loaded['controller/starlinePlateLight']=nil
  package.path='mod/starline_alarm/lua/vehicle/?.lua;'..package.path
  local alarm=dofile('mod/starline_alarm/lua/vehicle/controller/starlineAlarm.lua')
  alarm.init({})
  if armed then
    assert(alarm.handleCommand('arm'))
    for _=1,40 do alarm.updateGFX(.05) end
    assert(_G.starline_alarm_getState()=='ARMED')
  end
  local ok, reason=alarm.handleCommand('remoteStart')
  if speed and speed>1 then
    assert(not ok and reason=='car_moving' and starterCount==0)
  elseif hoodOpen then
    assert(not ok and reason=='hood_open' and starterCount==0)
  elseif brake==false then
    assert(not ok and reason=='remote_start_brake_confirmation' and starterCount==0)
    assert(alarm.handleCommand('remoteStart'), 'second gesture still confirms missing brake')
  else
    assert(ok, tostring(reason)..' for '..doorMode)
    assert(_G.starline_alarm_getState()=='REMOTE_STARTING')
    for _=1,40 do alarm.updateGFX(.05) end
    assert(starterCount==1 and running, 'starter must run with '..doorMode)
    assert(_G.starline_alarm_getState()==(armed and 'WAIT_AUTH' or 'RUNNING_AUTHORIZED'))
    local last=published[#published]
    assert(last.doors.FL.known==(doorMode=='closed' or doorMode=='open'))
    if doorMode=='open' then assert(last.doors.FL.open, 'open door indicator must remain truthful') end
    if armed and doorMode=='closed' then
      doorOpen=true
      alarm.updateGFX(.05)
      assert(_G.starline_alarm_getState()=='ALARM', 'opening a guarded closed door must still trigger alarm')
    end
  end
  alarm.reset({})
end

for _, mode in ipairs({'closed','open','unknown_false','unknown_nil','missing','error'}) do
  test(mode,false)
  test(mode,true)
end
test('open',false,5)
test('open',false,0,true)
test('open',false,0,false,false)
print('PASS: remote start accepts open/missing/unknown doors, starts engine, preserves indicators, guarded openings, movement/hood/brake checks')
